{{--

    
    <div class="slider-container">
        <slider-component
            direction="{{ core()->getCurrentLocale()->direction }}"
            default-banner="{{ asset('/themes/velocity/assets/images/banner.webp') }}"
            :banners="{{ json_encode($sliderData) }}">

            <!-- this is default content if js is not loaded --> 
            @if(! empty($sliderData))
                <img class="col-12 no-padding banner-icon" src="{{ asset('/storage/' . $sliderData[0]['path']) }}" alt=""/>
            @else
                <img class="col-12 no-padding banner-icon" src="{{ asset('/themes/velocity/assets/images/banner.webp') }}" alt=""/>
            @endif

        </slider-component>
    </div>
    

    --}}
    @if ($velocityMetaData && $velocityMetaData->slider)
        <section id="banner"
            @if(! empty($sliderData))
                style = "background: url({{ asset('/storage/' . $sliderData[0]['path']) }});background-position: center;
                background-repeat: no-repeat;
                background-size: cover;
                height: 65vh;
                display: flex;
                align-items: center;
                justify-content: center;"
            @endif
         >
            <div class="container">    
                <div class="banner-slider"></div>
                <div class="banner-search-engine">
                    <form method="GET"
                                    role="search"
                                    id="search-form"
                                    action="{{ route('velocity.search.index') }}"
                                    
                                    >
                        <button type = "submit" role="button" class="banner_search_btn">
                            <i class="far fa-search"></i>
                        </button>
                        <input type="text" name = "term" id="" placeholder="Search....">
                    </form>
                </div>
            </div>
        </section>
    @endif 