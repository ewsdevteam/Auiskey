<popular-categories
    heading="{{ __('velocity::app.home.popular-categories') }}"
    :categories="{{ json_encode($category) }}">
</popular-categories>
