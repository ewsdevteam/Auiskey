<section id="follow-us">
        <div class="container-fluid">
            <div class="follow-us-title">
                <h1>Follow us on Instagram</h1>
            </div>
            <div class="follow-us-container">
                <div class="follow-box">
                    <a href="">
                        <div class="social-instagram-1">
                            <i class="fab fa-instagram"></i>
                        </div>
                    </a>
                </div>
                <div class="follow-box">
                    <a href="">
                        <div class="social-instagram-1">
                            <i class="fab fa-instagram"></i>
                        </div>
                    </a>
                </div>
                <div class="follow-box">
                    <a href="">
                        <div class="social-instagram-1">
                            <i class="fab fa-instagram"></i>
                        </div>
                    </a>
                </div>
                <div class="follow-box">
                    <a href="">
                        <div class="social-instagram-1">
                            <i class="fab fa-instagram"></i>
                        </div>
                    </a>
                </div>
                <div class="follow-box">
                    <a href="">
                        <div class="social-instagram-1">
                            <i class="fab fa-instagram"></i>
                        </div>
                    </a>
                </div>
                <div class="follow-box">
                    <a href="">
                        <div class="social-instagram-1">
                            <i class="fab fa-instagram"></i>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </section><!-- End. follow-us -->