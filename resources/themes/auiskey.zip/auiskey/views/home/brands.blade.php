@php
    $categoryRepository = app('Webkul\Category\Repositories\CategoryRepository');
    $latest_categories = $categoryRepository->getCategoryLatest();
@endphp
<section id="popular-brands">
        <div class="container">
            <div class="popular-brands most-popular-container">
                <div class="popular-titles">
                    <a href="javascript:void()" class="title-text">Popular Brands</a>
                    <a href="">view more</a>
                </div>
                <div class="brands-items">
                    <div class="popular-brand-item">
                        <div class="brand-item">
                            <div class="brand-img">
                                <img src="{{asset('themes/auiskey/assets/img/popular-brands/jordan.png')}}" alt="jordan-logo">
                            </div>
                            <div class="brand-item-title">
                                <a href="">Jordan</a>
                            </div>
                        </div>
                        <div class="brand-item">
                            <div class="brand-img">
                                <img src="{{asset('themes/auiskey/assets/img/popular-brands/yeezy.png')}}" alt="yeezy-logo">
                            </div>
                            <div class="brand-item-title">
                                <a href="">yeezy</a>
                            </div>
                        </div>
                        <div class="brand-item">
                            <div class="brand-img">
                                <img src="{{asset('themes/auiskey/assets/img/popular-brands/nike.png')}}" alt="nike-logo">
                            </div>
                            <div class="brand-item-title">
                                <a href="">nike</a>
                            </div>
                        </div>
                        <div class="brand-item">
                            <div class="brand-img">
                                <img src="{{asset('themes/auiskey/assets/img/popular-brands/addidas.png')}}" alt="addidas-logo">
                            </div>
                            <div class="brand-item-title">
                                <a href="">addidas</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End .Under Retails products slider -->
            </div><!-- End. popular-brands -->
            @if(count($latest_categories) > 0)
                <div class="brands-slider owl-carousel owl-theme" id="popular-brand-cat">
                @foreach($latest_categories as $category)
                    <div class="popular-brand-list">
                        <div class="popular-brand-img">
                            <a href=""><img src="{{asset('storage/'.$category->image)}}" alt="{{ $category->name }}">
                            </a>
                        </div>
                        <div class="popular-brand-title">
                            <a href="">{{ $category->name }}</a>
                        </div>
                    </div>
                @endforeach
                </div><!-- End. Popular-brand-cat -->    
            @endif  
        </div><!-- End. Container -->
    </section><!-- End section. popular-brands -->

