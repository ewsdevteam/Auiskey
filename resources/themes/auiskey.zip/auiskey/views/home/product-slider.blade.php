    @push('css')
    <link rel="stylesheet" href="{{ asset('themes/auiskey/assets/css/slick.css') }}">
    @endpush
    <div class="container">
            <div class="popular-categories">
                <div class="categrize-controle">
                    <a href=""><img src="{{asset('themes/auiskey/assets/img/socials/sneaker.png')}}" alt="sneakers"> sneakers</a>
                    <a href=""><img src="{{asset('themes/auiskey/assets/img/socials/hoodie.png')}}" alt="hoodie"> streetwear</a>
                    <a href=""><img src="{{asset('themes/auiskey/assets/img/socials/collectibles.png')}}" alt="collectibles"> collectibles</a>
                </div>
            </div>
            <div class="most-popular-container">
                <div class="popular-titles">
                    <a href="javascript:void()" class="title-text">most popular</a>
                    <a href="">view more</a>
                </div>
                <div class="slider popular-products">
                    <div class="slick-item">
                        <div class="popular-item">
                            <div class="popular-img">
                                <a href=""><img src="{{asset('themes/auiskey/assets/img/products/sneaker-1.png')}}" alt="sneaker-1"></a>
                            </div>
                            <div class="popular-item-title">
                                <a href="">Fragment Design x Travis Jordan 1  Low</a>
                                <a href=""><i class="fal fa-heart"></i></a>
                            </div>
                            <span class="title-tag">Lowest List</span>
                            <p class="price">$1,124</p>
                        </div>
                    </div>
                    <div class="slick-item">
                        <div class="popular-item">
                            <div class="popular-img">
                                <a href=""><img src="{{asset('themes/auiskey/assets/img/products/sneaker-2.png')}}" alt="sneaker-2"></a>
                            </div>
                            <div class="popular-item-title">
                                <a href="">Fragment Design x Travis Jordan 1  Low</a>
                                <a href=""><i class="fal fa-heart"></i></a>
                            </div>
                            <span class="title-tag">Lowest List</span>
                            <p class="price">$1,124</p>
                        </div>
                    </div>
                    <div class="slick-item">
                        <div class="popular-item">
                            <div class="popular-img">
                                <a href=""><img src="{{asset('themes/auiskey/assets/img/products/sneaker-3.png')}}" alt="sneaker-3"></a>
                            </div>
                            <div class="popular-item-title">
                                <a href="">Fragment Design x Travis Jordan 1  Low</a>
                                <a href=""><i class="fal fa-heart"></i></a>
                            </div>
                            <span class="title-tag">Lowest List</span>
                            <p class="price">$1,124</p>
                        </div>
                    </div>
                    <div class="slick-item">
                        <div class="popular-item">
                            <div class="popular-img">
                                <a href=""><img src="{{asset('themes/auiskey/assets/img/products/sneaker-4.png')}}" alt="sneaker-4"></a>
                            </div>
                            <div class="popular-item-title">
                                <a href="">Fragment Design x Travis Jordan 1  Low</a>
                                <a href=""><i class="fal fa-heart"></i></a>
                            </div>
                            <span class="title-tag">Lowest List</span>
                            <p class="price">$1,124</p>
                        </div>
                    </div>
                    <div class="slick-item">
                        <div class="popular-item">
                            <div class="popular-img">
                                <a href=""><img src="{{asset('themes/auiskey/assets/img/products/sneaker-1.png')}}" alt="sneaker-1"></a>
                            </div>
                            <div class="popular-item-title">
                                <a href="">Fragment Design x Travis Jordan 1  Low</a>
                                <a href=""><i class="fal fa-heart"></i></a>
                            </div>
                            <span class="title-tag">Lowest List</span>
                            <p class="price">$1,124</p>
                        </div>
                    </div>
                    <div class="slick-item">
                        <div class="popular-item">
                            <div class="popular-img">
                                <a href=""><img src="{{asset('themes/auiskey/assets/img/products/sneaker-2.png')}}" alt="sneaker-2"></a>
                            </div>
                            <div class="popular-item-title">
                                <a href="">Fragment Design x Travis Jordan 1  Low</a>
                                <a href=""><i class="fal fa-heart"></i></a>
                            </div>
                            <span class="title-tag">Lowest List</span>
                            <p class="price">$1,124</p>
                        </div>
                    </div>
                    <div class="slick-item">
                        <div class="popular-item">
                            <div class="popular-img">
                                <a href=""><img src="{{asset('themes/auiskey/assets/img/products/sneaker-3.png')}}" alt="sneaker-3"></a>
                            </div>
                            <div class="popular-item-title">
                                <a href="">Fragment Design x Travis Jordan 1  Low</a>
                                <a href=""><i class="fal fa-heart"></i></a>
                            </div>
                            <span class="title-tag">Lowest List</span>
                            <p class="price">$1,124</p>
                        </div>
                    </div>
                    <div class="slick-item">
                        <div class="popular-item">
                            <div class="popular-img">
                                <a href=""><img src="{{asset('themes/auiskey/assets/img/products/sneaker-4.png')}}" alt="sneaker-4"></a>
                            </div>
                            <div class="popular-item-title">
                                <a href="">Fragment Design x Travis Jordan 1  Low</a>
                                <a href=""><i class="fal fa-heart"></i></a>
                            </div>
                            <span class="title-tag">Lowest List</span>
                            <p class="price">$1,124</p>
                        </div>
                    </div>
                </div>
                <!-- End .Popular products slider -->
            </div>
            <!-- End. most-popular-container -->

            <div class="under-retail most-popular-container">
                <div class="popular-titles">
                    <a href="javascript:void()" class="title-text">Under Retail</a>
                    <a href="">view more</a>
                </div>
                <div class="slider popular-products">
                    <div class="slick-item">
                        <div class="popular-item">
                            <div class="popular-img">
                                <a href=""><img src="{{asset('themes/auiskey/assets/img/products/sneaker-1.png')}}" alt="sneaker-1"></a>
                            </div>
                            <div class="popular-item-title">
                                <a href="">Fragment Design x Travis Jordan 1  Low</a>
                                <a href=""><i class="fal fa-heart"></i></a>
                            </div>
                            <span class="title-tag">Lowest List</span>
                            <p class="price">$1,124</p>
                        </div>
                    </div>
                    <div class="slick-item">
                        <div class="popular-item">
                            <div class="popular-img">
                                <a href=""><img src="{{asset('themes/auiskey/assets/img/products/sneaker-2.png')}}" alt="sneaker-2"></a>
                            </div>
                            <div class="popular-item-title">
                                <a href="">Fragment Design x Travis Jordan 1  Low</a>
                                <a href=""><i class="fal fa-heart"></i></a>
                            </div>
                            <span class="title-tag">Lowest List</span>
                            <p class="price">$1,124</p>
                        </div>
                    </div>
                    <div class="slick-item">
                        <div class="popular-item">
                            <div class="popular-img">
                                <a href=""><img src="{{asset('themes/auiskey/assets/img/products/sneaker-3.png')}}" alt="sneaker-3"></a>
                            </div>
                            <div class="popular-item-title">
                                <a href="">Fragment Design x Travis Jordan 1  Low</a>
                                <a href=""><i class="fal fa-heart"></i></a>
                            </div>
                            <span class="title-tag">Lowest List</span>
                            <p class="price">$1,124</p>
                        </div>
                    </div>
                    <div class="slick-item">
                        <div class="popular-item">
                            <div class="popular-img">
                                <a href=""><img src="{{asset('themes/auiskey/assets/img/products/sneaker-4.png')}}" alt="sneaker-4"></a>
                            </div>
                            <div class="popular-item-title">
                                <a href="">Fragment Design x Travis Jordan 1  Low</a>
                                <a href=""><i class="fal fa-heart"></i></a>
                            </div>
                            <span class="title-tag">Lowest List</span>
                            <p class="price">$1,124</p>
                        </div>
                    </div>
                    <div class="slick-item">
                        <div class="popular-item">
                            <div class="popular-img">
                                <a href=""><img src="{{asset('themes/auiskey/assets/img/products/sneaker-1.png')}}" alt="sneaker-1"></a>
                            </div>
                            <div class="popular-item-title">
                                <a href="">Fragment Design x Travis Jordan 1  Low</a>
                                <a href=""><i class="fal fa-heart"></i></a>
                            </div>
                            <span class="title-tag">Lowest List</span>
                            <p class="price">$1,124</p>
                        </div>
                    </div>
                    <div class="slick-item">
                        <div class="popular-item">
                            <div class="popular-img">
                                <a href=""><img src="{{asset('themes/auiskey/assets/img/products/sneaker-2.png')}}" alt="sneaker-2"></a>
                            </div>
                            <div class="popular-item-title">
                                <a href="">Fragment Design x Travis Jordan 1  Low</a>
                                <a href=""><i class="fal fa-heart"></i></a>
                            </div>
                            <span class="title-tag">Lowest List</span>
                            <p class="price">$1,124</p>
                        </div>
                    </div>
                    <div class="slick-item">
                        <div class="popular-item">
                            <div class="popular-img">
                                <a href=""><img src="{{asset('themes/auiskey/assets/img/products/sneaker-3.png')}}" alt="sneaker-3"></a>
                            </div>
                            <div class="popular-item-title">
                                <a href="">Fragment Design x Travis Jordan 1  Low</a>
                                <a href=""><i class="fal fa-heart"></i></a>
                            </div>
                            <span class="title-tag">Lowest List</span>
                            <p class="price">$1,124</p>
                        </div>
                    </div>
                    <div class="slick-item">
                        <div class="popular-item">
                            <div class="popular-img">
                                <a href=""><img src="{{asset('themes/auiskey/assets/img/products/sneaker-4.png')}}" alt="sneaker-4"></a>
                            </div>
                            <div class="popular-item-title">
                                <a href="">Fragment Design x Travis Jordan 1  Low</a>
                                <a href=""><i class="fal fa-heart"></i></a>
                            </div>
                            <span class="title-tag">Lowest List</span>
                            <p class="price">$1,124</p>
                        </div>
                    </div>

            </div><!-- End. under-retail-container -->            
        </div>

            @push('scripts')
                <script type="text/javascript" src="{{asset('themes/auiskey/assets/js/slick.js')}}"></script>
                <script type="text/javascript" src="{{asset('themes/auiskey/assets/js/custom-code.js')}}"></script>
            @endpush    