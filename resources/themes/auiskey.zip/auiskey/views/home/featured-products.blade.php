
@inject ('reviewHelper', 'Webkul\Product\Helpers\Review')
@inject ('toolbarHelper', 'Webkul\Product\Helpers\Toolbar')

@php

    $count = core()->getConfigData('catalog.products.homepage.no_of_featured_product_homepage');
    $count = $count ? $count : 10;
    $direction = core()->getCurrentLocale()->direction == 'rtl' ? 'rtl' : 'ltr';

    // repositories

    $categoryRepository = app('Webkul\Category\Repositories\CategoryRepository');
    $productRepository = app('Webkul\Product\Repositories\ProductRepository');

    $featured_products = $productRepository->getFeaturedProducts();

    $new_products = $productRepository->getNewProducts();
     
@endphp

<section id="most-popular">
        <div class="container">
            <div class="popular-categories">
                <div class="categrize-controle">
                    <a href=""><img src="{{asset('themes/auiskey/assets/img/socials/sneaker.png')}}" alt="sneakers"> sneakers</a>
                    <a href=""><img src="{{asset('themes/auiskey/assets/img/socials/hoodie.png')}}" alt="hoodie"> streetwear</a>
                    <a href=""><img src="{{asset('themes/auiskey/assets/img/socials/collectibles.png')}}" alt="collectibles"> collectibles</a>
                </div>
            </div>
           @if($count > 0) 
            <div class="most-popular-container">
                <div class="popular-titles">
                    <a href="javascript:void()" class="title-text">most popular</a>
                    <a href="">view more</a>
                </div>
                <!-- skeleton | start -->
                    <div class="skeleton-loader">
                        <div class="most-popular-skeleton">
                            <div class="most-popular-skeleton-box">
                                <div class="most-popular-skeleton-inner_box"></div>
                                <p></p>
                                <p></p>
                                <p></p>
                            </div>
                            <div class="most-popular-skeleton-box">
                                <div class="most-popular-skeleton-inner_box"></div>
                                <p></p>
                                <p></p>
                                <p></p>
                            </div>
                            <div class="most-popular-skeleton-box">
                                <div class="most-popular-skeleton-inner_box"></div>
                                <p></p>
                                <p></p>
                                <p></p>
                            </div>
                            <div class="most-popular-skeleton-box">
                                <div class="most-popular-skeleton-inner_box"></div>
                                <p></p>
                                <p></p>
                                <p></p>
                            </div>
                        </div>
                    </div>
                    <!-- skeleton | start -->
                <div class="slider popular-products">
                   @foreach($featured_products as $product) 
                   @php
                    if (isset($product)) {
                            $productBaseImage = productimage()->getProductImage($product);
                        } else {
                            $productBaseImage = productimage()->getProductBaseImage($product);
                        }
                    @endphp

                    <div class="slick-item">
                            <div class="popular-item">
                                <div class="popular-img">
                                    <div class="inner_img">    
                                        <a href="{{ route('shop.productOrCategory.index', $product->url_key) }}"><img src="{{ $productBaseImage['original_image_url'] ?? base_path().'/vendor/webkul/ui/assets/images/product/large-product-placeholder.png' }}" alt="{{ $product->name }}" title="{{ $product->name }}"></a>
                                    </div>
                                </div>
                                <div class="popular-item-title">
                                    <a href="{{ route('shop.productOrCategory.index', $product->url_key) }}">{{ $product->name }}</a>
                                    <a href=""><i class="fal fa-heart"></i></a>
                                </div>
                                <span class="title-tag">Lowest List</span>
                                <p class="price">@include ('shop::products.price', ['product' => $product])</p>
                            </div>
                        </div>
                   @endforeach 
                   
                </div>
                <!-- End .Popular products slider -->
            </div>
            @endif
            <!-- End. most-popular-container -->

            <div class="under-retail most-popular-container">
                <div class="popular-titles">
                    <a href="javascript:void()" class="title-text">Under Retail</a>
                    <a href="">view more</a>
                </div>
                <!-- skeleton | start -->
                   <div class="skeleton-loader">
                        <div class="most-popular-skeleton">
                            <div class="most-popular-skeleton-box">
                                <div class="most-popular-skeleton-inner_box"></div>
                                <p></p>
                                <p></p>
                                <p></p>
                            </div>
                            <div class="most-popular-skeleton-box">
                                <div class="most-popular-skeleton-inner_box"></div>
                                <p></p>
                                <p></p>
                                <p></p>
                            </div>
                            <div class="most-popular-skeleton-box">
                                <div class="most-popular-skeleton-inner_box"></div>
                                <p></p>
                                <p></p>
                                <p></p>
                            </div>
                            <div class="most-popular-skeleton-box">
                                <div class="most-popular-skeleton-inner_box"></div>
                                <p></p>
                                <p></p>
                                <p></p>
                            </div>
                        </div>
                    </div>
                    <!-- skeleton | start -->
                <div class="slider popular-products">
                @foreach($new_products as $product) 
                   @php

                    if (isset($product)) {
                            $productBaseImage = productimage()->getProductImage($product);
                        } else {
                            $productBaseImage = productimage()->getProductBaseImage($product);
                        }
                    @endphp

                    <div class="slick-item">
                            <div class="popular-item">
                                <div class="popular-img">
                                    <div class="inner_img">
                                        <a href="{{ route('shop.productOrCategory.index', $product->url_key) }}"><img src="{{ $productBaseImage['original_image_url'] ?? base_path().'/vendor/webkul/ui/assets/images/product/large-product-placeholder.png' }}" alt="{{ $product->name }}" title="{{ $product->name }}"></a>
                                    </div>
                                </div>
                                <div class="popular-item-title">
                                    <a href="{{ route('shop.productOrCategory.index', $product->url_key) }}">{{ $product->name }}</a>
                                    <a href=""><i class="fal fa-heart"></i></a>
                                </div>
                                <span class="title-tag">Lowest List</span>
                                <p class="price">@include ('shop::products.price', ['product' => $product])</p>
                            </div>
                        </div>
                   @endforeach
            </div><!-- End. under-retail-container -->            
        </div>
</section><!-- End. most-popular -->
