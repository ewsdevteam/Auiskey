

        <section id="mobile-app">
        <div class="container">
            <div class="mobile-container">
                <div class="text-container">
                    <h1>Download the App</h1>
                    <div class="rating">
                        <span>4.9</span>
                        <span class="fas fa-star"></span>
                        <span class="fas fa-star"></span>
                        <span class="fas fa-star"></span>
                        <span class="fas fa-star"></span>
                        <span class="fas fa-star"></span>
                    </div>
                    <ul>
                        <li>Buy and sell sneakers, apparel and collectibles</li>
                        <li>Get access to exclusive offers, latest drops and more</li>
                        <li>100% authentic, limited edition and brand new</li>
                    </ul>
                    <a href="">Learn more</a>
                    <div class="app-store">
                        <div class="app-store-img">
                            <img src="{{asset('themes/auiskey/assets/img/socials/app-store.png')}}" alt="app-store-img">
                            <p>Scan this QR code with your smartphone to download the free app</p>
                        </div>
                    </div>
                </div>
                <div class="mobile-img-container">
                    <img src="{{asset('themes/auiskey/assets/img/socials/mobiles.png')}}" alt="mobile-img">
                </div>
            </div><!-- End. mobile-container -->
        </div>
    </section><!-- End. Mobile App -->

