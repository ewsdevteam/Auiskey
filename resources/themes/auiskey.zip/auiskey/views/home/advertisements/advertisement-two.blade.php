
    @php
        $blogs = DB::table('blogs')
                        ->join('admins','admins.id','=','blogs.author')
                        ->where('is_published','1')
                        ->latest()
                        ->limit(8)
                        ->get(['admins.name','blogs.*']);
    @endphp
  
    <section id="news-alert">
        <div class="container">
            <div class="row">
                <div class="col-sm-4 col-xs-12">
                    <aside id="news-sidebar">
                        <div class="news-title">
                            <a href="">Latest News</a>
                            <a href="">See All</a>
                        </div>
                        <div class="news-list">
                            <ul>
                            @foreach($blogs as $blog)
                                <li>
                                    <a href="">{{ $blog->title }}</a>
                                    <p><span>{{ $blog->name }}</span> - <span>{{ date('m/d/Y',strtotime($blog->posted_at)) }}</span></p>
                                </li>
                            @endforeach
                            </ul>
                            <a href="" class="browse-all">Browse All</a>
                        </div>
                    </aside>
                </div>
                <div class="col-sm-8 col-xs-12">
                    <div class="news-title">
                        <a href="">Release Calendar</a>
                        <a href="">See All</a>
                    </div>
                    <div class="news-catalogue-list">
                        <div class="news-products">
                            <div class="product-news-catalogue">
                                <div class="catalogue-title">
                                    <a href="">Aug | 19</a>
                                    <a href=""><i class="fal fa-plus-circle"></i></a>
                                </div>
                                <div class="catalogue-img">
                                    <img src="{{asset('themes/auiskey/assets/img/products/sneaker-new-1.png')}}" alt="sneaker">
                                </div>
                                <div class="catalogue-description">
                                    <a href="">Jordan 14 Retro aleali may fortune (w)</a>
                                    <a href="" class="btn btn-outline-danger bid-btn">BID</a>
                                </div>
                            </div>
                        </div>
                        <div class="news-products">
                            <div class="product-news-catalogue">
                                <div class="catalogue-title">
                                    <a href="">Aug | 19</a>
                                    <a href=""><i class="fal fa-plus-circle"></i></a>
                                </div>
                                <div class="catalogue-img">
                                    <img src="{{asset('themes/auiskey/assets/img/products/sneaker-new-2.png')}}" alt="sneaker">
                                </div>
                                <div class="catalogue-description">
                                    <a href="">nike dunk high 1985 red acid wash</a>
                                    <a href="" class="btn btn-outline-danger bid-btn">BID</a>
                                </div>
                            </div>
                        </div>
                        <div class="news-products">
                            <div class="product-news-catalogue">
                                <div class="catalogue-title">
                                    <a href="">Aug | 19</a>
                                    <a href=""><i class="fal fa-plus-circle"></i></a>
                                </div>
                                <div class="catalogue-img">
                                    <img src="{{asset('themes/auiskey/assets/img/products/t-shirt-1.png')}}" alt="T-shirt">
                                </div>
                                <div class="catalogue-description">
                                    <a href="">supreme rick rubin tee black</a>
                                    <a href="" class="btn btn-outline-danger bid-btn">BID</a>
                                </div>
                            </div>
                        </div>
                        <div class="news-products">
                            <div class="product-news-catalogue">
                                <div class="catalogue-title">
                                    <a href="">Aug | 19</a>
                                    <a href=""><i class="fal fa-plus-circle"></i></a>
                                </div>
                                <div class="catalogue-img">
                                    <img src="{{asset('themes/auiskey/assets/img/products/supreme-1.png')}}" alt="supreme">
                                </div>
                                <div class="catalogue-description">
                                    <a href="">supreme dog bone red</a>
                                    <a href="" class="btn btn-outline-danger bid-btn">BID</a>
                                </div>
                            </div>
                        </div>
                        <div class="news-products">
                            <div class="product-news-catalogue">
                                <div class="catalogue-title">
                                    <a href="">Aug | 19</a>
                                    <a href=""><i class="fal fa-plus-circle"></i></a>
                                </div>
                                <div class="catalogue-img">
                                    <img src="{{asset('themes/auiskey/assets/img/products/bottle-1.png')}}" alt="bottle">
                                </div>
                                <div class="catalogue-description">
                                    <a href="">supreme swing top 1.OL bottle (set of 2) clear</a>
                                    <a href="" class="btn btn-outline-danger bid-btn">BID</a>
                                </div>
                            </div>
                        </div>
                        <div class="news-products">
                            <div class="product-news-catalogue">
                                <div class="catalogue-title">
                                    <a href="">Aug | 19</a>
                                    <a href=""><i class="fal fa-plus-circle"></i></a>
                                </div>
                                <div class="catalogue-img">
                                    <img src="{{asset('themes/auiskey/assets/img/products/not-found.png')}}" alt="not-found">
                                </div>
                                <div class="catalogue-description">
                                    <a href="">supereme shrek tee black</a>
                                    <a href="" class="btn btn-outline-danger bid-btn">BID</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section><!-- End. news-alert -->
    