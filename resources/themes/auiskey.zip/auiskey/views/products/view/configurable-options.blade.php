@if (Webkul\Product\Helpers\ProductType::hasVariants($product->type))

    @inject ('configurableOptionHelper', 'Webkul\Product\Helpers\ConfigurableOption')

    @php
        $defaultVariant = $product->getTypeInstance()->getDefaultVariant();
        
        $config = $configurableOptionHelper->getConfigurationConfig($product);
        
        $galleryImages = productimage()->getGalleryImages($product);
    @endphp

    {!! view_render_event('bagisto.shop.products.view.configurable-options.before', ['product' => $product]) !!}

        <div class="sizes">
        @foreach($config['attributes'] as $attribute)
            @if($attribute["code"] == 'size')
                <p class="short-size">{{ $attribute["label"] }}:</p>
                <div class="size-choice">
                    <select name = "selected_configurable_option" id = "product-size-select" class="nice-select product-size-select">       
                        <option class="select-title" value = "">Sizes</option>
                        @foreach($attribute["options"] as $option)
                            <option value = "{{ $option['products'][0] ?? $product->id }}">{{ $option['label'] }}</option> 
                        @endforeach
                    </select>
                </div>
            @endif
        @endforeach    
        </div>
        <div id = "buy-or-bid" class="modal fade buy-or-bid"  tabindex="-1" role="dialog" >
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title">Select Size</h1>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="size-nav">
                    @foreach($config['attributes'] as $attribute)
                        @if($attribute["code"] == 'size')
                            @foreach($attribute["options"] as $option)
                                <a data-size="{{ $option['products'][0] ?? $product->id }}" class = "get_bid">{{ $option['label'] }} <p>Bid</p></a> 
                            @endforeach
                        @endif
                    @endforeach
                        
                    </div>
                </div>                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary btn-lg" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    @push('scripts')
        <script type = "text/javascript">

            $(document).ready(function(){

              $(".buy_now").submit(function (e) {

                    var val = $('.product-size-select .selected').data('value')
                    
                    if(val == ''){
                        e.preventDefault();
                        jQuery.noConflict();
                        $('#buy-or-bid').modal('toggle');
                    }
              })

              $(document).on('click','.get_bid',function(){
                jQuery.noConflict();
                $('#product-size-select').val($(this).data('size'));
                $('#buy-or-bid').modal('toggle');
                $(".buy_now").submit() 
              })

            }) 

        </script>
    @endpush
    {!! view_render_event('bagisto.shop.products.view.configurable-options.after', ['product' => $product]) !!}
    
@endif