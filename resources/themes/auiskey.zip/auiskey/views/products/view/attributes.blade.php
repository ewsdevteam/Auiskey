@inject ('productViewHelper', 'Webkul\Product\Helpers\View')

{!! view_render_event('bagisto.shop.products.view.attributes.before', ['product' => $product]) !!}
    @php
        $customAttributeValues = $productViewHelper->getAdditionalData($product);
    @endphp

    @if ($customAttributeValues)

                    <div class="short-desc">    
                    @foreach ($customAttributeValues as $attribute)                    
                        <p>
                            @if ($attribute['label'])
                                <span>{{ $attribute['label'] }}</span>
                            @else
                                <span>{{ $attribute['admin_name'] }}</span>
                            @endif

                            @if ($attribute['type'] == 'file' && $attribute['value'])
                                
                                    <a  href="{{ route('shop.product.file.download', [$product->product_id, $attribute['id']])}}" style="color:black;">
                                        <i class="icon rango-download-1"></i>
                                    </a>
                                
                            @elseif ($attribute['type'] == 'image' && $attribute['value'])
                                
                                    <a href="{{ route('shop.product.file.download', [$product->product_id, $attribute['id']])}}">
                                        <img src="{{ Storage::url($attribute['value']) }}" style="height: 20px; width: 20px;" alt=""/>
                                    </a>
                                
                            @else
                                {{ $attribute['value'] }}
                            @endif
                        </p>
                    @endforeach
                    </div>
    @endif

{!! view_render_event('bagisto.shop.products.view.attributes.after', ['product' => $product]) !!}