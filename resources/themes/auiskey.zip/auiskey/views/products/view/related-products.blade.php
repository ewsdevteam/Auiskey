<?php
    $relatedProducts = $product->related_products()->get();
?>

@if ($relatedProducts->count())
    
    <section class="popular-product" id="most-popular">
        <div class="container">
            <div class="most-popular-container">
                <div class="popular-titles">
                    <a href="javascript:void()" class="title-text">most popular</a>
                    <a href="">view more</a>
                </div>
                <div class="slider popular-products">
                    @foreach ($relatedProducts as $index => $product)
                        <div class="slick-item">
                            @include('shop::products.list.card')
                        </div>
                    @endforeach
                </div>
                        <!-- End .Popular products slider -->
            </div><!-- End. most-popular-container -->       
        </div>
    </section><!-- End. most-popular -->
@endif