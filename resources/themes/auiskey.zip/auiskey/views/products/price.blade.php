{!! view_render_event('bagisto.shop.products.price.before', ['product' => $product]) !!}

    {!! strip_tags($product->getTypeInstance()->getPriceHtml()) !!}

{!! view_render_event('bagisto.shop.products.price.after', ['product' => $product]) !!}