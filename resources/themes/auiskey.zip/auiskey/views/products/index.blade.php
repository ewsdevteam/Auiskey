@inject ('toolbarHelper', 'Webkul\Product\Helpers\Toolbar')
@inject ('productRepository', 'Webkul\Product\Repositories\ProductRepository')

@extends('shop::layouts.master')

@section('page_title')
    {{ trim($category->meta_title) != "" ? $category->meta_title : $category->name }}
@stop

@section('seo')
    <meta name="description" content="{{ $category->meta_description }}" />
    <meta name="keywords" content="{{ $category->meta_keywords }}" />

    @if (core()->getConfigData('catalog.rich_snippets.categories.enable'))
        <script type="application/ld+json">
            {!! app('Webkul\Product\Helpers\SEO')->getCategoryJsonLd($category) !!}
        </script>
    @endif
@stop

@push('css')
    <style type="text/css">
        .product-price span:first-child, .product-price span:last-child {
            font-size: 18px;
            font-weight: 600;
        }

        @media only screen and (max-width: 992px) {
            .main-content-wrapper .vc-header {
                box-shadow: unset;
            }
        }
    </style>
@endpush

@php

    $isProductsDisplayMode = in_array(
        $category->display_mode, [
            null,
            'products_only',
            'products_and_description'
        ]
    );

    $isDescriptionDisplayMode = in_array(
        $category->display_mode, [
            null,
            'description_only',
            'products_and_description'
        ]
    );
@endphp

@section('full-content-wrapper')
    
<section id="browse-banner">
            <div class="container">
                <div class="browse-banner-bg">
                    <div class="banner-text">
                        <h1 class="banner-heading">Browse</h1>
                        <p>On Yoututu, every sneaker you want is always available and authentic. Buy and sell new
                            sneakers & shoes from Air Jordan, adidas, Nike, Yeezy and more!</p>
                    </div>
                </div>
            </div>
        </section>
        <!-- End. Browse banner -->




        <section id="shop-category">
            <div class="container">
                <div class="filter-products-container">
                    <aside id="sidebar">
                        <div class="widget-area">
                            <nav class="nav-category">
                                <ul>
                                    <li><a href="">Sneakers</a></li>
                                    <li><a href="">Streetwear</a></li>
                                    <li><a href="">Collectibles</a></li>
                                    <li><a href="">Collectibles</a></li>
                                    <li><a href="">Watches</a></li>
                                </ul>
                            </nav>
                        </div>

                        <div class="widget-area">
                            <div class="widget-title">
                                <h2>Below Retail</h2>
                            </div>
                            <nav class="nav-category">
                                <ul>
                                    <li><a href="">adidas</a></li>
                                    <li><a href="">Air Jordan</a></li>
                                    <li><a href="">Nike</a></li>
                                    <li><a href="">New Balance</a></li>
                                    <li><a href="">Other Brands</a></li>
                                    <li><a href="">Luxury Brands</a></li>
                                    <li><a href="">Collections</a></li>
                                </ul>
                            </nav>
                        </div>

                        <div class="widget-area">
                            <div class="widget-title">
                                <h2>SIZE TYPES</h2>
                            </div>
                            <form action="">
                                <nav class="nav-category">
                                    <ul>
                                        <li><a href=""><input type="checkbox" name=""> men</a></li>
                                        <li><a href=""><input type="checkbox" name=""> women</a></li>
                                        <li><a href=""><input type="checkbox" name=""> kids</a></li>
                                        <li><a href=""><input type="checkbox" name=""> Preschool</a></li>
                                        <li><a href=""><input type="checkbox" name=""> inf.ant</a></li>
                                        <li><a href=""><input type="checkbox" name=""> Toddior</a></li>
                                    </ul>
                                </nav>
                            </form>
                        </div>

                        <div class="widget-area widget-sizes">
                            <div class="widget-title">
                                <h2>SIZES</h2>
                            </div>
                            <nav class="nav-category">
                                <ul>
                                    <li><a href="">1</a></li>
                                    <li><a href="">1.5</a></li>
                                    <li><a href="">2</a></li>
                                    <li><a href="">2.5</a></li>
                                    <li><a href="">3</a></li>
                                    <li><a href="">3.5</a></li>
                                    <li><a href="">4</a></li>
                                    <li><a href="">4.5</a></li>
                                    <li><a href="">5</a></li>
                                    <li><a href="">5.5</a></li>
                                    <li><a href="">6</a></li>
                                    <li><a href="">6.5</a></li>
                                    <li><a href="">7</a></li>
                                    <li><a href="">7.5</a></li>
                                    <li><a href="">8</a></li>
                                    <li><a href="">8.5</a></li>
                                    <li><a href="">9</a></li>
                                    <li><a href="">9.5</a></li>
                                    <li><a href="">10</a></li>
                                    <li><a href="">10.5</a></li>
                                    <li><a href="">11</a></li>
                                    <li><a href="">11.5</a></li>
                                    <li><a href="">12</a></li>
                                    <li><a href="">12.5</a></li>
                                    <li><a href="">13</a></li>
                                    <li><a href="">13.5</a></li>
                                    <li><a href="">14</a></li>
                                    <li><a href="">14.5</a></li>
                                    <li><a href="">15</a></li>
                                    <li><a href="">16</a></li>
                                    <li><a href="">17</a></li>
                                    <li><a href="">18</a></li>
                                </ul>
                            </nav>
                        </div>

                        <div class="widget-area">
                            <div class="widget-title">
                                <h2>PRIZES</h2>
                            </div>
                            <form action="">
                                <nav class="nav-category">
                                    <ul>
                                        <li><a href=""><input type="checkbox" name=""> Under  - A$100</a></li>
                                        <li><a href=""><input type="checkbox" name=""> A$100  - A$200</a></li>
                                        <li><a href=""><input type="checkbox" name=""> A$200  - A$300</a></li>
                                        <li><a href=""><input type="checkbox" name=""> A$300  - A$400</a></li>
                                        <li><a href=""><input type="checkbox" name=""> A$400  - A$500</a></li>
                                        <li><a href=""><input type="checkbox" name=""> A$500  - A$600</a></li>
                                        <li><a href=""><input type="checkbox" name=""> A$600+</a></li>
                                    </ul>
                                </nav>
                            </form>
                        </div>

                        <div class="widget-area widget-release-year">
                            <div class="widget-title">
                                <h2>RELEASE YEARS</h2>
                            </div>
                            <form action="">
                                <nav class="nav-category">
                                    <ul>
                                        <li>
                                            <a href=""><input type="checkbox" name="">&lt;2001</a>
                                            <a href=""><input type="checkbox" name=""> 2001</a>
                                        </li>
                                        <li>
                                            <a href=""><input type="checkbox" name=""> 2002</a>
                                            <a href=""><input type="checkbox" name=""> 2003</a>
                                        </li>
                                        <li>
                                            <a href=""><input type="checkbox" name=""> 2004</a>
                                            <a href=""><input type="checkbox" name=""> 2005</a>
                                        </li>
                                        <li>
                                            <a href=""><input type="checkbox" name=""> 2006</a>
                                            <a href=""><input type="checkbox" name=""> 2007</a>
                                        </li>
                                        <li>
                                            <a href=""><input type="checkbox" name=""> 2008</a>
                                            <a href=""><input type="checkbox" name=""> 2009</a>
                                        </li>
                                        <li>
                                            <a href=""><input type="checkbox" name=""> 2010</a>
                                            <a href=""><input type="checkbox" name=""> 2011</a>
                                        </li>
                                        <li>
                                            <a href=""><input type="checkbox" name=""> 2012</a>
                                            <a href=""><input type="checkbox" name=""> 2013</a>
                                        </li>
                                        <li>
                                            <a href=""><input type="checkbox" name=""> 2014</a>
                                            <a href=""><input type="checkbox" name=""> 2015</a>
                                        </li>
                                        <li>
                                            <a href=""><input type="checkbox" name=""> 2016</a>
                                            <a href=""><input type="checkbox" name=""> 2017</a>
                                        </li>
                                        <li>
                                            <a href=""><input type="checkbox" name=""> 2018</a>
                                            <a href=""><input type="checkbox" name=""> 2019</a>
                                        </li>
                                        <li>
                                            <a href=""><input type="checkbox" name=""> 2020</a>
                                            <a href=""><input type="checkbox" name=""> 2021</a>
                                        </li>
                                    </ul>
                                </nav>
                            </form>
                        </div>

                    </aside><!--End. sidebar-->

                    <div class="filter-products">
                        <div class="filter-head">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                                    <li class="breadcrumb-item"><a href="#">Library</a></li>
                                    <li class="breadcrumb-item active">Data</li>
                                </ol>
                            </nav><!-- End. Breadcrumbs -->
                            <div class="col-grid">
                                <ul>
                                    <li><a href=""><i class="fas fa-th"></i></a></li>
                                    <li><a href=""><i class="fas fa-bars"></i></a></li>
                                </ul>
                            </div><!-- End. col-grid -->
                        </div><!-- End. Filter Header -->


                        <div class="products-grid">
                            @foreach($products as $product)
                                @include('shop::products.list.card')
                            @endforeach    
                        </div><!-- End. Gird Column 4,1 Products -->

                        <nav aria-label="Page navigation">
                            <ul class="pagination justify-content-center">
                                {{ $products->links() }}
                            </ul>
                                

                        </nav><!-- End. Pagination -->
                    </div><!-- End. filter-products -->
                </div><!-- End. filter-products-container -->
            </div>
        </section>



        <section id="follow-us">
            <div class="container-fluid">
                <div class="follow-us-title">
                    <h1>Follow us on Instagram</h1>
                </div>
                <div class="follow-us-container">
                    <div class="follow-box">
                        <a href="">
                            <div class="social-instagram-1">
                                <i class="fab fa-instagram"></i>
                            </div>
                        </a>
                    </div>
                    <div class="follow-box">
                        <a href="">
                            <div class="social-instagram-1">
                                <i class="fab fa-instagram"></i>
                            </div>
                        </a>
                    </div>
                    <div class="follow-box">
                        <a href="">
                            <div class="social-instagram-1">
                                <i class="fab fa-instagram"></i>
                            </div>
                        </a>
                    </div>
                    <div class="follow-box">
                        <a href="">
                            <div class="social-instagram-1">
                                <i class="fab fa-instagram"></i>
                            </div>
                        </a>
                    </div>
                    <div class="follow-box">
                        <a href="">
                            <div class="social-instagram-1">
                                <i class="fab fa-instagram"></i>
                            </div>
                        </a>
                    </div>
                    <div class="follow-box">
                        <a href="">
                            <div class="social-instagram-1">
                                <i class="fab fa-instagram"></i>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </section><!-- End. follow-us -->
@stop

@push('scripts')
    <script type="text/x-template" id="category-template">
        <section class="row col-12 velocity-divide-page category-page-wrapper">
            {!! view_render_event('bagisto.shop.productOrCategory.index.before', ['category' => $category]) !!}

            @if (in_array($category->display_mode, [null, 'products_only', 'products_and_description']))
                @include ('shop::products.list.layered-navigation')
            @endif

            <div class="category-container right">
                <div class="row remove-padding-margin">
                    <div class="pl0 col-12">
                        <h2 class="fw6 mb10">{{ $category->name }}</h2>

                        @if ($isDescriptionDisplayMode)
                            @if ($category->description)
                                <div class="category-description">
                                    {!! $category->description !!}
                                </div>
                            @endif
                        @endif
                    </div>

                    <div class="col-12 no-padding">
                        <div class="hero-image">
                            @if (!is_null($category->image))
                                <img class="logo" src="{{ $category->image_url }}" alt="" width="20" height="20" />
                            @endif
                        </div>
                    </div>
                </div>

                @if ($isProductsDisplayMode)
                    <div class="filters-container">
                        <template v-if="products.length >= 0">
                            @include ('shop::products.list.toolbar')
                        </template>
                    </div>

                    <div
                        class="category-block"
                        @if ($category->display_mode == 'description_only')
                            style="width: 100%"
                        @endif>

                        <shimmer-component v-if="isLoading" shimmer-count="4"></shimmer-component>

                        <template v-else-if="products.length > 0">
                            @if ($toolbarHelper->getCurrentMode() == 'grid')
                                <div class="row col-12 remove-padding-margin">
                                    <product-card
                                        :key="index"
                                        :product="product"
                                        v-for="(product, index) in products">
                                    </product-card>
                                </div>
                            @else
                                <div class="product-list">
                                    <product-card
                                        list=true
                                        :key="index"
                                        :product="product"
                                        v-for="(product, index) in products">
                                    </product-card>
                                </div>
                            @endif

                            {!! view_render_event('bagisto.shop.productOrCategory.index.pagination.before', ['category' => $category]) !!}

                            <div class="bottom-toolbar" v-html="paginationHTML"></div>

                            {!! view_render_event('bagisto.shop.productOrCategory.index.pagination.after', ['category' => $category]) !!}
                        </template>

                        <div class="product-list empty" v-else>
                            <h2>{{ __('shop::app.products.whoops') }}</h2>
                            <p>{{ __('shop::app.products.empty') }}</p>
                        </div>
                    </div>
                @endif
            </div>

            {!! view_render_event('bagisto.shop.productOrCategory.index.after', ['category' => $category]) !!}
        </section>
    </script>

    <script>
        Vue.component('category-component', {
            template: '#category-template',

            data: function () {
                return {
                    'products': [],
                    'isLoading': true,
                    'paginationHTML': '',
                }
            },

            created: function () {
                this.getCategoryProducts();
            },

            methods: {
                'getCategoryProducts': function () {
                    this.$http.get(`${this.$root.baseUrl}/category-products/{{ $category->id }}${window.location.search}`)
                    .then(response => {
                        this.isLoading = false;
                        this.products = response.data.products;
                        this.paginationHTML = response.data.paginationHTML;
                    })
                    .catch(error => {
                        this.isLoading = false;
                        console.log(this.__('error.something_went_wrong'));
                    })
                }
            }
        })
    </script>
@endpush