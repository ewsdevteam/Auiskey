@extends('shop::layouts.master')

@inject ('reviewHelper', 'Webkul\Product\Helpers\Review')
@inject ('customHelper', 'Webkul\Velocity\Helpers\Helper')

@php
    $total = $reviewHelper->getTotalReviews($product);

    $avgRatings = $reviewHelper->getAverageRating($product);
    $avgStarRating = round($avgRatings);

    $productImages = [];
    $images = productimage()->getGalleryImages($product);

    foreach ($images as $key => $image) {
        array_push($productImages, $image['medium_image_url']);
    }
@endphp

@section('page_title')
    {{ trim($product->meta_title) != "" ? $product->meta_title : $product->name }}
@stop

@section('seo')
    <meta name="description" content="{{ trim($product->meta_description) != "" ? $product->meta_description : \Illuminate\Support\Str::limit(strip_tags($product->description), 120, '') }}"/>

    <meta name="keywords" content="{{ $product->meta_keywords }}"/>

    @if (core()->getConfigData('catalog.rich_snippets.products.enable'))
        <script type="application/ld+json">
            {!! app('Webkul\Product\Helpers\SEO')->getProductJsonLd($product) !!}
        </script>
    @endif

    <?php $productBaseImage = productimage()->getProductBaseImage($product, $images); ?>

    <meta name="twitter:card" content="summary_large_image" />

    <meta name="twitter:title" content="{{ $product->name }}" />

    <meta name="twitter:description" content="{{ $product->description }}" />

    <meta name="twitter:image:alt" content="" />

    <meta name="twitter:image" content="{{ $productBaseImage['medium_image_url'] }}" />

    <meta property="og:type" content="og:product" />

    <meta property="og:title" content="{{ $product->name }}" />

    <meta property="og:image" content="{{ $productBaseImage['medium_image_url'] }}" />

    <meta property="og:description" content="{{ $product->description }}" />

    <meta property="og:url" content="{{ route('shop.productOrCategory.index', $product->url_key) }}" />
@stop

@section('full-content-wrapper')
    {!! view_render_event('bagisto.shop.products.view.before', ['product' => $product]) !!}
        
   
    <section id="product-description">
     <form
        class="buy_now"
        method="POST"
        action="{{ route('cart.add', $product->product_id) }}">
        @csrf
        <input type="hidden" name="quantity" value="1">
        <input type="hidden" name="is_buy_now" value = "1" >
        <input type="hidden" name="product_id" value="{{ $product->product_id }}">
        <div class="container">
            <div class="breadcrumbs-social">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item"><a href="#">NEAKERS</a></li>
                        <li class="breadcrumb-item"><a href="#">NIKE</a></li>
                        <li class="breadcrumb-item"><a href="#">AIR FORCE</a></li>
                        <li class="breadcrumb-item"><a href="#">1</a></li>
                        <li class="breadcrumb-item"><a href="#">LOW</a></li>
                        <li class="breadcrumb-item active">NIKE AIR FORCE 1 LOW WHITE '07</li>
                    </ol>
                </nav><!-- End. Breadcrumbs -->
                <div class="social-btns">
                    <a href=""><i class="fas fa-arrow-up"></i> Share</a>
                    <a href=""><i class="fas fa-plus"></i> Portfolio</a>
                    <a href=""><i class="fas fa-plus"></i> Follow</a>
                </div>
            </div><!-- End. Breadcrumbs -->

            <div class="product-title-text">
                <h1>{{ $product->name }}</h1>
                <p>Condition:  <a href="" target="_blank" class="hot-text">New</a>  |  Ticker: AF1L-WHT07  |  <a href="" target="_blank" class="hot-text">100% Authentic</a></p>
            </div>
            
            <div class="product-biding">
                <div class="product-sizes">
                    @include ('shop::products.view.configurable-options')
                    <div class="sale-tag">
                        <div class="last-sale">
                            <p>Last Sale</p>
                            <span>Size: 9</span>
                        </div>
                        <div class="total-sale-representing">
                            <h3>A&dollar;205</h3>
                            <a href="">View All Sales</a>
                        </div>
                        <div class="sale-percentage">
                            <p><i class="fas fa-caret-down"></i> A&dollar;3 (3%)</p>
                        </div>
                    </div>
                </div><!-- End. Sizes -->
                <div class="biding-view">
                    <div class="bid-container">
                        <div class="bid-card lowest-bid">
                            <button type = "submit" class="btns-bidOrAsk" >
                                <div class="inner-shell">
                                    <div class="bid-left">
                                        <h3>--</h3>
                                        <span>Lowest Ask</span>
                                    </div>
                                    <div class="bid-right">
                                        <h3>Buy</h3>
                                        <h4>or Bid</h4>
                                    </div>
                                </div>
                            </button>
                        </div>
                        <div class="bid-card highest-bid">
                            <a href="">
                                <div class="inner-shell">
                                    <div class="bid-left">
                                        <h3>--</h3>
                                        <span>Highest Ask</span>
                                    </div>
                                    <div class="bid-right">
                                        <h3>Sell</h3>
                                        <h4>or Ask</h4>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div><!-- End. Biding -->
            </div>

            <div class="single360-product-slider">
                <!-- <div class="slider360-img">
                    <img src="img/products/single360-shoe.png" alt="sheo image">
                    <img src="img/socials/slider.png" alt="Slider">
                </div> -->
                <div class="spin360-slider">
                <div class="rotatebox">
                    <div class="images"></div>
                    <div class="slider"></div>
                    </div>
                </div>
                
            </div>            


            <div class="products-descriptions">
                <div class="row">
                    <div class="col-md-3 short__description">
                        @include('shop::products.view.attributes')
                    </div>
                    <div class="col-md-9">
                        <div class="long-desc">
                            <p>{!! $product->description !!}</p>
                            <div class="row">
                                <h2 class="text-center my-5 fw-bolder">OUR SERVICE GUARANTEE</h2>
                                <div class="col service-guarantee-img">
                                    <img src="{{asset('themes/auiskey/assets/img/socials/au-na-marketplace.png')}}" alt="AU/NA MARKETPLACE">
                                    <h4>AU/NA MARKETPLACE</h4>
                                </div>
                                <div class="col service-guarantee-img">
                                    <img src="{{asset('themes/auiskey/assets/img/socials/certified-authentic.png')}}" alt="CERTIFIED AUTHENTIC">
                                    <h4>CERTIFIED AUTHENTIC</h4>
                                </div>
                                <div class="col service-guarantee-img">
                                    <img src="{{asset('themes/auiskey/assets/img/socials/customer-care.png')}}" alt="CUSTOMER CARE">
                                    <h4>CUSTOMER CARE</h4>
                                </div>
                                <div class="col service-guarantee-img">
                                    <img src="{{asset('themes/auiskey/assets/img/socials/secure-transaction.png')}}" alt="SECURE TRANSACTIONS">
                                    <h4>SECURE TRANSACTIONS</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </form>
    </section>


    <section id="analysis">
        <div class="container">
            <div class="analysis-container">
                <div class="weeks-52 analysis-box">
                    <div class="weeks-img">
                        <img src="{{asset('themes/auiskey/assets/img/socials/52-weeks.png')}}" alt="52-weeks-icon">
                    </div>
                    <div class="weeks-text">
                        <h3>52 Weeks</h3>
                        <p>High &dollar;668 | Low &dollar;32</p>
                    </div>
                </div>
                <div class="trade-range analysis-box">
                    <div class="weeks-img">
                        <img src="{{asset('themes/auiskey/assets/img/socials/trade-range.png')}}" alt="trade-range-icon">
                    </div>
                    <div class="weeks-text">
                        <h3>Trade Range (12 Mos.)</h3>
                        <p>&dollar;92 - &dollar;118</p>
                    </div>
                </div>
                <div class="volatility analysis-box">
                    <div class="weeks-img">
                        <img src="{{asset('themes/auiskey/assets/img/socials/volatility.png')}}" alt="volatility-icon">
                    </div>
                    <div class="weeks-text">
                        <h3>Volatility</h3>
                        <p>12.2%</p>
                    </div>
                </div>
            </div>
        </div>
    </section><!-- End. Analysis -->

    <!-- Related Products -->

       @include('shop::products.view.related-products') 

    <!--End Related Products -->            
    <section class="follow-ul-product" id="follow-us">
        <div class="container-fluid">
            <div class="follow-us-title">
                <h1>Follow us on Instagram</h1>
            </div>
            <div class="follow-us-container">
                <div class="follow-box">
                    <a href="">
                        <div class="social-instagram-1">
                            <i class="fab fa-instagram"></i>
                        </div>
                    </a>
                </div>
                <div class="follow-box">
                    <a href="">
                        <div class="social-instagram-1">
                            <i class="fab fa-instagram"></i>
                        </div>
                    </a>
                </div>
                <div class="follow-box">
                    <a href="">
                        <div class="social-instagram-1">
                            <i class="fab fa-instagram"></i>
                        </div>
                    </a>
                </div>
                <div class="follow-box">
                    <a href="">
                        <div class="social-instagram-1">
                            <i class="fab fa-instagram"></i>
                        </div>
                    </a>
                </div>
                <div class="follow-box">
                    <a href="">
                        <div class="social-instagram-1">
                            <i class="fab fa-instagram"></i>
                        </div>
                    </a>
                </div>
                <div class="follow-box">
                    <a href="">
                        <div class="social-instagram-1">
                            <i class="fab fa-instagram"></i>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </section><!-- End. follow-us -->
     <!-- buy-or-bid MODAL -->
    
    {{--
        <div class="row no-margin">
            <section class="col-12 product-detail">
                <div class="layouter">
                    <product-view>
                        <div class="form-container">
                            @csrf()

                            <input type="hidden" name="product_id" value="{{ $product->product_id }}">

                            <div class="row">

                                <div class="left col-lg-5 col-md-6">
                                    @include ('shop::products.view.gallery')
                                </div>


                                <div class="right col-lg-7 col-md-6">

                                    <div class="row info">
                                        <h2 class="col-12">{{ $product->name }}</h2>

                                        @if ($total)
                                            <div class="reviews col-lg-12">
                                                <star-ratings
                                                    push-class="mr5"
                                                    :ratings="{{ $avgStarRating }}"
                                                ></star-ratings>

                                                <div class="reviews">
                                                    <span>
                                                        {{ __('shop::app.reviews.ratingreviews', [
                                                            'rating' => $avgRatings,
                                                            'review' => $total])
                                                        }}
                                                    </span>
                                                </div>
                                            </div>
                                        @endif

                                        @include ('shop::products.view.stock', ['product' => $product])

                                        <div class="col-12 price">
                                            @include ('shop::products.price', ['product' => $product])

                                            @if (Webkul\Tax\Helpers\Tax::isTaxInclusive() && $product->getTypeInstance()->getTaxCategory())
                                                <span>
                                                    {{ __('velocity::app.products.tax-inclusive') }}
                                                </span>
                                            @endif
                                        </div>

                                        @if (count($product->getTypeInstance()->getCustomerGroupPricingOffers()) > 0)
                                            <div class="col-12">
                                                @foreach ($product->getTypeInstance()->getCustomerGroupPricingOffers() as $offers)
                                                    {{ $offers }} </br>
                                                @endforeach
                                            </div>
                                        @endif

                                        <div class="product-actions">
                                            @if (core()->getConfigData('catalog.products.storefront.buy_now_button_display'))
                                                @include ('shop::products.buy-now', [
                                                    'product' => $product,
                                                ])
                                            @endif

                                            @include ('shop::products.add-to-cart', [
                                                'form' => false,
                                                'product' => $product,
                                                'showCartIcon' => false,
                                                'showCompare' => core()->getConfigData('general.content.shop.compare_option') == "1"
                                                                ? true : false,
                                            ])
                                        </div>
                                    </div>

                                    {!! view_render_event('bagisto.shop.products.view.short_description.before', ['product' => $product]) !!}

                                    @if ($product->short_description)
                                        <div class="description">
                                            <h3 class="col-lg-12">{{ __('velocity::app.products.short-description') }}</h3>

                                            {!! $product->short_description !!}
                                        </div>
                                    @endif

                                    {!! view_render_event('bagisto.shop.products.view.short_description.after', ['product' => $product]) !!}


                                    {!! view_render_event('bagisto.shop.products.view.quantity.before', ['product' => $product]) !!}

                                    @if ($product->getTypeInstance()->showQuantityBox())
                                        <div>
                                            <quantity-changer quantity-text="{{ __('shop::app.products.quantity') }}"></quantity-changer>
                                        </div>
                                    @else
                                        <input type="hidden" name="quantity" value="1">
                                    @endif

                                    {!! view_render_event('bagisto.shop.products.view.quantity.after', ['product' => $product]) !!}

                                    @include ('shop::products.view.configurable-options')

                                    @include ('shop::products.view.downloadable')

                                    @include ('shop::products.view.grouped-products')

                                    @include ('shop::products.view.bundle-options')

                                    @include ('shop::products.view.attributes', [
                                        'active' => true
                                    ])

                                    @include ('shop::products.view.description')


                                    @include ('shop::products.view.reviews', ['accordian' => true])
                                </div>
                            </div>
                        </div>
                    </product-view>
                </div>
            </section>

            <div class="related-products">
                @include('shop::products.view.related-products')
                @include('shop::products.view.up-sells')
            </div>
        </div>
    --}}
   
   
   
    {!! view_render_event('bagisto.shop.products.view.after', ['product' => $product]) !!}
@endsection
@php
    $images = productimage()->getGalleryImages($product);
    $videos = productvideo()->getVideos($product);

    $videoData = $imageData = [];

    foreach ($videos as $key => $video) {
        $videoData[$key]['type'] = $video['type'];
        $videoData[$key]['large_image_url'] = $videoData[$key]['small_image_url']= $videoData[$key]['medium_image_url']= $videoData[$key]['original_image_url'] = $video['video_url'];
    }

    foreach ($images as $key => $image) {
        $imageData[$key]['type'] = '';
        $imageData[$key]['large_image_url']    = $image['large_image_url'];
        $imageData[$key]['small_image_url']    = $image['small_image_url'];
        $imageData[$key]['medium_image_url']   = $image['medium_image_url'];
        $imageData[$key]['original_image_url'] = $image['original_image_url'];
    }

    $images = array_merge($imageData, $videoData);
    
@endphp
@push('scripts')
        <script>   
            var galleryImages = @json($images);
            var images = [];    
            galleryImages.forEach(function(item,index){           
                images.push(item.original_image_url)
            })
            rotate(images);
        //     rotate([
        //   "{{asset('themes/auiskey/assets/img/single-product/1.jpg')}}",
        //   "{{asset('themes/auiskey/assets/img/single-product/2.jpg')}}",
        //   "{{asset('themes/auiskey/assets/img/single-product/3.jpg')}}",
        //   "{{asset('themes/auiskey/assets/img/single-product/4.jpg')}}",
        //   "{{asset('themes/auiskey/assets/img/single-product/5.jpg')}}",
        //   "{{asset('themes/auiskey/assets/img/single-product/6.jpg')}}",
        //   "{{asset('themes/auiskey/assets/img/single-product/7.jpg')}}",
        //   "{{asset('themes/auiskey/assets/img/single-product/8.jpg')}}",
        //   "{{asset('themes/auiskey/assets/img/single-product/9.jpg')}}",
        //   "{{asset('themes/auiskey/assets/img/single-product/10.jpg')}}",
        //   "{{asset('themes/auiskey/assets/img/single-product/11.jpg')}}",
        //   "{{asset('themes/auiskey/assets/img/single-product/12.jpg')}}",
        //   "{{asset('themes/auiskey/assets/img/single-product/13.jpg')}}",
        //   "{{asset('themes/auiskey/assets/img/single-product/14.jpg')}}",
        //   "{{asset('themes/auiskey/assets/img/single-product/15.jpg')}}",
        //   "{{asset('themes/auiskey/assets/img/single-product/16.jpg')}}",
        //   "{{asset('themes/auiskey/assets/img/single-product/17.jpg')}}",
        //   "{{asset('themes/auiskey/assets/img/single-product/18.jpg')}}",
        //   "{{asset('themes/auiskey/assets/img/single-product/19.jpg')}}",
        //   "{{asset('themes/auiskey/assets/img/single-product/20.jpg')}}",
        //   "{{asset('themes/auiskey/assets/img/single-product/21.jpg')}}",
        //   "{{asset('themes/auiskey/assets/img/single-product/22.jpg')}}",
        //   "{{asset('themes/auiskey/assets/img/single-product/23.jpg')}}",
        //   "{{asset('themes/auiskey/assets/img/single-product/24.jpg')}}",
        //   "{{asset('themes/auiskey/assets/img/single-product/25.jpg')}}"
        // ])
        </script>    

@endpush