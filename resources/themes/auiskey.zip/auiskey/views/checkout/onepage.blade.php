@inject ('toolbarHelper', 'Webkul\Product\Helpers\Toolbar')
@inject ('productRepository', 'Webkul\Product\Repositories\ProductRepository')
@inject ('customHelper', 'Webkul\Velocity\Helpers\Helper')

@php
    $cart = Cart::getCart();
    $item = end($cart->items);
    $product = $productRepository->find($item[0]->product_id);

    $images = productimage()->getGalleryImages($product);
    $videos = productvideo()->getVideos($product);

    $videoData = $imageData = [];

    foreach ($videos as $key => $video) {
        $videoData[$key]['type'] = $video['type'];
        $videoData[$key]['large_image_url'] = $videoData[$key]['small_image_url']= $videoData[$key]['medium_image_url']= $videoData[$key]['original_image_url'] = $video['video_url'];
    }

    foreach ($images as $key => $image) {
        $imageData[$key]['type'] = '';
        $imageData[$key]['large_image_url']    = $image['large_image_url'];
        $imageData[$key]['small_image_url']    = $image['small_image_url'];
        $imageData[$key]['medium_image_url']   = $image['medium_image_url'];
        $imageData[$key]['original_image_url'] = $image['original_image_url'];
    }

    $images = array_merge($imageData, $videoData);

@endphp
@extends('shop::layouts.master')

@section('page_title')
    {{ __('shop::app.checkout.onepage.title') }}
@stop

@section('content-wrapper')
{!! view_render_event('bagisto.shop.products.view.before', ['product' => $product]) !!}
<div class="buy_sell_sizes">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-lg-7">
                        <div class="product-title_sellAsk">
                            <h1>{{ $product->name }}</h1>
                            <p>Highest Bid: <span class="bidAsk__price">$0</span> | Lowest Ask: <span
                                    class="bidAsk__price">$0</span></p>
                        </div>
                        <div class="product-seems">
                            <img src="{{ $images[0]['original_image_url'] }}" alt="{{ $product->name }}">
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-5">
                        <div class="size__bidAsk">

                            
                            <div class="tab-list-3">
                                <div class="">
                                    <div class="size-3">
                                        <a href="" data-toggle="modal" data-target=".buy-or-bid">
                                        <h3>U.S. Men's Size 5</h3>
                                        <i class="fal fa-pencil"></i>
                                        </a>
                                    </div>
                                    <div class="pills-container">
                                        <div class="pills-btns">
                                            <button class="pill-normal place__bid pill-active">Place Bid</button>
                                            <button class="pill-normal buy__now">Buy Now</button>
                                        </div>
                                        <div class="bid-enter">
                                            <form action="">
                                                <div class="input-groups">
                                                    <label for="">$</label>
                                                     <input type="number" name="bid_price" id="" placeholder="Enter Bid" class="form-control bid_textbox">  
                                                    <div class="No-ask-available hide_amount">No Asks Available</div>
                                                </div>
                                                <p class = "text-muted text-center bid-message"></p> 
                                            </form>
                                            <div class="invoice">
                                                <ul>
                                                    <li>
                                                        <p>Tax <i class="fas fa-question-circle"></i></p>
                                                        <p class = "total_tax">--</p>
                                                    </li>
                                                    <li>
                                                        <p>Discount</p>
                                                        <p class = "discount_amount">--</p>
                                                    </li>
                                                    <li class="total-amount-li">
                                                        <p>Total</p>
                                                        <p class="total-amount">--</p>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="btns_sizes">
                                        <a href="" class="btn btn-danger btn-lg cancel">Cancel</a>
                                        @auth('customer')  
                                            <a class="btn btn-success btn-lg buy_or_bid tab-3">Next</a>
                                        @endauth
                                        @guest('customer')  
                                            <a href = "{{ route('customer.session.create') }}" class="btn btn-success btn-lg">Next</a>
                                        @endguest
                                    </div>
                                </div>
                            </div>
                            <div class="tab-list-4" style = "display:none">
                                <div class="">
                                @include('shop::checkout.onepage.customer-info')                

                                    <div class="btns_sizes">
                                        <a href="" class="btn btn-danger btn-lg cancel">Cancel</a>
                                        <a class="btn btn-success btn-lg tab-4">Next</a>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-list-5" style = "display:none">
                                <div class="">
                                         <span id = "shipping_methods"></span>       

                                    <div class="btns_sizes">
                                        <a href="" class="btn btn-danger btn-lg cancel">Cancel</a>
                                        <a class="btn btn-success btn-lg tab-5">Next</a>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-list-6" style = "display:none">
                                <div class="">
                                         <span id = "payment_methods"></span>       

                                    <div class="btns_sizes">
                                        <a href="" class="btn btn-danger btn-lg cancel">Cancel</a>
                                        <a class="btn btn-success btn-lg tab-6">Next</a>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-list-7" style = "display:none">
                                <div class="">
                                         <span id = "order_review"></span>       

                                    <div class="btns_sizes">
                                        <a href="" class="btn btn-danger btn-lg cancel">Cancel</a>
                                        <a class="btn btn-success btn-lg place_bid_or_order place-bid">Place Bid</a>
                                    </div>
                                </div>
                            </div>
                            <div class="preloader">
                                <img src="{{asset('themes/auiskey/assets/img/socials/preloader.gif')}}" alt="preloader">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @if (Webkul\Product\Helpers\ProductType::hasVariants($product->type))
        @inject ('configurableOptionHelper', 'Webkul\Product\Helpers\ConfigurableOption')
            @php
            $config = $configurableOptionHelper->getConfigurationConfig($product);
            @endphp
        <div id = "buy-or-bid" class="modal fade buy-or-bid"  tabindex="-1" role="dialog" >
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title">Select Size</h1>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="size-nav">
                            @foreach($config['attributes'] as $attribute)
                                @if($attribute["code"] == 'size')
                                    @foreach($attribute["options"] as $option)
                                        <a data-size="{{ $option['products'][0] ?? $product->id }}" class = "get_bid">{{ $option['label'] }} <p>Bid</p></a> 
                                    @endforeach
                                @endif
                            @endforeach                   
                        </div>
                    </div>                
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary btn-lg" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        <form
            class="buy_now"
            method="POST"
            action="{{ route('cart.add', $product->product_id) }}">
            @csrf
            <input type="hidden" name="quantity" value="1">
            <input type="hidden" name="is_buy_now" value = "1" >
            <input type="hidden" name="product_id" value="{{ $product->product_id }}">
            <input type="hidden" name = "selected_configurable_option" id = "product-size-select">
        </form>        
    @endif

    {!! view_render_event('bagisto.shop.products.view.after', ['product' => $product]) !!}
@endsection

@push('scripts')

    <script>
        
        // Place Bid | Buy Now
        $(document).ready(function(){
            
            $(".place__bid").on("click",function(){
            $(this).addClass("pill-active");
            $(".buy__now").removeClass("pill-active")
            $(".bid_textbox").removeClass("bid_amount")
            $(".No-ask-available").addClass("hide_amount") 
            $(".buy_or_bid").addClass("tab-3")
            $(".buy_or_bid").removeClass("checkout")
            })

            $(".buy__now").on("click",function(){
            $(this).addClass("pill-active");
            $(".place__bid").removeClass("pill-active")      
            $(".bid_textbox").addClass("bid_amount")
            $(".total-amount-li").siblings("li").addClass("list_toggle");
            $(".No-ask-available").removeClass("hide_amount")
            $('.bid-message').html(' ')
            $(".buy_or_bid").removeClass("tab-3") 
            $(".buy_or_bid").addClass("checkout")
            })



            $(".total-amount-li").siblings("li").addClass("list_toggle");
            $(".bid_textbox").on("keyup",function(){

                $.ajax({
                    url:"{{ route('get_max_bid') }}",
                    type:'POST',
                    data:{product_id:"{{$product->id}}",'_token':"{{ csrf_token() }}"},
                    success:function(data){

                        if($(".bid_textbox").val() > data.max_bid){
                            $('.bid-message').html('You are about to be the highest bidder')    
                            $(".total-amount-li").siblings("li").removeClass("list_toggle");
                            $('.total_tax').html('$'+data.pre_calculations.tax)
                            $('.discount_amount').html('$'+data.pre_calculations.discount)
                            $('.total-amount').html('$'+ (Number($(".bid_textbox").val()) + Number(data.pre_calculations.tax) + Number(data.pre_calculations.discount)))
                            
                        }else{
                            $('.bid-message').html('You must meet the minimum Bid of $'+data.max_bid)
                            $(".total-amount-li").siblings("li").addClass("list_toggle");
                            $('.total_tax').html('--')
                            $('.discount_amount').html('--')
                            $('.total-amount').html('--')
                            
                        }

                        if($(".bid_textbox").val() == ''){
                            $('.bid-message').html(' ')
                        }
                 
                    }
                })

            
            })

            $(document).on('click','.checkout',function(){
                
                if($('.place_bid_or_order').hasClass("place-bid")){
                        
                    $('.place_bid_or_order').removeClass('place-bid')
                    $('.place_bid_or_order').addClass('place-order')
                    $('.place_bid_or_order').html('Place Order')
                    
                }
                
                $('.tab-list-3').hide()
                $('.tab-list-4').show()
               
            })

            $(document).on('click','.place-order',function(e){
                e.stopImmediatePropagation();
                $.ajax({
                type: "POST",
                url: "{{route('shop.checkout.save-order')}}",
                data: {'_token':"{{ csrf_token() }}"},
                beforeSend: function(){
					$(".preloader").show();
				},
				success: function(data) {
                    
                    window.location.href = "{{ route('thank-you') }}"
                },
                error: function(data) {
                    alert('error handling here');
                },
				complete:function(data){
					// Hide image container
					$(".preloader").hide();
				},
            });     
        
            })


            $(document).on('click','.tab-3',function(){
                
                $.ajax({
                type: "POST",
                url: "{{route('shop.checkout.save-bid-price')}}",
                data: {bid_price:$("input[name='bid_price']").val(),'_token':"{{csrf_token()}}"},
                beforeSend: function(){
					// Show image container
					$(".preloader").show();
				},
				success: function(data) {
                    
                    if($('.place_bid_or_order').hasClass("place-order")){
                        
                        $('.place_bid_or_order').removeClass('place-order')
                        $('.place_bid_or_order').addClass('place-bid')
                        $('.place_bid_or_order').html('Place Bid')
                    
                    }
                    
                    $('.tab-list-3').hide()
                    $('.tab-list-4').show()
                },
                error: function(data) {
                    alert('error handling here');
                },
				complete:function(data){
					// Hide image container
					$(".preloader").hide();
				},
            });
               
            })



            $(document).on('change','#use_for_shipping',function(){
                if($(this).is(':checked')){
                    $('.shipping_address').hide()
                }else{
                    $('.shipping_address').show()
                }
            })

            $(document).on('click','.tab-4',function(){
                    
                if($('#use_for_shipping').is(':checked')){
                   
                    var data = {
                        billing: {
                                    address1:[
                                        $("textarea[name='billing[address1][]']").val(),
                                    ], 
                                    company_name: 'Seftware',
                                    use_for_shipping:true,
                                    first_name: $("input[name='billing[first_name]']").val(),
                                    last_name: $("input[name='billing[last_name]']").val(),
                                    email: $("input[name='billing[email]']").val(),
                                    city: $("input[name='billing[city]']").val(),
                                    state: $("input[name='billing[state]']").val(),
                                    postcode: $("input[name='billing[postcode]']").val(),
                                    phone: $("input[name='billing[phone]']").val(),
                                    country: $("select[name='billing[country]']").val(),

                                },
                        shipping: {
                                    address1:[
                                        $("textarea[name='billing[address1][]']").val(),
                                    ], 
                                    company_name: 'Seftware',
                                    use_for_shipping:true,
                                    first_name: $("input[name='billing[first_name]']").val(),
                                    last_name: $("input[name='billing[last_name]']").val(),
                                    email: $("input[name='billing[email]']").val(),
                                    city: $("input[name='billing[city]']").val(),
                                    state: $("input[name='billing[state]']").val(),
                                    postcode: $("input[name='billing[postcode]']").val(),
                                    phone: $("input[name='billing[phone]']").val(),
                                    country: $("select[name='billing[country]']").val(),

                                },        
                                
                        "_token":"{{csrf_token()}}",            
                };
                   
                }else{

                    var data = {
                        billing: {
                                    address1:[
                                        $("textarea[name='billing[address1][]']").val(),
                                    ], 
                                    company_name: 'Seftware',
                                    use_for_shipping:true,
                                    first_name: $("input[name='billing[first_name]']").val(),
                                    last_name: $("input[name='billing[last_name]']").val(),
                                    email: $("input[name='billing[email]']").val(),
                                    city: $("input[name='billing[city]']").val(),
                                    state: $("input[name='billing[state]']").val(),
                                    postcode: $("input[name='billing[postcode]']").val(),
                                    phone: $("input[name='billing[phone]']").val(),
                                    country: $("select[name='billing[country]']").val(),

                                },
                        shipping: {
                                    address1:[
                                        $("textarea[name='shipping[address1][]']").val(),
                                    ], 
                                    company_name: 'Seftware',
                                    first_name: $("input[name='shipping[first_name]']").val(),
                                    last_name: $("input[name='shipping[last_name]']").val(),
                                    email: $("input[name='shipping[email]']").val(),
                                    city: $("input[name='shipping[city]']").val(),
                                    state: $("input[name='shipping[state]']").val(),
                                    postcode: $("input[name='shipping[postcode]']").val(),
                                    phone: $("input[name='shipping[phone]']").val(),
                                    country: $("input[name='shipping[country]']").val(),

                                },
                                
                        "_token":"{{csrf_token()}}",            
                };

                }
            
                
            $.ajax({
                type: "POST",
                url: "{{route('shop.checkout.save-address')}}",
                data: data,
                beforeSend: function(){
					// Show image container
					$(".preloader").show();
				},
				success: function(data) {
                    $('.tab-list-4').hide()
                    $('.tab-list-5').show()
                    $('#shipping_methods').html(data.html)
                },
                error: function(data) {
                    alert('error handling here');
                },
				complete:function(data){
					// Hide image container
					$(".preloader").hide();
				},
            });
            })


            $(document).on('click','.tab-5',function(){
                $.ajax({
                type: "POST",
                url: "{{route('shop.checkout.save-shipping')}}",
                data: {shipping_method:$("input[name='shipping_method']").val(),'_token':"{{ csrf_token() }}"},
                beforeSend: function(){
					// Show image container
					$(".preloader").show();
				},
				success: function(data) {
                    $('.tab-list-5').hide()
                    $('.tab-list-6').show()
                    $('#payment_methods').html(data.html)
                    
                },
                error: function(data) {
                    alert('error handling here');
                },
				complete:function(data){
					// Hide image container
					$(".preloader").hide();
				},
            });     
            })
            
            $(document).on('click',"input[name='payment[method]']:checked",function(){
                if($(this).val() == 'moneytransfer'){
                    $('#methodmoneytransfer').show();
                }
                else{
                    $('#methodmoneytransfer').hide();
                }
            })
            $(document).on('click','.tab-6',function(){
                $.ajax({
                type: "POST",
                url: "{{route('shop.checkout.save-payment')}}",
                data: {payment:{method:$("input[name='payment[method]']:checked").val()},'_token':"{{ csrf_token() }}"},
                beforeSend: function(){
					// Show image container
					$(".preloader").show();
				},
				success: function(data) {
                     $('.tab-list-6').hide()
                     $('.tab-list-7').show()
                     $('#order_review').html(data.html)
                    
                },
                error: function(data) {
                    alert('error handling here');
                },
				complete:function(data){
					// Hide image container
					$(".preloader").hide();
				},
            });     
            })

            $(document).on('click','.place-bid',function(e){
                e.stopImmediatePropagation();
                   $.ajax({
                   type: "POST",
                   url: "{{route('shop.checkout.save-bid')}}",
                   data: {'_token':"{{ csrf_token() }}"},
                   beforeSend: function(){
               		$(".preloader").show();
               	},
               	success: function(data) {
                       
                       window.location.href = "{{ route('thank-you') }}"
                   },
                   error: function(data) {
                       alert('error handling here');
                   },
               	complete:function(data){
               		// Hide image container
               		$(".preloader").hide();
               	},
               });     

               })
            $(document).on('click','.get_bid',function(){
                jQuery.noConflict();
                $('#product-size-select').val($(this).data('size'));
                $('#buy-or-bid').modal('toggle');
                $(".buy_now").submit() 
              })
            
        })
    </script>    

@endpush
