@extends('shop::layouts.master')

@section('full-content-wrapper')
    
<section class="authentication">
            <div class="authentication-banner selling-banner" id="about-banner">
                <div class="container">
                    <div class="authentication_selling_poster_sec selling_poster_sec">
                        <div class="selling_stock">
                            <h1>Guaranteed authenticity</h1>
                            <p>All item, All time. Shop with Aullad with full confidence knowing that all purchases are
                                100% Verified Authentic.</p>
                        </div>
                        <div class="selling_image">
                            <iframe width="100%" height="315" src="https://www.youtube.com/embed/88X1lqdbj-g"
                                title="YouTube video player" frameborder="0"
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                allowfullscreen></iframe>
                        </div>
                    </div>
                </div>
            </div><!-- Selling Main Banner -->



            <div class="believe_the_step">
                <div class="container">
                    <div class="main_section">
                        <div class="left_section">
                            <div class="title__text_box">
                                <h1>Believe The Step</h1>
                                <p>Our global team of expert authenticators uses a rigorous, multi-step verification
                                    procedure that includes the following checkpoints:</p>
                            </div>

                            <div class="specification_container">
                                <div class="specification_list">
                                    <div class="spec_icon">
                                        <img src="{{asset('themes/auiskey/assets/img/socials/guaranteed-authenticity2021.png')}}"
                                            alt="guaranteed-authenticity">
                                    </div>
                                    <div class="spec_desc">
                                        <h2>Condition</h2>
                                        <p>We only allow brand-new items on our marketplace which ensure all items that
                                            are purchased and sold are never worn and will be brand new.</p>
                                    </div>
                                </div>
                                <div class="specification_list">
                                    <div class="spec_icon">
                                        <img src="{{asset('themes/auiskey/assets/img/socials/construction2021.png')}}" alt="construction">
                                    </div>
                                    <div class="spec_desc">
                                        <h2>Integrity of item</h2>
                                        <p>With over access to all authentication data our team are now much equipped
                                            with more knowledge to ensure each product’s authenticity.</p>
                                    </div>
                                </div>
                                <div class="specification_list">
                                    <div class="spec_icon">
                                        <img src="{{asset('themes/auiskey/assets/img/socials/packaging2021.png')}}" alt="packaging">
                                    </div>
                                    <div class="spec_desc">
                                        <h2>Packaging</h2>
                                        <p>The packaging will meet highest quality standards to ensure the integrity of
                                            the package is top notch.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="authentic__sec">
                                <img src="{{asset('themes/auiskey/assets/img/gallery/authentic.jpg')}}" alt="authentic">
                                <div class="authentic__text">
                                    <p>authentic</p>
                                    <p>authentic</p>
                                    <p>authentic</p>
                                </div>
                            </div>

                        </div>
                        <div class="right_section">
                            <div class="authentic__sec">
                                <img src="{{asset('themes/auiskey/assets/img/gallery/bag.jpg')}}" alt="bag">
                                <div class="authentic__text">
                                    <p>verfied</p>
                                    <p>verfied</p>
                                    <p>verfied</p>
                                </div>
                            </div>

                            <div class="specification_container">
                                <div class="specification_list">
                                    <div class="spec_icon">
                                        <img src="{{asset('themes/auiskey/assets/img/socials/accessories2021-400x202.png')}}" alt="accessories">
                                    </div>
                                    <div class="spec_desc">
                                        <h2>Accessories</h2>
                                        <p>All accessories/add-ons of each products will be included in your purchase
                                            will meet any retailer purchase experience.</p>
                                    </div>
                                </div>
                                <div class="specification_list">
                                    <div class="spec_icon">
                                        <img src="{{asset('themes/auiskey/assets/img/socials/verified-authentic2021-400x230.png')}}"
                                            alt="verified-authentic2021">
                                    </div>
                                    <div class="spec_desc">
                                        <h2>Advanced Tech</h2>
                                        <p>Our team will be using the most modern and advance technology out there to
                                            authenticate every fine details of the products.</p>
                                    </div>
                                </div>
                                <div class="specification_list">
                                    <div class="spec_icon">
                                        <img src="{{asset('themes/auiskey/assets/img/socials/quality.png')}}" alt="quality">
                                    </div>
                                    <div class="spec_desc">
                                        <h2>Quality control</h2>
                                        <p>A last check by our experts will ensure that nothing slips through under us.
                                        </p>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

            
            <div class="hear-our-team">
                <div class="container">
                    <div class="vertical_trianle">
                        <img src="{{asset('themes/auiskey/assets/img/socials/vertical-triangle.png')}}" alt="vertical-triangles">
                    </div>
                    
                    <div class="hear_title_text">
                        <h1>Hear From Our Team</h1>
                    </div>


                    <div class="authentication-owl owl-carousel owl-theme">
                        <div class="item">
                            <div class="auth-pg__experience-wrapper">
                                <div class="auth-pg__experience-item">
                                    <div class="auth-pg__experience-image">
                                        <div class="auth-pg__experience-placeholder">
                                            <img class="img-bkg" src="{{asset('themes/auiskey/assets/img/gallery/testimonial-1.jpg')}}"
                                                alt="man">
                                        </div>
                                    </div>
                                    <div class="auth-pg__experience-content">
                                        <p class="auth-pg__experience-icon"></p>
                                        <p class="headline headline--style2 headline--4">In a community filled with inauthentic
                                            items, I have the opportunity to protect our customers and their hard earned money.
                                        </p>
                                        <p class="auth-pg__experience-author">Siebe</p>
                                        <p class="auth-pg__experience-title">Authenticator, Veldhoven</p>
                                    </div>                                    
                                </div>
                                <div class="auth-pg__experience-item">
                                    <div class="auth-pg__experience-content">
                                        <p class="auth-pg__experience-icon"></p>
                                        <p class="headline headline--style2 headline--4">I have the privilege of teaching a new
                                            generation of authenticators, to help them succeed, and watch them grow. It’s
                                            fulfilling to see.</p>
                                        <p class="auth-pg__experience-author">Alex</p>
                                        <p class="auth-pg__experience-title">Authenticator, Tempe</p>
                                    </div>
                                    <div class="auth-pg__experience-image">
                                        <div class="auth-pg__experience-placeholder">
                                            <img class="img-bkg"
                                                src="{{asset('themes/auiskey/assets/img/gallery/testimonial-2.jpg')}}"
                                                alt="man-2">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="auth-pg__experience-wrapper">
                                <div class="auth-pg__experience-item">
                                    <div class="auth-pg__experience-image">
                                        <div class="auth-pg__experience-placeholder">
                                            <img class="img-bkg" src="{{asset('themes/auiskey/assets/img/gallery/testimonial-3.jpg')}}"
                                                alt="man">
                                        </div>
                                    </div>
                                    <div class="auth-pg__experience-content">
                                        <p class="auth-pg__experience-icon"></p>
                                        <p class="headline headline--style2 headline--4">I am the second set of eyes reviewing packages before they ship out to customers. I take pride and care in ensuring our customers have a perfect unboxing experience.
                                        </p>
                                        <p class="auth-pg__experience-author">Lauren</p>
                                        <p class="auth-pg__experience-title">Quality Assurance, Detroit</p>
                                    </div>                                    
                                </div>
                                <div class="auth-pg__experience-item">
                                    <div class="auth-pg__experience-content">
                                        <p class="auth-pg__experience-icon"></p>
                                        <p class="headline headline--style2 headline--4">I authenticate every item as if it was going to a collector. I have a skillset that not many people have, and it’s my responsibility to provide the best service possible.</p>
                                        <p class="auth-pg__experience-author">Justin</p>
                                        <p class="auth-pg__experience-title">Authenticator, Detroit</p>
                                    </div>
                                    <div class="auth-pg__experience-image">
                                        <div class="auth-pg__experience-placeholder">
                                            <img class="img-bkg"
                                                src="{{asset('themes/auiskey/assets/img/gallery/testimonial-4.jpg')}}"
                                                alt="man-2">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- Owl Carousel -->
                </div>
            </div>




            <div class="Committed_to_Quality">
                <div class="committed">
                    <div class="com_banner">
                        <img src="{{asset('themes/auiskey/assets/img/gallery/tags-1200x800.jpg')}}" alt="tags">
                    </div>
                    <div class="com_text">
                        <h1>Committed to Quality</h1>
                        <p>Over the years, our team members have authenticated tens of millions of products at a 99.95% accuracy rate.</p>
                        <p>We’ve compiled data from every fake product in the history of StockX to build a comprehensive database of fake techniques around the world. Our database is updated daily and constantly serves to keep our team educated and up to date.</p>
                    </div>
                </div>
            </div>





            <div class="behind_the_scene">
                <div class="container">
                    <div class="text__headline">
                        <h1>Behind The Scenes</h1>
                        <p>Our authenticators share a deep love and knowledge for the products and culture around our marketplace.</p>
                    </div>
                    <div class="bts__videos">
                        <div class="authentication-owl owl-carousel owl-theme">
                            <div class="item">
                                <iframe width="75%" height="480" src="https://www.youtube.com/embed/uLvKx8yTH9A" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                            </div>
                            <div class="item">
                                <iframe width="75%" height="480" src="https://www.youtube.com/embed/9eoESGrw7eA" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                            </div>
                            <div class="item">
                                <iframe width="75%" height="480" src="https://www.youtube.com/embed/zp26bPDVR1M" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                            </div>
                        </div>
                        <p class="five_plus">+++++</p>
                    </div>
                </div>
                <div class="triable__left_bottom">
                    <img src="{{asset('themes/auiskey/assets/img/socials/triangle-bottom-left.png')}}" alt="triangle-bottom-left">
                </div>
            </div>






        <div class="faq-shop">
        <div class="container">
            <h1 class="faq-title">FAQ'S</h1>
            <div class="faqs">
                <div class="faq-card">
                    <p>What is a Bid, how do I buy on StockX?</p>
                    <p>There are two ways to buy on StockX: placing a bid or Buying Now. A Bid signals your...
                    </p>
                    <a href="" class="indication_right"><i class="far fa-arrow-right"></i></a>
                </div>
                <div class="faq-card">
                    <p>What is a Bid, how do I buy on StockX?</p>
                    <p>There are two ways to buy on StockX: placing a bid or Buying Now. A Bid signals your...
                    </p>
                    <a href="" class="indication_right"><i class="far fa-arrow-right"></i></a>
                </div>
                <div class="faq-card">
                    <p>What is a Bid, how do I buy on StockX?</p>
                    <p>There are two ways to buy on StockX: placing a bid or Buying Now. A Bid signals your...
                    </p>
                    <a href="" class="indication_right"><i class="far fa-arrow-right"></i></a>
                </div>
                <div class="faq-card">
                    <p>What is a Bid, how do I buy on StockX?</p>
                    <p>There are two ways to buy on StockX: placing a bid or Buying Now. A Bid signals your...
                    </p>
                    <a href="" class="indication_right"><i class="far fa-arrow-right"></i></a>
                </div>
                <div class="faq-card">
                    <p>What is a Bid, how do I buy on StockX?</p>
                    <p>There are two ways to buy on StockX: placing a bid or Buying Now. A Bid signals your...
                    </p>
                    <a href="" class="indication_right"><i class="far fa-arrow-right"></i></a>
                </div>
                <div class="faq-card">
                    <p>What is a Bid, how do I buy on StockX?</p>
                    <p>There are two ways to buy on StockX: placing a bid or Buying Now. A Bid signals your...
                    </p>
                    <a href="" class="indication_right"><i class="far fa-arrow-right"></i></a>
                </div>
                <div class="faq-card">
                    <p>What is a Bid, how do I buy on StockX?</p>
                    <p>There are two ways to buy on StockX: placing a bid or Buying Now. A Bid signals your...
                    </p>
                    <a href="" class="indication_right"><i class="far fa-arrow-right"></i></a>
                </div>
            </div>
            <div class="shop_faq">
                <h1 class="faq-title">SHOP</h1>
                <div class="shop-cards_list">
                    <a href="">
                        <div class="shop__img">
                            <img src="{{asset('themes/auiskey/assets/img/products/blue-shoe.png')}}" alt="blue-shoe">
                        </div>
                        <h4>Sneakers</h4>
                    </a>
                    <a href="">
                        <div class="shop__img">
                            <img src="{{asset('themes/auiskey/assets/img/products/streetwear.jpg')}}" alt="streetwear">
                        </div>
                        <h4>Streetwear</h4>
                    </a>
                    <a href="">
                        <div class="shop__img">
                            <img src="{{asset('themes/auiskey/assets/img/products/Electronics.jpg')}}" alt="Electronics">
                        </div>
                        <h4>Electronics</h4>
                    </a>
                    <a href="">
                        <div class="shop__img">
                            <img src="{{asset('themes/auiskey/assets/img/products/Collectibles.jpg')}}" alt="Collectibles">
                        </div>
                        <h4>Collectibles</h4>
                    </a>
                    <a href="">
                        <div class="shop__img">
                            <img src="{{asset('themes/auiskey/assets/img/products/Handbags.jpg')}}" alt="Handbags">
                        </div>
                        <h4>Sneakers</h4>
                    </a>
                    <a href="">
                        <div class="shop__img">
                            <img src="{{asset('themes/auiskey/assets/img/products/Watches.jpg')}}" alt="Watches">
                        </div>
                        <h4>Sneakers</h4>
                    </a>
                </div>
            </div>
        </div>
    </div><!-- Faq-shop -->
        </section>

@endsection