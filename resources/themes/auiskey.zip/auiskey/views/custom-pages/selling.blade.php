@extends('shop::layouts.master')

@section('full-content-wrapper')
<section id="about">

    <div class="selling-banner" id="about-banner" style="background-image:url({{asset('themes/auiskey/assets/img/brands/about-banner.png')}})">
        <div class="container">
            <div class="selling_poster_sec">
                <div class="selling_stock">
                    <p>SELLING ON STOCKX</p>
                    <h1>SELL, get the money, sell again</h1>
                    <a href="">Get Started <i class="fas fa-chevron-right"></i></a>
                </div>
                <div class="selling_image">
                    <img src="{{asset('themes/auiskey/assets/img/gallery/box.jpg')}}" alt="box">
                </div>
            </div>
        </div>
    </div><!-- Selling Main Banner -->

    <div class="map__country">
        <div class="container">
            <div class="row map__row">
                <div class="col-md-6">
                    <div class="map__listing">
                        <p>Sell with confidence</p>
                        <p>Look for your product, set your price. No pictures needed to be taken of product, no negotiation with potential buyers.</p>
                        <img src="{{asset('themes/auiskey/assets/img/socials/01.png')}}" alt="01_number_img">
                    </div>
                    <div class="map__listing">
                        <p>Worldwide marketplace</p>
                        <p>Our reach will be available to everyone who have a smart phone all around the world. We will bring the buyer to you.</p>
                        <img src="{{asset('themes/auiskey/assets/img/socials/02.png')}}" alt="02_number_img">
                    </div>
                    <div class="map__listing">
                        <p>Multiple rewards</p>
                        <p>Best commission rate in the market. unlock cheaper rates by selling more when you level up.</p>
                        <img src="{{asset('themes/auiskey/assets/img/socials/03.png')}}" alt="03_number_img">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="map__sec">
                        <img src="{{asset('themes/auiskey/assets/img/gallery/map.png')}}" alt="map">
                    </div>
                </div>
            </div>
        </div>
    </div><!-- Map -->

    <div class="start_selling">
        <div class="container">
            <h1 class="selling_title_text">SELL IN 4 STEPS</h1>
            <div class="selling_listing">
                <div class="selling__items">
                    <div class="selling_img">
                        <img src="{{asset('themes/auiskey/assets/img/socials/sign_up_and_sell.png')}}" alt="sell_icon">
                    </div>
                    <div class="selling_description">
                        <h3>Sign up and sell</h3>
                        <p>select a method for payout and currency from our option.</p>
                    </div>
                </div>
                <div class="selling__items">
                    <div class="selling_img">
                        <img src="{{asset('themes/auiskey/assets/img/socials/ab-analysis.png')}}" alt="analytics">
                    </div>
                    <div class="selling_description">
                        <h3>real time listing</h3>
                        <p>choose when to sell or put the lowest ask by looking at up to date sales data for all items in our marketplace.</p>
                    </div>
                </div>
                <div class="selling__items">
                    <div class="selling_img">
                        <img src="{{asset('themes/auiskey/assets/img/socials/ship_up_your_sell_items.png')}}" alt="ship_up_your_sell_items">
                    </div>
                    <div class="selling_description">
                        <h3>Ship us the items you sold</h3>
                        <p>We have a policy that you have to ship your items which you sold within 2 buisness days. Print the label we sent and allow our shipping guideline to ensure that your item reach us safely at our authentication center.</p>
                    </div>
                </div>
                <div class="selling__items">
                    <div class="selling_img">
                        <img src="{{asset('themes/auiskey/assets/img/socials/get_paid.png')}}" alt="money_icon">
                    </div>
                    <div class="selling_description">
                        <h3>Get Paid</h3>
                        <p>We will send you your payout as soon as we can ensure that your items are new and authentic.</p>
                    </div>
                </div>
            </div>
            <a href="" class="get__started">Get Started <i class="fas fa-chevron-right"></i></a>
        </div>
    </div>


    <div class="how_sell">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="control_sell">
                        <h1>Control How You Sell</h1>
                        <p>You can either place an Ask or Sell Now.</p>
                        <p>An Ask lets you select the price you'd like to sell your item for. If you have the
                            lowest Ask, Buyers who place a matching Bid will automatically Buy from you. Looking
                            for a faster solution? Select "Sell Now" on the product page to sell your item on
                            the spot to the highest Bid.</p>
                        <a href="" class="get__started">Get Started <i class="fas fa-chevron-right"></i></a>
                    </div>
                </div>
                <div class="col-md-6 control_img_col">
                    <div class="control_img">
                        <img src="{{asset('themes/auiskey/assets/img/products/shoe-sell.jpg')}}" alt="shoe-image">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- how yout sell -->



    <div class="tabular_data">
        <div class="container">
            <div class="tabular_data_container">
                <div class="heading_box">
                    <h1 class="tabular_text_title">Level Up & Enjoy The Benefits</h1>
                    <p>Whether you’re reselling a new purchase, growing a business, or creating a side-hustle,
                        we’ve developed an intelligent, global marketplace that works for anyone, anywhere.</p>
                </div>


                <table class="table table-bordered table-striped benefit_table">
                    <thead>
                        <tr>
                            <th></th>
                            <th>Level 1</th>
                            <th>Level 2</th>
                            <th>Level 3</th>
                            <th>Level 4</th>
                            <th>Level 5</th>
                        </tr>
                    </thead>
                    <tbody>                                
                        <tr>
                            <td>Sales Required</td>
                            <td>
                                <p>–</p>
                            </td>
                            <td>
                                <p>3</p>
                                <span>or</span>
                            </td>
                            <td>
                                <p>6</p>
                                <span>or</span>
                            </td>
                            <td>
                                <p>25</p>
                                <span>or</span>
                            </td>
                            <td>
                                <p>250</p>
                                <span>or</span>
                            </td>
                        </tr>
                        <tr>
                            <td>Sales ($) Required</td>
                            <td>
                                <p>–</p>
                            </td>
                            <td>
                                <p>$500</p>
                            </td>
                            <td>
                                <p>$1,500</p>
                            </td>
                            <td>
                                <p>$5,000</p>
                            </td>
                            <td>
                                <p>$30,000</p>
                            </td>
                        </tr>
                        <tr>
                            <td>Transaction Fee</td>
                            <td>
                                <p>10.0%</p>
                            </td>
                            <td>
                                <p>9.5%</p>
                            </td>
                            <td>
                                <p>9.0%</p>
                            </td>
                            <td>
                                <p>8.5%</p>
                            </td>
                            <td>
                                <p>8.0%</p>
                            </td>
                        </tr>
                        <tr>
                            <td>Rewards &amp; Advanced Features</td>
                            <td>
                                <p>–</p>
                            </td>
                            <td>
                                <p>–</p>
                            </td>
                            <td>
                                <p>–</p>
                            </td>
                            <td>
                                <ul class="record_unordered">
                                    <li>Eligible for up to 2.0% off seller fees via <a href="">Bonus
                                            Discounts</a></li>
                                    <li>Bulk Shipping (Available in certain countries/regions only)</li>
                                    <li>Early payouts (subject to restrictions)</li>
                                    <li>VIP account management (must have 500+ sales in a year)</li>
                                </ul>
                                <h5><a href="">Learn more about our advanced tools for power
                                            sellers</a></h5>
                            </td>
                            <td>
                                <ul class="record_unordered">
                                    <li>Eligible for up to 2.0% off seller fees via <a href="">Bonus
                                            Discounts</a></li>
                                    <li>Bulk Shipping (Available in certain countries/regions only)</li>
                                    <li>Early payouts (subject to restrictions)</li>
                                    <li>VIP account management (must have 500+ sales in a year)</li>
                                </ul>
                                <h5><a href="">Learn more about our advanced tools for power
                                            sellers</a></h5>
                            </td>
                        </tr>
                    </tbody>
                </table>
                

                <div class="faq-toggle">
                    <div class="item">
                        <div class="question">
                            <h4>Level 1</h4>
                            <!-- replace plus/minus icons here -->
                            <i class="fas fa-plus-circle"></i>
                            <i class="fas fa-minus-circle"></i>
                        </div>
                        <div class="answer">
                            <div class="record_list">
                                <div class="record_item">
                                    <p class="record_heading">Sales Required</p>
                                    <p>...</p>
                                </div>
                                <div class="record_item">
                                    <p class="record_heading">Sales ($) Required</p>
                                    <p>...</p>
                                </div>
                                <div class="record_item">
                                    <p class="record_heading">Transaction Fee</p>
                                    <p>...</p>
                                </div>
                                <div class="record_item">
                                    <p class="record_heading">Rewards & Advanced Features</p>
                                    <p>...</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="question">
                            <h4>Level 2</h4>
                            <i class="fas fa-plus-circle"></i>
                            <i class="fas fa-minus-circle"></i>
                        </div>
                        <div class="answer">
                            <div class="record_list">
                                <div class="record_item">
                                    <p class="record_heading">Sales Required</p>
                                    <p>3</p>
                                </div>
                                <div class="record_item">
                                    <p class="record_heading">Sales ($) Required</p>
                                    <p>$500</p>
                                </div>
                                <div class="record_item">
                                    <p class="record_heading">Transaction Fee</p>
                                    <p>9.5%</p>
                                </div>
                                <div class="record_item">
                                    <p class="record_heading">Rewards & Advanced Features</p>
                                    <p>...</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="question">
                            <h4>Level 3</h4>
                            <i class="fas fa-plus-circle"></i>
                            <i class="fas fa-minus-circle"></i>
                        </div>
                        <div class="answer">
                            <div class="record_list">
                                <div class="record_item">
                                    <p class="record_heading">Sales Required</p>
                                    <p>6</p>
                                </div>
                                <div class="record_item">
                                    <p class="record_heading">Sales ($) Required</p>
                                    <p>$1,500</p>
                                </div>
                                <div class="record_item">
                                    <p class="record_heading">Transaction Fee</p>
                                    <p>9.0%</p>
                                </div>
                                <div class="record_item">
                                    <p class="record_heading">Rewards & Advanced Features</p>
                                    <p>...</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="question">
                            <h4>Level 4</h4>
                            <i class="fas fa-plus-circle"></i>
                            <i class="fas fa-minus-circle"></i>
                        </div>
                        <div class="answer">
                            <div class="record_list">
                                <div class="record_item">
                                    <p class="record_heading">Sales Required</p>
                                    <p>25</p>
                                </div>
                                <div class="record_item">
                                    <p class="record_heading">Sales ($) Required</p>
                                    <p>$5,000</p>
                                </div>
                                <div class="record_item">
                                    <p class="record_heading">Transaction Fee</p>
                                    <p>8.5%</p>
                                </div>
                                <div class="record_item">
                                    <p class="record_heading">Rewards & Advanced Features</p>
                                    <ul class="record_unordered">
                                        <li>Eligible for up to 2.0% off seller fees via <a href="">Bonus
                                                Discounts</a></li>
                                        <li>Bulk Shipping (Available in certain countries/regions only)</li>
                                        <li>Early payouts (subject to restrictions)</li>
                                        <li>VIP account management (must have 500+ sales in a year)</li>
                                    </ul>
                                    <h5><a href="">
                                            Learn more about our advanced tools for power sellers
                                        </a></h5>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="question">
                            <h4>Level 5</h4>
                            <i class="fas fa-plus-circle"></i>
                            <i class="fas fa-minus-circle"></i>
                        </div>
                        <div class="answer">
                            <div class="record_list">
                                <div class="record_item">
                                    <p class="record_heading">Sales Required</p>
                                    <p>250</p>
                                </div>
                                <div class="record_item">
                                    <p class="record_heading">Sales ($) Required</p>
                                    <p>$30,000</p>
                                </div>
                                <div class="record_item">
                                    <p class="record_heading">Transaction Fee</p>
                                    <p>8.0%</p>
                                </div>
                                <div class="record_item">
                                    <p class="record_heading">Rewards & Advanced Features</p>
                                    <ul class="record_unordered">
                                        <li>Eligible for up to 2.0% off seller fees via <a href="">Bonus
                                                Discounts</a></li>
                                        <li>Bulk Shipping (Available in certain countries/regions only)</li>
                                        <li>Early payouts (subject to restrictions)</li>
                                        <li>VIP account management (must have 500+ sales in a year)</li>
                                    </ul>
                                    <h5><a href="">
                                            Learn more about our advanced tools for power sellers
                                        </a></h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <p class="text-center py-5 ">
                    Note: All sellers also have a 3% payment processing rate in addition to the StockX transaction rate. Your Seller level is determined by your sales activity (number of sales OR the total value of sales in USD) on StockX. Activity resets at the end of each calendar quarter, You must continue selling in order to maintain you Seller Level. For example, if you complete 20 sales in a given quarter, you will be in Seller Level 3 during the following quarter. However, if during that following quarter, you complete O sales, your Seller Level will revert back to Level 1 for the quarter after that, you can level up at any point mid-quarter once you reach the sales requirements for the next level.
                </p>
            </div>
        </div><!-- Toggle -->
        <div class="tabular_data_gradient"></div>
    </div><!-- Tablular Data -->



    <div class="catch-up">
        <div class="container">
            <h1 class="catch_up_text">Catch up with the latest developments</h1>
            <div class="catch_up_cards_list">
                <div class="catch_up_card">
                    <img src="{{asset('themes/auiskey/assets/img/products/red-white-shoe.jpg')}}" alt="red-white-shoe">
                    <h3>The Flip: The All Things Selling Newsletter</h3>
                    <p>We'll keep you informed on any updates we make at StockX.</p>
                    <a href="" class="read__more">Read More <span>+ + + + +</span></a>
                </div>
                <div class="catch_up_card">
                    <img src="{{asset('themes/auiskey/assets/img/products/shoes-colors.jpg')}}" alt="shoes">
                    <h3>Industry Trends & Insights</h3>
                    <p>Our collection of curated news will help you stay one step ahead of the game.</p>
                    <a href="" class="read__more">Read More <span>+ + + + +</span></a>
                </div>
            </div>
        </div>
        <div class="selling-pg__resources-headline">
            <p class="selling-pg__resources-headline-text">Resources</p>
            <p class="selling-pg__resources-headline-text">Resources</p>
            <p class="selling-pg__resources-headline-text">Resources</p>
        </div>
    </div>
    <!-- Catch Up with development -->


    <div class="faq-shop">
        <div class="container">
            <h1 class="faq-title">FAQ'S</h1>
            <div class="faqs">
                <div class="faq-card">
                    <p>What is a Bid, how do I buy on StockX?</p>
                    <p>There are two ways to buy on StockX: placing a bid or Buying Now. A Bid signals your...
                    </p>
                    <a href="" class="indication_right"><i class="far fa-arrow-right"></i></a>
                </div>
                <div class="faq-card">
                    <p>What is a Bid, how do I buy on StockX?</p>
                    <p>There are two ways to buy on StockX: placing a bid or Buying Now. A Bid signals your...
                    </p>
                    <a href="" class="indication_right"><i class="far fa-arrow-right"></i></a>
                </div>
                <div class="faq-card">
                    <p>What is a Bid, how do I buy on StockX?</p>
                    <p>There are two ways to buy on StockX: placing a bid or Buying Now. A Bid signals your...
                    </p>
                    <a href="" class="indication_right"><i class="far fa-arrow-right"></i></a>
                </div>
                <div class="faq-card">
                    <p>What is a Bid, how do I buy on StockX?</p>
                    <p>There are two ways to buy on StockX: placing a bid or Buying Now. A Bid signals your...
                    </p>
                    <a href="" class="indication_right"><i class="far fa-arrow-right"></i></a>
                </div>
                <div class="faq-card">
                    <p>What is a Bid, how do I buy on StockX?</p>
                    <p>There are two ways to buy on StockX: placing a bid or Buying Now. A Bid signals your...
                    </p>
                    <a href="" class="indication_right"><i class="far fa-arrow-right"></i></a>
                </div>
                <div class="faq-card">
                    <p>What is a Bid, how do I buy on StockX?</p>
                    <p>There are two ways to buy on StockX: placing a bid or Buying Now. A Bid signals your...
                    </p>
                    <a href="" class="indication_right"><i class="far fa-arrow-right"></i></a>
                </div>
                <div class="faq-card">
                    <p>What is a Bid, how do I buy on StockX?</p>
                    <p>There are two ways to buy on StockX: placing a bid or Buying Now. A Bid signals your...
                    </p>
                    <a href="" class="indication_right"><i class="far fa-arrow-right"></i></a>
                </div>
            </div>
            <div class="shop_faq">
                <h1 class="faq-title">SHOP</h1>
                <div class="shop-cards_list">
                    <a href="">
                        <div class="shop__img">
                            <img src="{{asset('themes/auiskey/assets/img/products/blue-shoe.png')}}" alt="blue-shoe">
                        </div>
                        <h4>Sneakers</h4>
                    </a>
                    <a href="">
                        <div class="shop__img">
                            <img src="{{asset('themes/auiskey/assets/img/products/streetwear.jpg')}}" alt="streetwear">
                        </div>
                        <h4>Streetwear</h4>
                    </a>
                    <a href="">
                        <div class="shop__img">
                            <img src="{{asset('themes/auiskey/assets/img/products/Electronics.jpg')}}" alt="Electronics">
                        </div>
                        <h4>Electronics</h4>
                    </a>
                    <a href="">
                        <div class="shop__img">
                            <img src="{{asset('themes/auiskey/assets/img/products/Collectibles.jpg')}}" alt="Collectibles">
                        </div>
                        <h4>Collectibles</h4>
                    </a>
                    <a href="">
                        <div class="shop__img">
                            <img src="{{asset('themes/auiskey/assets/img/products/Handbags.jpg')}}" alt="Handbags">
                        </div>
                        <h4>Sneakers</h4>
                    </a>
                    <a href="">
                        <div class="shop__img">
                            <img src="{{asset('themes/auiskey/assets/img/products/Watches.jpg')}}" alt="Watches">
                        </div>
                        <h4>Sneakers</h4>
                    </a>
                </div>
            </div>
        </div>
    </div><!-- Faq-shop -->
</section>
@endsection