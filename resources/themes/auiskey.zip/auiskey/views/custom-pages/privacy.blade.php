@extends('shop::layouts.master')

@section('full-content-wrapper')
<section class="privacy-policy">
            <div class="css-1ezbodh">
                <div class="css-1fhn9bq">
                    <div class="container">
                        <h1 class="chakra-heading css-142re05">StockX Privacy Policy - Your Privacy Rights</h1>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="privacy_policy_sec">
                    <p>By visiting the website owned or operated by LEERDO and located at the URL: www.Leerdo.com (the "Site"), you agree to accept the practices described in this privacy policy (the "Privacy Policy"). If you do not agree to the terms of this Privacy Policy, please do not use the Site. LEERDO reserves the right to modify this Privacy Policy at any time, so each time you use the Site, you should check this Privacy Policy and review any changes that have been made since your last visit to the Site.</p>
                    <p>LEERDO understands the importance of your privacy, and that you have a right to control how your personal information is collected and used. We also understand that supplying personal information is an act of trust and we take that seriously.</p>


                    <h2>WHAT DO WE COLLECT?</h2>
                    <p>LEERDO collect the following personal information from you:</p>
                    <ul>
                        <li>- your name and contact details (e.g. address, phone number)</li>
                        <li>- other information that you will supply to us</li>
                    </ul>

                    <p>Information collected by cookies and web beacons may include, without limitation:</p>

                    <ul>
                        <li>- the pages you visit within the Site;</li>
                        <li>- the date and time of your visit to the Site;</li>
                        <li>- the websites you visit before or after visiting the Site;</li>
                        <li>- the Internet Protocol (IP) address used to connect your computer to the Internet;</li>
                        <li>- your computer and connection information such as your browser type and version, operating system and platform;</li>
                        <li>- whether you open and whether you click on any link contained in an email message that we send you; and/or</li>
                        <li>- your purchase history.</li>
                    </ul>

                    <p><strong>LEERDO</strong> also collects the following information that you may not be aware of:</p>
                    <ul>
                        <li>- the name of the domain from which you access the internet</li>
                        <li>- the date and time you access our site</li>
                        <li>- the internet address of the website from which you linked directly to our site</li>
                    </ul>


                    <h2>WHY DO WE COLLECT?</h2>
                    <p>Our purpose in collecting information about you is to provide you with the best shopping experience, make improvements for you and to identify your purchases. We may also notify you with relevant consumer information, notify you of products, promotions, events and special offers that may be of interest to you as a valued LEERDO customer.</p>


                    <h2>SECURITY</h2>
                    <p>LEERDO uses security measures to protect the information you provide us.</p>
                    <p>Please be aware that no internet data transmission can be guaranteed to be 100% secure from access by unintended recipient. LEERDO will not be responsible for events arising unauthorized access to your personal information.</p>


                    <h2>IS MY INFORMATION SHARED WITH THIRD PARTIES?</h2>
                    <p>Your personal information (e.g. email addresses or postal addresses) collected online will only be disclosed to us and is not shared, sold or traded with any other unrelated parties.</p>


                    <h2>CAN I ACCESS MY PERSONAL INFORMATION?</h2>
                    <p>You may review, change or delete personal information held by LEERDO at any time. You may do this by logging into ‘my account’ or simply sending us an email at theleerdo@gmail.com If you have discovered and notified us that there is an error or information missing, we will endeavour to correct the information as soon as possible.</p>

                </div>
            </div>
        </section>

@endsection