@extends('shop::layouts.master')

@section('full-content-wrapper')
<section id="about">

<div id="about-banner" style="background-image:url({{asset('themes/auiskey/assets/img/brands/about-banner.png')}})">
    <div class="container">
        <div class="collections">
            <div class="collection-twins">
                <div class="collection-text">
                    <h1>The Current Culture Marketplace</h1>
                    <p>Our mission is to provide access to the world's most coveted items in the smartest
                        way possible. Buy and sell the hottest sneakers, apparel, electronics, collectibles,
                        trading cards and accessories.</p>
                </div>
                <div class="collection-img">
                    <img src="{{asset('themes/auiskey/assets/img/socials/collections.png')}}" alt="collection-imgea">
                </div>
            </div>
            <div class="collections-links">
                <a href="">Authentication <i class="fas fa-chevron-right"></i></a>
                <a href="">Buyers <i class="fas fa-chevron-right"></i></a>
                <a href="">Sellers <i class="fas fa-chevron-right"></i></a>
            </div>
        </div>
    </div>
</div><!-- About Main Banner -->

<div class="about-info">
    <div class="container">
        <div class="information-container">
            <div class="info-box">
                <img src="{{asset('themes/auiskey/assets/img/socials/ab-shoe.png')}}" alt="shoe">
                <p class="info-title-text">100% Verified Authentic</p>
                <p>Every item sold goes through our proprietary multi-step verification process with our
                    team of expert authenticators.</p>
            </div>
            <div class="info-box">
                <img src="{{asset('themes/auiskey/assets/img/socials/ab-analysis.png')}}" alt="analysis">
                <p class="info-title-text">Transparent Pricing</p>
                <p>Our real-time marketplace works just like the stock market - allowing you ot buy and sell
                    the most coveted items at their true market price.</p>
            </div>
            <div class="info-box">
                <img src="{{asset('themes/auiskey/assets/img/socials/ab-world.png')}}" alt="world">
                <p class="info-title-text">Global Access</p>
                <p>Whether it's pre-release, regionally limited, or "sold out" - our millions of customers
                    from over 200+ coutires allow you to easily secure those hard-to-find.</p>
            </div>
            <div class="info-box">
                <img src="{{asset('themes/auiskey/assets/img/socials/ab-shoe.png')}}" alt="customer">
                <p class="info-title-text">No BS</p>
                <p>Every item sold goes through our proprietary multi-step verification process with our
                    team of expert authenticators.</p>
            </div>
            <div class="info-box">
                <img src="{{asset('themes/auiskey/assets/img/socials/ab-mark.png')}}" alt="security">
                <p class="info-title-text">Secure</p>
                <p>Our real-time marketplace works just like the stock market - allowing you ot buy and sell
                    the most coveted items at their true market price.</p>
            </div>
            <div class="info-box">
                <img src="{{asset('themes/auiskey/assets/img/socials/ab-people.png')}}" alt="peoples">
                <p class="info-title-text">Here For You</p>
                <p>Whether it's pre-release, regionally limited, or "sold out" - our millions of customers
                    from over 200+ coutires allow you to easily secure those hard-to-find.</p>
            </div>

        </div>
    </div>
</div><!-- about info -->


<div class="about-buy_sell">
    <div class="container">
        <div class="about__buy_set">
            <div class="about__buy">
                <h1>Buy</h1>
                <div class="buy__list">
                    <span class="box_circle">1</span>
                    <p>Place A Bid Or Buy Now</p>
                </div>
                <div class="buy__list buy__arrow">
                    <i class="fas fa-arrow-down"></i>
                </div>
                <div class="buy__list">
                    <span class="box_circle">1</span>
                    <p>Place A Bid Or Buy Now</p>
                </div>
                <div class="buy__arrow">
                    <i class="fas fa-arrow-down"></i>
                </div>
                <div class="buy__list">
                    <span class="box_circle">1</span>
                    <p>Place A Bid Or Buy Now</p>
                </div>
            </div>
            <div class="about__sell">
                <div class="sell-container">
                    <h1>Sell</h1>
                    <div class="buy__list">
                        <span class="box_circle">1</span>
                        <p>Place A Bid Or Buy Now</p>
                    </div>
                    <div class="buy__arrow">
                        <i class="fas fa-arrow-down"></i>
                    </div>
                    <div class="buy__list">
                        <span class="box_circle">1</span>
                        <p>Place A Bid Or Buy Now</p>
                    </div>
                    <div class="buy__arrow">
                        <i class="fas fa-arrow-down"></i>
                    </div>
                    <div class="buy__list">
                        <span class="box_circle">1</span>
                        <p>Place A Bid Or Buy Now</p>
                    </div>
                </div>
                <div class="sell-image-container">
                    <img src="{{asset('themes/auiskey/assets/img/socials/collection-type-1.png')}}" alt="collection">
                </div>
            </div>
        </div>
    </div>
</div><!-- about-buy_sell -->


<div class="power">
    <div class="container">                    
        <div class="row">
            <h1 class="text-center">The Power's In Your Hands</h1>
            <div class="col-md-4 col-sm-6 left_box">
                <h3>Buying On StockX</h3>
                <p>We don't determine the price, you do. As a live marketplace, StockX empowers you to Bid and Buy at real-time prices that reflect the current demand.</p>
            </div>
            <div class="col-md-4 col-sm-6 left_box">
                <h3>Selling on StockX</h3>
                <p>Whether you're looking to make quick cash or start a reselling business, we have the tools to help you</p>
            </div>
            <div class="col-md-4 col-sm-6">
                <div class="animated-container">
                    <img src="{{asset('themes/auiskey/assets/img/socials/animation-grid.gif')}}" alt="animate image">
                    <img src="{{asset('themes/auiskey/assets/img/socials/clutch.png')}}" alt="clutch" class="img-clutch">
                </div>
            </div>
        </div>
    </div>
</div><!-- The Power In your hand -->


<div class="testimonials">
                <div class="test_img">
                    <img src="{{ asset('themes/auiskey/assets/img/socials/dots.png') }}" alt="dots">
                </div>
                <div class="container">
                    <div class="test_text">
                        <h1>What people have to say about StockX</h1>
                    </div>
                    <div class="testimonials-owl owl-carousel owl-theme">
                        <div class="item">
                            <div class="testimonials__card">
                                <div class="test_icon">
                                    <i class="fab fa-twitter"></i>
                                </div>
                                <div class="test_message">
                                    <p>So hope. Copped Under retail and got them 3 days!</p>
                                    <p>#GotItOnStockX</p>
                                </div>
                                <div class="test_person">
                                    <p>TheEndGuyTEG</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimonials__card">
                                <div class="test_icon">
                                    <i class="fab fa-twitter"></i>
                                </div>
                                <div class="test_message">
                                    <p>So hope. Copped Under retail and got them 3 days!</p>
                                    <p>#GotItOnStockX</p>
                                </div>
                                <div class="test_person">
                                    <p>TheEndGuyTEG</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimonials__card">
                                <div class="test_icon">
                                    <i class="fab fa-twitter"></i>
                                </div>
                                <div class="test_message">
                                    <p>So hope. Copped Under retail and got them 3 days!</p>
                                    <p>#GotItOnStockX</p>
                                </div>
                                <div class="test_person">
                                    <p>TheEndGuyTEG</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimonials__card">
                                <div class="test_icon">
                                    <i class="fab fa-twitter"></i>
                                </div>
                                <div class="test_message">
                                    <p>So hope. Copped Under retail and got them 3 days!</p>
                                    <p>#GotItOnStockX</p>
                                </div>
                                <div class="test_person">
                                    <p>TheEndGuyTEG</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimonials__card">
                                <div class="test_icon">
                                    <i class="fab fa-twitter"></i>
                                </div>
                                <div class="test_message">
                                    <p>So hope. Copped Under retail and got them 3 days!</p>
                                    <p>#GotItOnStockX</p>
                                </div>
                                <div class="test_person">
                                    <p>TheEndGuyTEG</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimonials__card">
                                <div class="test_icon">
                                    <i class="fab fa-twitter"></i>
                                </div>
                                <div class="test_message">
                                    <p>So hope. Copped Under retail and got them 3 days!</p>
                                    <p>#GotItOnStockX</p>
                                </div>
                                <div class="test_person">
                                    <p>TheEndGuyTEG</p>
                                </div>
                            </div>
                        </div>
                    </div><!-- Testimonials Owl Carousel -->
                </div>
            </div><!-- Testimonials -->


            <div class="faq-shop">
                <div class="container">
                    <h1 class="faq-title">FAQ'S</h1>
                    <div class="faqs">
                        <div class="faq-card">
                            <p>What is a Bid, how do I buy on StockX?</p>
                            <p>There are two ways to buy on StockX: placing a bid or Buying Now. A Bid signals your...</p>
                            <a href="" class="indication_right"><i class="far fa-arrow-right"></i></a>
                        </div>
                        <div class="faq-card">
                            <p>What is a Bid, how do I buy on StockX?</p>
                            <p>There are two ways to buy on StockX: placing a bid or Buying Now. A Bid signals your...</p>
                            <a href="" class="indication_right"><i class="far fa-arrow-right"></i></a>
                        </div>
                        <div class="faq-card">
                            <p>What is a Bid, how do I buy on StockX?</p>
                            <p>There are two ways to buy on StockX: placing a bid or Buying Now. A Bid signals your...</p>
                            <a href="" class="indication_right"><i class="far fa-arrow-right"></i></a>
                        </div>
                        <div class="faq-card">
                            <p>What is a Bid, how do I buy on StockX?</p>
                            <p>There are two ways to buy on StockX: placing a bid or Buying Now. A Bid signals your...</p>
                            <a href="" class="indication_right"><i class="far fa-arrow-right"></i></a>
                        </div>
                        <div class="faq-card">
                            <p>What is a Bid, how do I buy on StockX?</p>
                            <p>There are two ways to buy on StockX: placing a bid or Buying Now. A Bid signals your...</p>
                            <a href="" class="indication_right"><i class="far fa-arrow-right"></i></a>
                        </div>
                        <div class="faq-card">
                            <p>What is a Bid, how do I buy on StockX?</p>
                            <p>There are two ways to buy on StockX: placing a bid or Buying Now. A Bid signals your...</p>
                            <a href="" class="indication_right"><i class="far fa-arrow-right"></i></a>
                        </div>
                        <div class="faq-card">
                            <p>What is a Bid, how do I buy on StockX?</p>
                            <p>There are two ways to buy on StockX: placing a bid or Buying Now. A Bid signals your...</p>
                            <a href="" class="indication_right"><i class="far fa-arrow-right"></i></a>
                        </div>
                    </div>
                    <div class="shop_faq">
                        <h1 class="faq-title">SHOP</h1>
                        <div class="shop-cards_list">
                            <a href="">
                                <div class="shop__img">
                                    <img src="{{ asset('themes/auiskey/assets/img/products/blue-shoe.png') }}" alt="blue-shoe">                                    
                                </div>                 
                                <h4>Sneakers</h4>           
                            </a>
                            <a href="">
                                <div class="shop__img">
                                    <img src="{{ asset('themes/auiskey/assets/img/products/streetwear.jpg') }}" alt="streetwear">                                    
                                </div>                 
                                <h4>Streetwear</h4>           
                            </a>
                            <a href="">
                                <div class="shop__img">
                                    <img src="{{ asset('themes/auiskey/assets/img/products/Electronics.jpg') }}" alt="Electronics">                                    
                                </div>                 
                                <h4>Electronics</h4>           
                            </a>
                            <a href="">
                                <div class="shop__img">
                                    <img src="{{ asset('themes/auiskey/assets/img/products/Collectibles.jpg') }}" alt="Collectibles">                                    
                                </div>                 
                                <h4>Collectibles</h4>           
                            </a>
                            <a href="">
                                <div class="shop__img">
                                    <img src="{{ asset('themes/auiskey/assets/img/products/Handbags.jpg') }}" alt="Handbags">                                    
                                </div>                 
                                <h4>Sneakers</h4>           
                            </a>
                            <a href="">
                                <div class="shop__img">
                                    <img src="{{ asset('themes/auiskey/assets/img/products/Watches.jpg') }}" alt="Watches">                                    
                                </div>                 
                                <h4>Sneakers</h4>           
                            </a>
                        </div>
                    </div>
                </div>
            </div>
</section>    
@endsection