@extends('shop::layouts.master')

@section('full-content-wrapper')
<section class="buying_sec" id="about">

<div class="selling-banner" id="about-banner" style="background-image:url({{asset('themes/auiskey/assets/img/brands/about-banner.png')}})">
    <div class="container">
        <div class="selling_poster_sec">
            <div class="buying_stock selling_stock">
                <p>BUYING ON STOCKX</p>
                <h1>Buying Grails Has Never Been Easier</h1>
            </div>
            <div class="selling_image">
                <img src="{{asset('themes/auiskey/assets/img/gallery/girl-image.jpg')}}" alt="girl image">
            </div>
        </div>
    </div>
</div><!-- Selling Main Banner -->

<div class="start_buying start_selling">
    <div class="container">
        <div class="selling_listing">
            <div class="buying__items selling__items">
                <div class="buying_img selling_img">
                    <img src="{{asset('themes/auiskey/assets/img/socials/wallet-cash.png')}}" alt="wallet-cash-icon">
                </div>
                <div class="selling_description">
                    <h3>Price is at your hands</h3>
                    <p>Buy now at the lowest ask or place a bid at a lower price to bid for the item you want. All updates will be sent to you such as update to price, outbid and acceptance of bid. Bid can be edited/renewed/cancelled anytime at your own convenience.</p>
                </div>
            </div>
            <div class="buying__items selling__items">
                <div class="buying_img selling_img">
                    <img src="{{asset('themes/auiskey/assets/img/socials/ab-world.png')}}" alt="world_map_icon">
                </div>
                <div class="selling_description">
                    <h3>Worldwide marketplace</h3>
                    <p>Browse and shop items you love from around the globe even if it is sold out. Exclusive sneakers, clothing, accessories, consoles, trading card, watches and many more will be available for purchase or bided on in our marketplace.</p>
                </div>
            </div>
            <div class="buying__items selling__items">
                <div class="buying_img selling_img">
                    <img src="{{asset('themes/auiskey/assets/img/socials/wallet-cash.png')}}" alt="wallet-cash-icon">
                </div>
                <div class="selling_description">
                    <h3>Real time data</h3>
                    <p>Stay up to date with current data to help make the right pucrases. View data such as previous prices and time-stamped trade for all items  to help you shop with a ease of mind.</p>
                </div>
            </div>
            <div class="buying__items selling__items">
                <div class="buying_img selling_img">
                    <img src="{{asset('themes/auiskey/assets/img/socials/check-mark-sign.png')}}" alt="check-mark-sign_icon">
                </div>
                <div class="selling_description">
                    <h3>Guaranteed authenticity</h3>
                    <p>Our team of professional authenticator will all items with the best data and hands on inspection of all items. They will make it their main prority to ensure every item you purchase are 100% authentic and brand new before we ship it out.</p>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="three_step">
    <div class="container">
        <h1 class="three_step_text">3 STEPS FOR AWESOMENESS</h1>
        <div class="three_step_list">
            <div class="step_item step_odd_item">
                <div class="step_item_img">
                    <img src="{{asset('themes/auiskey/assets/img/products/red-shoes-250.png')}}" alt="red-shoes-250">
                </div>
                <div class="step_text_box">
                    <h1>01</h1>
                    <h3>BUY OR bid</h3>
                    <p>Bid at the price you want or buy at the lowest ask price from our amazing real-time marketplace to secure your item anytime.</p>
                </div>
            </div>
            <div class="step_item step_even_item">
                <div class="step_text_box">
                    <h1>02</h1>
                    <h3>Let us do our job</h3>
                    <p>Once you purchase we will make sure your items are shipped ASAP to us for verification. Once we verify the items you purchased are authentic we will send it your way. Our average delivery time is 7-14 business days from order date.</p>
                </div>
                <div class="step_item_img">
                    <img src="{{asset('themes/auiskey/assets/img/products/authenticate-delievery.png')}}" alt="authenticate-delievery">
                </div>
            </div>
            <div class="step_item step_odd_item">
                <div class="step_item_img">
                    <img src="{{asset('themes/auiskey/assets/img/gallery/black-boy.jpg')}}" alt="black-boy">
                </div>
                <div class="step_text_box">
                    <h1>03</h1>
                    <h3>Flex it hard</h3>
                    <p>Once your item arrive flex it on everyone by tagging us @aullad on all social media platform. We will see you next order</p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- 3 step success -->


<div class="faq-shop">
    <div class="container">
        <div class="video_container">
            <iframe width="560" height="315" src="https://www.youtube.com/embed/AEM1e0d1NP0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        </div>
        <!-- video -->
        <h1 class="faq-title">FAQ'S</h1>
        <div class="faqs">
            <div class="faq-card">
                <p>What is a Bid, how do I buy on StockX?</p>
                <p>There are two ways to buy on StockX: placing a bid or Buying Now. A Bid signals your...</p>
                <a href="" class="indication_right"><i class="far fa-arrow-right"></i></a>
            </div>
            <div class="faq-card">
                <p>What is a Bid, how do I buy on StockX?</p>
                <p>There are two ways to buy on StockX: placing a bid or Buying Now. A Bid signals your...</p>
                <a href="" class="indication_right"><i class="far fa-arrow-right"></i></a>
            </div>
            <div class="faq-card">
                <p>What is a Bid, how do I buy on StockX?</p>
                <p>There are two ways to buy on StockX: placing a bid or Buying Now. A Bid signals your...</p>
                <a href="" class="indication_right"><i class="far fa-arrow-right"></i></a>
            </div>
            <div class="faq-card">
                <p>What is a Bid, how do I buy on StockX?</p>
                <p>There are two ways to buy on StockX: placing a bid or Buying Now. A Bid signals your...</p>
                <a href="" class="indication_right"><i class="far fa-arrow-right"></i></a>
            </div>
            <div class="faq-card">
                <p>What is a Bid, how do I buy on StockX?</p>
                <p>There are two ways to buy on StockX: placing a bid or Buying Now. A Bid signals your...</p>
                <a href="" class="indication_right"><i class="far fa-arrow-right"></i></a>
            </div>
            <div class="faq-card">
                <p>What is a Bid, how do I buy on StockX?</p>
                <p>There are two ways to buy on StockX: placing a bid or Buying Now. A Bid signals your...</p>
                <a href="" class="indication_right"><i class="far fa-arrow-right"></i></a>
            </div>
            <div class="faq-card">
                <p>What is a Bid, how do I buy on StockX?</p>
                <p>There are two ways to buy on StockX: placing a bid or Buying Now. A Bid signals your...</p>
                <a href="" class="indication_right"><i class="far fa-arrow-right"></i></a>
            </div>
        </div>
        <div class="shop_faq">
            <h1 class="faq-title">SHOP</h1>
            <div class="shop-cards_list">
                <a href="">
                    <div class="shop__img">
                        <img src="{{asset('themes/auiskey/assets/img/products/blue-shoe.png')}}" alt="blue-shoe">                                    
                    </div>                 
                    <h4>Sneakers</h4>           
                </a>
                <a href="">
                    <div class="shop__img">
                        <img src="{{asset('themes/auiskey/assets/img/products/streetwear.jpg')}}" alt="streetwear">                                    
                    </div>                 
                    <h4>Streetwear</h4>           
                </a>
                <a href="">
                    <div class="shop__img">
                        <img src="{{asset('themes/auiskey/assets/img/products/Electronics.jpg')}}" alt="Electronics">                                    
                    </div>                 
                    <h4>Electronics</h4>           
                </a>
                <a href="">
                    <div class="shop__img">
                        <img src="{{asset('themes/auiskey/assets/img/products/Collectibles.jpg')}}" alt="Collectibles">                                    
                    </div>                 
                    <h4>Collectibles</h4>           
                </a>
                <a href="">
                    <div class="shop__img">
                        <img src="{{asset('themes/auiskey/assets/img/products/Handbags.jpg')}}" alt="Handbags">                                    
                    </div>                 
                    <h4>Sneakers</h4>           
                </a>
                <a href="">
                    <div class="shop__img">
                        <img src="{{asset('themes/auiskey/assets/img/products/Watches.jpg')}}" alt="Watches">                                    
                    </div>                 
                    <h4>Sneakers</h4>           
                </a>
            </div>
        </div>
    </div>
</div><!-- Faq-shop -->
</section>

@endsection