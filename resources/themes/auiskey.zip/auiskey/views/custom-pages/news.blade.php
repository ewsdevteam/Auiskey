@extends('shop::layouts.master')

@section('content-wrapper')
    <section id="latest-news-banner">
        <div class="container">
            <div class="latest-news-slider">
                <h1 class="latest-news-title">STOCKX</h1>
                <h1 class="latest-news-subtitle">Changing the Game</h1>
                <p>Buyers and sellers have been the heart of StockX since 2016. In celebration of this year's of StockX Day, let's take a look back at how our community has changed - and continues to change - the game.</p>
                <a href="">READ ON</a>
            </div>
        </div>
    </section>
@endsection

@section('full-content-wrapper')
<section id="visiting-voice">
        <div class="visiting-voice-container">
            <div class="slider-controles">
                <img src="{{asset('themes/auiskey/assets/img/components/shape-1.png')}}" alt="shape">
            </div>
            <div class="vv-slider-container">
                <div class="vv-slider-title">
                    <h1>Visiting Voices, Powerful Messages</h1>
                </div>
                <div class="vv-slider visiting-voice-slider owl-carousel owl-theme">
                    <div class="vv-profile-bdr">
                        <div class="profile-vv">
                            <div class="vv-img">
                                <img src="{{asset('themes/auiskey/assets/img/ali-hussain.jpg')}}" alt="ali-hussain-man">
                            </div>
                            <div class="vv-title">
                                <h3>ali hussain</h3>
                                <p>kickstaw store</p>
                            </div>
                        </div>
                    </div>
                    <div class="vv-profile-bdr">
                        <div class="profile-vv">
                            <div class="vv-img">
                                <img src="{{asset('themes/auiskey/assets/img/visiting-voice.jpg')}}" alt="visiting-voices-woman">
                            </div>
                            <div class="vv-title">
                                <h3>visiting voices</h3>
                                <p>jezerai allen-lord</p>
                            </div>
                        </div>
                    </div>
                    <div class="vv-profile-bdr">
                        <div class="profile-vv">
                            <div class="vv-img">
                                <img src="{{asset('themes/auiskey/assets/img/visiting-voice.jpg')}}" alt="visiting-voices-woman">
                            </div>
                            <div class="vv-title">
                                <h3>visiting voices</h3>
                                <p>jezerai allen-lord</p>
                            </div>
                        </div>
                    </div>
                    <div class="vv-profile-bdr">
                        <div class="profile-vv">
                            <div class="vv-img">
                                <img src="{{asset('themes/auiskey/assets/img/grish-yoyo.jpg')}}" alt="grish-yoyo-men">
                            </div>
                            <div class="vv-title">
                                <h3>grish yoyo</h3>
                                <p>Ovuvuevuevue Enyetuenwuevu store</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section><!-- End. visiting voice slier -->


    <section id="latest-news">
        <div class="container">
            
            <div class="search-news">
                <a href=""><i class="far fa-search"></i></a>
                <form action="">
                    <input type="text" class="search-input" placeholder="What's your top pick of the season?">
                </form>
            </div>
        </div>

            <div class="best-shoes">
                <div class="container">
                    <div class="best-shoes-bg">
                        <div class="best-shoes-container">
                            <div class="shoes-text-container">
                                <h1>The Best <br />White Shoes<br />On StockX</h1>
                                <p>From Jordan to Yeezy, expensive to affordable, we're taking a look at the best white shoes available on StockX.</p>
                                <a href="" class="btn-shoes">Read More</a>
                            </div>
                            <div class="shoes-cont">
                                <div class="shoes-img-container">
                                    <div class="shoe-img">
                                        <img src="{{asset('themes/auiskey/assets/img/components/shoe.png')}}" alt="shoe-img">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>                    
                </div>
            </div><!-- End. Best Shoes -->

            <div class="top-games">
                <div class="container">
                    <div class="best-game-bg">
                        <div class="top-games-container best-shoes-container">                            
                            <div class="shoes-cont">
                                <div class="shoes-img-container games-img-container">
                                    <div class="shoe-img game-img">
                                        <img src="{{asset('themes/auiskey/assets/img/components/remote-controller.png')}}" alt="remote-controller-img">
                                    </div>
                                </div>
                            </div>
                            <div class="shoes-text-container">
                                <h1>The Top Games <br />of E3 2021</h1>
                                <p>While countless games were shown off at E3 2021, some developers stole the show with the top games after an unprecedented year for the gaming community.</p>
                                <a href="" class="btn-shoes">Read More</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- End. Best Games -->

            <div class="latest-stories">
                <div class="latest-stories-text">
                    <h1>the lastes stories</h1>
                    <p>from our community</p>
                </div>
                <div class="latest-stories-slider">
                    <div class="latest-story">
                        <div class="topside-story">
                            <a href=""><img src="{{asset('themes/auiskey/assets/img/gallery/shoe-3.png')}}" alt="shoe-img-3"></a>
                        </div>
                        <div class="downside-story">
                            <a href=""><img src="{{asset('themes/auiskey/assets/img/gallery/shoe-8.png')}}" alt="shoe-img-8"></a>
                        </div>
                    </div>
                    <div class="latest-story">
                        <div class="topside-story">
                            <a href=""><img src="{{asset('themes/auiskey/assets/img/gallery/shoe-4.png')}}" alt="shoe-img-4"></a>
                        </div>
                        <div class="downside-story">
                            <a href=""><img src="{{asset('themes/auiskey/assets/img/gallery/shoe-9.png')}}" alt="shoe-img-9"></a>
                        </div>
                    </div>
                    <div class="latest-story">
                        <div class="topside-story">
                            <a href=""><img src="{{asset('themes/auiskey/assets/img/gallery/shoe-5.png')}}" alt="shoe-img-5"></a>
                        </div>
                        <div class="downside-story">
                            <a href=""><img src="{{asset('themes/auiskey/assets/img/gallery/shoe-10.png')}}" alt="shoe-img-10"></a>
                        </div>
                    </div>
                    <div class="latest-story">
                        <div class="topside-story">
                            <a href=""><img src="{{asset('themes/auiskey/assets/img/gallery/shoe-1.png')}}" alt="shoe-img-1"></a>
                        </div>
                        <div class="downside-story">
                            <a href=""><img src="{{asset('themes/auiskey/assets/img/gallery/shoe-6.png')}}" alt="shoe-img-6"></a>
                        </div>
                    </div>
                    <div class="latest-story">
                        <div class="topside-story">
                            <a href=""><img src="{{asset('themes/auiskey/assets/img/gallery/shoe-2.png')}}" alt="shoe-img-2"></a>
                        </div>
                        <div class="downside-story">
                            <a href=""><img src="{{asset('themes/auiskey/assets/img/gallery/shoe-7.png')}}" alt="shoe-img-7"></a>
                        </div>
                    </div>


                    <div class="latest-story">
                        <div class="topside-story">
                            <a href=""><img src="{{asset('themes/auiskey/assets/img/gallery/shoe-3.png')}}" alt="shoe-img-3"></a>
                        </div>
                        <div class="downside-story">
                            <a href=""><img src="{{asset('themes/auiskey/assets/img/gallery/shoe-8.png')}}" alt="shoe-img-8"></a>
                        </div>
                    </div>
                    <div class="latest-story">
                        <div class="topside-story">
                            <a href=""><img src="{{asset('themes/auiskey/assets/img/gallery/shoe-4.png')}}" alt="shoe-img-4"></a>
                        </div>
                        <div class="downside-story">
                            <a href=""><img src="{{asset('themes/auiskey/assets/img/gallery/shoe-9.png')}}" alt="shoe-img-9"></a>
                        </div>
                    </div>
                    <div class="latest-story">
                        <div class="topside-story">
                            <a href=""><img src="{{asset('themes/auiskey/assets/img/gallery/shoe-5.png')}}" alt="shoe-img-5"></a>
                        </div>
                        <div class="downside-story">
                            <a href=""><img src="{{asset('themes/auiskey/assets/img/gallery/shoe-10.png')}}" alt="shoe-img-10"></a>
                        </div>
                    </div>
                    <div class="latest-story">
                        <div class="topside-story">
                            <a href=""><img src="{{asset('themes/auiskey/assets/img/gallery/shoe-1.png')}}" alt="shoe-img-1"></a>
                        </div>
                        <div class="downside-story">
                            <a href=""><img src="{{asset('themes/auiskey/assets/img/gallery/shoe-6.png')}}" alt="shoe-img-6"></a>
                        </div>
                    </div>
                    <div class="latest-story">
                        <div class="topside-story">
                            <a href=""><img src="{{asset('themes/auiskey/assets/img/gallery/shoe-2.png')}}" alt="shoe-img-2"></a>
                        </div>
                        <div class="downside-story">
                            <a href=""><img src="{{asset('themes/auiskey/assets/img/gallery/shoe-7.png')}}" alt="shoe-img-7"></a>
                        </div>
                    </div>
                </div>                
            </div>
            <!-- End. The Latest Stories -->
    </section>
    
@endsection