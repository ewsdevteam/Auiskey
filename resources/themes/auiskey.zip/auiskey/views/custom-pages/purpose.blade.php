@extends('shop::layouts.master')

@section('full-content-wrapper')
<div class="purpose_sec101">
            <div class="container">
                <div class="purpose_container">
                    <div class="purpose_left_textarea">
                        <div class="porpose_txt_container">
                            <h2>To ensure all buyer/seller can buy and sell safely in our marketplace </h2>
                        </div>
                        <div class="stroke_line_text">
                            <p>PURPOSE</p>
                            <p>PURPOSE</p>
                            <p>PURPOSE</p>
                        </div>
                    </div>
                    <div class="purpose_img_box">
                        <div class="purpose_img">
                            <img src="{{asset('themes/auiskey/assets/img/gallery/collection_sell_purchase.jpg')}}" alt="collection_sell_purchase">
                        </div>
                    </div>
                    <div class="stroke_line_text vision_text_stroke_cont_plus">
                        <p>+++++</p>
                    </div>
                </div>


                <div class="purpose_container">
                    <div class="purpose_img_box">
                        <div class="vision_img purpose_img">
                            <img src="{{asset('themes/auiskey/assets/img/gallery/vision.jpg')}}" alt="vision">
                        </div>
                    </div>
                    <div class="purpose_left_textarea">
                        <div class="vision_txt_container porpose_txt_container">
                            <h2>To the world best e-commerce marketplace for people to shop the current trend</h2>
                        </div>
                        <div class="stroke_line_text vision_text_stroke_cont">
                            <p>VISION</p>
                            <p>VISION</p>
                            <p>VISION</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="listing201">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="list201">
                            <h2>Core value</h2>
                            <p>Doing the right thing – truth, authenticity and transparency. Doing things the right and
                                best way.</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="list201">
                            <h2>Customer friendly </h2>
                            <p>Always open to suggestion and understanding what you need to create an experience for our
                                customer that they will never forget.</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="list201">
                            <h2>Hungry for success</h2>
                            <p>We need to learn grow and evolve. Pushing our self to our limit everyday to ensure we are
                                at the top</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="list201">
                            <h2>Create a legeacy</h2>
                            <p>We are always getting better items, better marketplace by being the best in the game.
                                making a legacy which can never be toppled and perish.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="leadership">
            <div class="leadership_bg_text">
                <p>Leadership</p>
            </div>
            <div class="container">
                <div class="our_leaders">
                    <div class="our_leader_text_headline">
                        <h1>Our Leadership</h1>
                    </div>
                    <div class="our_leader_individual">
                        <div class="our_leader_img">
                            <a href="">
                                <div class="img_leader">
                                    <img src="{{asset('themes/auiskey/assets/img/gallery/leader-1.jpg')}}" alt="leader image">
                                </div>
                                <h3>Scott Cutler</h3>
                                <p>CHIEF EXECUTIVE OFFICER</p>
                            </a>
                        </div>
                        <div class="our_leader_img">
                            <a href="">
                                <div class="img_leader">
                                    <img src="{{asset('themes/auiskey/assets/img/gallery/leader-2.jpg')}}" alt="leader image">
                                </div>
                                <h3>Greg Schwartz</h3>
                                <p>CHIEF OPERATING OFFICER AND CO-FOUNDER</p>
                            </a>
                        </div>
                        <div class="our_leader_img">
                            <a href="">
                                <div class="img_leader">
                                    <img src="{{asset('themes/auiskey/assets/img/gallery/leader-3.jpg')}}" alt="leader image">
                                </div>
                                <h3>Deena Bahri</h3>
                                <p>CHIEF MARKETING OFFICER</p>
                            </a>
                        </div>
                        <div class="our_leader_img">
                            <a href="">
                                <div class="img_leader">
                                    <img src="{{asset('themes/auiskey/assets/img/gallery/leader-4.png')}}" alt="leader image">
                                </div>
                                <h3>Terra Carmichael</h3>
                                <p>CHIEF COMMUNICATIONS OFFICER</p>
                            </a>
                        </div>
                        <div class="our_leader_img">
                            <a href="">
                                <div class="img_leader">
                                    <img src="{{asset('themes/auiskey/assets/img/gallery/leader-5.jpg')}}" alt="leader image">
                                </div>
                                <h3>Tracy Coté</h3>
                                <p>CHIEF PEOPLE OFFICER</p>
                            </a>
                        </div>
                        <div class="our_leader_img">
                            <a href="">
                                <div class="img_leader">
                                    <img src="{{asset('themes/auiskey/assets/img/gallery/leader-6.jpg')}}" alt="leader image">
                                </div>
                                <h3>John Kaelle</h3>
                                <p>CHIEF FINANCIAL OFFICER</p>
                            </a>
                        </div>
                        <div class="our_leader_img">
                            <a href="">
                                <div class="img_leader">
                                    <img src="{{asset('themes/auiskey/assets/img/gallery/leader-7.jpg')}}" alt="leader image">
                                </div>
                                <h3>Laura Lewis</h3>
                                <p>GENERAL COUNSEL</p>
                            </a>
                        </div>
                        <div class="our_leader_img">
                            <a href="">
                                <div class="img_leader">
                                    <img src="{{asset('themes/auiskey/assets/img/gallery/leader-8.jpg')}}" alt="leader image">
                                </div>
                                <h3>Andy Lisk</h3>
                                <p>HEAD OF CUSTOMER SERVICE</p>
                            </a>
                        </div>
                        <div class="our_leader_img">
                            <a href="">
                                <div class="img_leader">
                                    <img src="{{asset('themes/auiskey/assets/img/gallery/leader-9.png')}}" alt="leader image">
                                </div>
                                <h3>Sean McCartney</h3>
                                <p>CHIEF SUPPLY CHAIN OFFICER</p>
                            </a>
                        </div>
                        <div class="our_leader_img">
                            <a href="">
                                <div class="img_leader">
                                    <img src="{{asset('themes/auiskey/assets/img/gallery/leader-10.jpg')}}" alt="leader image">
                                </div>
                                <h3>Vishnu Patankar</h3>
                                <p>CHIEF TECHNOLOGY OFFICER</p>
                            </a>
                        </div>
                        <div class="our_leader_img">
                            <a href="">
                                <div class="img_leader">
                                    <img src="{{asset('themes/auiskey/assets/img/gallery/leader-11.jpg')}}" alt="leader image">
                                </div>
                                <h3>Stephen Winn</h3>
                                <p>CHIEF PRODUCT OFFICER</p>
                            </a>
                        </div>
                    </div>
                </div><!-- our_leaders -->


                <div class="brands_sec202">
                    <div class="brand_item202">
                        <div class="brand_img202">
                            <img src="{{asset('themes/auiskey/assets/img/socials/of-logo.jpg')}}" alt="of-logo">
                        </div>
                        <div class="brand_title202">
                            <h3>Stacy Brown-Philpot</h3>
                            <p>FOUNDING MEMBER, SOFTBANK OPPORTUNITY FUND</p>
                        </div>
                    </div>
                    <div class="brand_item202">
                        <div class="brand_img202">
                            <img src="{{asset('themes/auiskey/assets/img/socials/detroit-logo.png')}}" alt="detroit-logo">
                        </div>
                        <div class="brand_title202">
                            <h3>Jacob Cohen</h3>
                            <p>PARTNER, DETROIT VENTURE PARTNERS</p>
                        </div>
                    </div>
                    <div class="brand_item202">
                        <div class="brand_img202">
                            <img src="{{asset('themes/auiskey/assets/img/socials/stockX-logo.png')}}" alt="stockX-logo">
                        </div>
                        <div class="brand_title202">
                            <h3>Scott Cutler</h3>
                            <p>CEO, STOCKX</p>
                        </div>
                    </div>
                    <div class="brand_item202">
                        <div class="brand_img202">
                            <img src="{{asset('themes/auiskey/assets/img/socials/RocketCompanies-logo.jpg')}}" alt="RocketCompanies-logo">
                        </div>
                        <div class="brand_title202">
                            <h3>Jay Farner</h3>
                            <p>CEO, ROCKET COMPANIES</p>
                        </div>
                    </div>
                    <div class="brand_item202">
                        <div class="brand_img202">
                            <img src="{{asset('themes/auiskey/assets/img/socials/gv-138x100.png')}}" alt="gv-138x100">
                        </div>
                        <div class="brand_title202">
                            <h3>David Krane</h3>
                            <p>CEO AND MANAGING PARTNER, GV</p>
                        </div>
                    </div>
                    <div class="brand_item202">
                        <div class="brand_img202">
                            <img src="{{asset('themes/auiskey/assets/img/socials/Battery-Ventures-1-126x100.jpg')}}" alt="Battery-Ventures">
                        </div>
                        <div class="brand_title202">
                            <h3>Roger Lee</h3>
                            <p>GENERAL PARTNER, BATTERY VENTURES</p>
                        </div>
                    </div>
                    <div class="brand_item202">
                        <div class="brand_img202">
                            <img src="{{asset('themes/auiskey/assets/img/socials/stockX-logo.png')}}" alt="stockX-logo">
                        </div>
                        <div class="brand_title202">
                            <h3>Greg Schwartz</h3>
                            <p>COO, STOCKX</p>
                        </div>
                    </div>
                    <div class="brand_item202">
                        <div class="brand_img202">
                            <img src="{{asset('themes/auiskey/assets/img/socials/kgyuxv4tf8s40dr3sj08-100x100.png')}}" alt="kgyuxv4tf8s40dr3sj08">
                        </div>
                        <div class="brand_title202">
                            <h3>Hans Tung</h3>
                            <p>MANAGING PARTNER, GGV</p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
   



        <div class="counters_sec203">
            <div class="container">
                <div class="stroke_line_text counter_stroke_line_text_sec203">
                    <p>KEY MATRICS</p>
                    <p>KEY MATRICS</p>
                    <p>KEY MATRICS</p>
                </div>
                <div class="main_counter203">
                    <div class="counters203">
                        <div class="counter" data-target="300">0</div>
                        <h3>Lifetime Gross Merchandise Value</h3>
                    </div>
                    <div class="counters203">
                        <div class="counter" data-target="1700">0</div>
                        <h3>Average Monthly Visitors</h3>
                    </div>
                    <div class="counters203">
                        <div class="counter" data-target="1800">0</div>
                        <h3>StockX Team Members</h3>
                    </div>
                    <div class="counters203">
                        <div class="counter" data-target="900">0</div>
                        <h3>Authentication Centers & Drop-off Locations</h3>
                    </div>
                </div>
            </div>
            <div class="count_shape203">
                <svg viewBox="0 0 100 27.14">
                    <polygon fill="#FFFFFF" points="100,0 100,27.14 0,27.14"></polygon>
                </svg>
            </div>
        </div>



        <div class="mark_insights">
            <div class="container">
                <div class="mark_headline">
                    <h1>Market Insights</h1>
                </div>
                <div class="purpose-owl owl-carousel owl-theme">
                    <div class="item">
                        <div class="mark_item_img204">
                            <a href="">
                                <div class="mark_item_img205">
                                    <img src="{{asset('themes/auiskey/assets/img/socials/BigFacts.png')}}" alt="bigFact">
                                </div>
                                <p>JUN 7 2021</p>
                                <h2>Big Facts: Next Gen Invesments</h2>
                            </a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="mark_item_img204">
                            <a href="">
                                <div class="mark_item_img205">
                                    <img src="{{asset('themes/auiskey/assets/img/socials/BigFacts_203.jpg')}}" alt="BigFacts_203">
                                </div>
                                <p>MAY 12 2021</p>
                                <h2>Big Facts: Next Gen Chapter</h2>
                            </a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="mark_item_img204">
                            <a href="">
                                <div class="mark_item_img205">
                                    <img src="{{asset('themes/auiskey/assets/img/socials/NewsroomImages_.jpg')}}" alt="NewsroomImages_">
                                </div>
                                <p>APR 20 2021</p>
                                <h2>StockX Snapshot: Trade is a Global Game</h2>
                            </a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="mark_item_img204">
                            <a href="">
                                <div class="mark_item_img205">
                                    <img src="{{asset('themes/auiskey/assets/img/socials/BigFacts.png')}}" alt="bigFact">
                                </div>
                                <p>JUN 7 2021</p>
                                <h2>Big Facts: Next Gen Invesments</h2>
                            </a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="mark_item_img204">
                            <a href="">
                                <div class="mark_item_img205">
                                    <img src="{{asset('themes/auiskey/assets/img/socials/BigFacts_203.jpg')}}" alt="BigFacts_203">
                                </div>
                                <p>MAY 12 2021</p>
                                <h2>Big Facts: Next Gen Chapter</h2>
                            </a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="mark_item_img204">
                            <a href="">
                                <div class="mark_item_img205">
                                    <img src="{{asset('themes/auiskey/assets/img/socials/NewsroomImages_.jpg')}}" alt="NewsroomImages_">
                                </div>
                                <p>APR 20 2021</p>
                                <h2>StockX Snapshot: Trade is a Global Game</h2>
                            </a>
                        </div>
                    </div>
                </div><!-- Owl Carousel -->
            </div>
        </div>



        <div class="core_value">
            <div class="container">
                <div class="core_value204">
                    <div class="core_item204">
                        <h1>Core Values</h1>
                    </div>
                    <div class="core_item205">
                        <div class="core_item_nmbr">
                            <div class="core_icon204">
                                <img src="{{asset('themes/auiskey/assets/img/socials/Committed_To_Whats_Right-400x400.png')}}" alt="Committed_To_Whats_Right-400x400">
                                <p>01</p>
                            </div>
                            <div class="core_text204">
                                <h1>Committed to What’s Right</h1>
                                <p>We believe in the power of truth, authenticity, and transparency. We do the right thing, and we do it right.</p>
                            </div>
                        </div>
                        <div class="core_item_nmbr">
                            <div class="core_icon204">
                                <img src="{{asset('themes/auiskey/assets/img/socials/Champions_For_Our_Custoemr-400x400.png')}}" alt="Champions_For_Our_Custoemr-400x400">
                                <p>02</p>
                            </div>
                            <div class="core_text204">
                                <h1>Champion for Our Customer</h1>
                                <p>We’re always listening and always learning so we can deliver the quality experience our customers deserve every single day.</p>
                            </div>
                        </div>
                        <div class="core_item_nmbr">
                            <div class="core_icon204">
                                <img src="{{asset('themes/auiskey/assets/img/socials/Playing_On_The_Dream_Team-400x400.png')}}" alt="Playing_On_The_Dream_Team-400x400">
                                <p>03</p>
                            </div>
                            <div class="core_text204">
                                <h1>Playing on the Dream Team</h1>
                                <p>Our diverse and epic team is bound together by a deep belief in our vision, a passionate commitment to each other, and a shared joy in the adventure of it all. We play to win and have fun while doing it.</p>
                            </div>
                        </div>
                        <div class="core_item_nmbr">
                            <div class="core_icon204">
                                <img src="{{asset('themes/auiskey/assets/img/socials/Hungry_For-Whats_Next-400x400.png')}}" alt="Hungry_For-Whats_Next-400x400">
                                <p>04</p>
                            </div>
                            <div class="core_text204">
                                <h1>Hungry for What’s Next</h1>
                                <p>We are committed to learning, growing and disrupting. We push ourselves and each other against the status quo, and we are not afraid to make mistakes.</p>
                            </div>
                        </div>
                        <div class="core_item_nmbr">
                            <div class="core_icon204">
                                <img src="{{asset('themes/auiskey/assets/img/socials/Building_A_Legacy-400x400.png')}}" alt="Building_A_Legacy-400x400">
                                <p>05</p>
                            </div>
                            <div class="core_text204">
                                <h1>Building a Legacy</h1>
                                <p>We are forever building better - a better product, a better workplace and a better world. We’re going to keep raising the bar, changing the game, and ensuring we leave a mark that is never, ever forgotten.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>





        <div class="community_engagement205">
            <div class="container">
                <div class="community_engagement_text">
                    <h1>Community Engagement</h1>
                </div>
                <div class="community_engagements205">
                    <div class="community_engagement_item205">
                        <div class="comm_eng_img">
                            <img src="{{asset('themes/auiskey/assets/img/socials/b204.png')}}" alt="b204">
                        </div>
                        <div class="comm_eng_desc">
                            <h2>Arts & Culture</h2>
                            <p>StockX is inherently connected to the arts community. The sneaker and streetwear spaces, in particular, have roots that trace back to some of the most famous street artists, graffiti writers, muralists and designers. The company is supportive of organizations aimed at introducing youth to arts and culture through initiatives including but not limited to: writing and design scholarships, music education programs, and artist shadowing.</p>
                        </div>
                    </div>
                    <div class="community_engagement_item205">
                        <div class="comm_eng_img">
                            <img src="{{asset('themes/auiskey/assets/img/socials/b205.jpg')}}" alt="b205">
                        </div>
                        <div class="comm_eng_desc">
                            <h2>Youth Recreation</h2>
                            <p>70% of StockX customers are under the age of 35 making the youth constituency core to the StockX community. The company is supportive of initiatives designed to engage youth in recreational activities that align with StockX’s verticals including skateboarding clinics, basketball camps, and other activities designed to connect kids to sport and educational programming.</p>
                        </div>
                    </div>
                    <div class="community_engagement_item205">
                        <div class="comm_eng_img">
                            <img src="{{asset('themes/auiskey/assets/img/socials/b206.jpg')}}" alt="b206">
                        </div>
                        <div class="comm_eng_desc">
                            <h2>Sustainability</h2>
                            <p>StockX is committed to investing in sustainable practices internally within its business operations and externally through its support of campaigns, initiatives, and philanthropic partners like Oceana, an organization committed to the protection and restoration of oceans.</p>
                        </div>
                    </div>
                    <div class="community_engagement_item205">
                        <div class="comm_eng_img">
                            <img src="{{asset('themes/auiskey/assets/img/socials/b207.jpg')}}" alt="b207">
                        </div>
                        <div class="comm_eng_desc">
                            <h2>Tech Education</h2>
                            <p>StockX partners with organizations engaging youth in STEAM initiatives and related technical skill development to encourage a future in applied settings with a specific focus on minority and underserved student populations. Diversity in tech is sorely lacking and StockX aims to play a role in ensuring the industry is representative.</p>
                        </div>
                    </div>
                    <div class="community_engagement_item205">
                        <div class="comm_eng_img">
                            <img src="{{asset('themes/auiskey/assets/img/socials/b208.jpg')}}" alt="b208">
                        </div>
                        <div class="comm_eng_desc">
                            <h2>Social Justice</h2>
                            <p>StockX fosters a diverse and inclusive community, not only for its team members, but for the millions of buyers, sellers, makers, and creators it serves. While much of this work is internal and anchored by a six-point D&I plan, the company understands that it is wrong that underrepresented communities must play by different rules. As such, we are committed to advancing the work of organizations fighting for equity and social justice. In 2020, StockX matched team member donations to organizations including the George Floyd Memorial Fund, the NAACP Legal Defense Fund and Know Your Rights Camp totaling more than $100K in support of their work.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>   
@endsection