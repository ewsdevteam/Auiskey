@extends('shop::layouts.master')

@section('full-content-wrapper')
    
        <section id="app" style="background-image: url({{asset('themes/auiskey/assets/img/socials/app-bg.png')}});">
            <div class="app-bg-overlay">
                <div class="container">
                    <div class="mobile-app">
                        <div class="mobile-text">
                            <h1>GET THE STOCKX APP FOR
                                IPHONE AND ANDROID</h1>
                            <p class="app-text">Buy and sell authentic sneakers, streetwear, watches, and handbags,
                                from your
                                pocket.</p>
                            <form action="">
                                <div class="send-group">
                                    <input type="text" name="send" class="text-field"
                                        placeholder="Enter your phone number and we'll text you the app">
                                    <button type="Submit" class="btn-set btn-send">Send</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
@endsection