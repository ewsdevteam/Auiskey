@extends('shop::layouts.master')

@section('full-content-wrapper')
<section id="about">

<div id="about-banner" style="background-image:url({{asset('themes/auiskey/assets/img/brands/about-banner.png')}})">
    <div class="container">
        <div class="collections">
            <div class="collection-twins">
                <div class="collection-text">
                    <h1>Thank You! for your order</h1>
                    <p>Our mission is to provide access to the world's most coveted items in the smartest
                        way possible. Buy and sell the hottest sneakers, apparel, electronics, collectibles,
                        trading cards and accessories.</p>
                </div>
                <div class="collection-img">
                    <img src="{{asset('themes/auiskey/assets/img/socials/collections.png')}}" alt="collection-imgea">
                </div>
            </div>
            <div class="collections-links">

                <a href="/">Back to Home <i class="fas fa-chevron-right"></i></a>

            </div>
        </div>
    </div>
</div><!-- About Main Banner -->

<!-- What poeple have to say -->
</section>    
@endsection