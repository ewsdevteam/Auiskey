<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">

    <head>
        {{-- title --}}
        <title>@yield('page_title')</title>

        {{-- meta data --}}
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="content-language" content="{{ app()->getLocale() }}">
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <meta name="base-url" content="{{ url()->to('/') }}">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        {!! view_render_event('bagisto.shop.layout.head') !!}

        {{-- for extra head data --}}
        @yield('head')

        {{-- seo meta data --}}
        @section('seo')
            <meta name="description" content="{{ core()->getCurrentChannel()->description }}"/>
        @show

        {{-- fav icon --}}
        @if ($favicon = core()->getCurrentChannel()->favicon_url)
            <link rel="icon" sizes="16x16" href="{{ $favicon }}" />
        @else
            <link rel="icon" sizes="16x16" href="{{ asset('/themes/auiskey/assets/img/favicon-16x16.png') }}" />
        @endif

        {{-- all styles --}}
        @include('shop::layouts.styles')
    </head>

    <body @if (core()->getCurrentLocale() && core()->getCurrentLocale()->direction == 'rtl') class="rtl" @endif>
        

        {{-- main app --}}
         
        <div class="page-wrapper">

                @section('body-header')
                {!! view_render_event('bagisto.shop.layout.header.before') !!}  
                    <header>
                        @include('shop::layouts.top-nav.index') 
                        @include('shop::layouts.header.index')
                    </header>    
                    {!! view_render_event('bagisto.shop.layout.header.after') !!}
                    
                        {!! view_render_event('bagisto.shop.layout.content.before') !!}

                            @yield('content-wrapper')

                        {!! view_render_event('bagisto.shop.layout.content.after') !!}
                    
                @show
               
                {!! view_render_event('bagisto.shop.layout.full-content.before') !!}

                    @yield('full-content-wrapper')

                {!! view_render_event('bagisto.shop.layout.full-content.after') !!}

        {{-- footer --}}
        @section('footer')
                @include('shop::layouts.footer.index')
        @show
    </div>    
        <div class="mobile-menu-overlay"></div><!-- End .mobil-menu-overlay -->
        <div class="mobile-menu-container mobile-menu-light">
            <div class="mobile-menu-wrapper">
                <span class="mobile-menu-close"><i class="fal fa-times"></i></span>

                <nav class="mobile-nav">
                    <ul class="mobile-menu">
                    <li>
                        <a href="">Browse</a>
                        <ul>
                            <li><a href="">Sneakers</a>
                                <ul>
                                    <li><a href="">adidas</a>
                                        <ul>
                                            <li><a href="">Ozweego</a></li>
                                            <li><a href="">Human Race</a></li>
                                            <li><a href="">Nite Jogger</a></li>
                                            <li><a href="">Ivy Park</a></li>
                                            <li><a href="">Raf Simons</a></li>
                                            <li><a href="">Yeezy</a></li>
                                            <li><a href="">Ultra Boost</a></li>
                                            <li><a href="">NMD</a></li>
                                            <li><a href="">Iniki</a></li>
                                            <li><a href="">Stan Smith</a></li>
                                            <li><a href="">EQT</a></li>
                                            <li><a href="">Basketball</a></li>
                                            <li><a href="">Running</a></li>
                                            <li><a href="">Skateboarding</a></li>
                                            <li><a href="">Soccer</a></li>
                                            <li><a href="">Other</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="">Air Jordan</a>
                                        <ul>
                                            <li><a href="">1</a></li>
                                            <li><a href="">2</a></li>
                                            <li><a href="">3</a></li>
                                            <li><a href="">4</a></li>
                                            <li><a href="">5</a></li>
                                            <li><a href="">6</a></li>
                                            <li><a href="">7</a></li>
                                            <li><a href="">8</a></li>
                                            <li><a href="">9</a></li>
                                            <li><a href="">10</a></li>
                                            <li><a href="">11</a></li>
                                            <li><a href="">12</a></li>
                                            <li><a href="">13</a></li>
                                            <li><a href="">14</a></li>
                                            <li><a href="">15</a></li>
                                            <li><a href="">16</a></li>
                                            <li><a href="">17</a></li>
                                            <li><a href="">18</a></li>
                                            <li><a href="">19</a></li>
                                            <li><a href="">20</a></li>
                                            <li><a href="">21</a></li>
                                            <li><a href="">22</a></li>
                                            <li><a href="">23</a></li>
                                            <li><a href="">24</a></li>
                                            <li><a href="">25</a></li>
                                            <li><a href="">26</a></li>
                                            <li><a href="">27</a></li>
                                            <li><a href="">28</a></li>
                                            <li><a href="">29</a></li>
                                            <li><a href="">30</a></li>
                                            <li><a href="">31</a></li>
                                            <li><a href="">32</a></li>
                                            <li><a href="">33</a></li>
                                            <li><a href="">34</a></li>
                                            <li><a href="">35</a></li>
                                            <li><a href="">Packs</a></li>
                                            <li><a href="">Spizike</a></li>
                                            <li><a href="">Legacy 312</a></li>
                                            <li><a href="">Jordan OFF-WHITE</a></li>
                                            <li><a href="">Future</a></li>
                                            <li><a href="">Women</a></li>
                                            <li><a href="">Kids</a></li>
                                            <li><a href="">Golf</a></li>
                                            <li><a href="">Other</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">Nike</a>
                                        <ul>
                                            <li><a href="">Air Force</a></li>
                                            <li><a href="">Air Max</a></li>
                                            <li><a href="">Basketball</a></li>
                                            <li><a href="">Foamposite</a></li>
                                            <li><a href="">KD</a></li>
                                            <li><a href="">Kobe</a></li>
                                            <li><a href="">LeBron</a></li>
                                            <li><a href="">Dunk</a></li>
                                            <li><a href="">SB</a></li>
                                            <li><a href="">Other</a></li>
                                            <li><a href="">Sacai</a></li>
                                            <li><a href="">Cortez</a></li>
                                            <li><a href="">Presto</a></li>
                                            <li><a href="">Fear Of God</a></li>
                                            <li><a href="">Huarache</a></li>
                                            <li><a href="">Undercover</a></li>
                                            <li><a href="">React Element</a></li>
                                            <li><a href="">Cactus Plant Flea Market</a></li>
                                            <li><a href="">Comme Des Garcons</a></li>
                                            <li><a href="">Yeezy</a></li>
                                            <li><a href="">Daybreak</a></li>
                                            <li><a href="">Space Hippie</a></li>
                                            <li><a href="">Zoomx</a></li>
                                            <li><a href="">Tailwind</a></li>
                                            <li><a href="">Stranger Things</a></li>
                                            <li><a href="">OBJ</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">New Balance</a>
                                        <ul>
                                            <li><a href="">550</a></li>
                                            <li><a href="">57/40</a></li>
                                            <li><a href="">327</a></li>
                                            <li><a href="">990v1</a></li>
                                            <li><a href="">990v2</a></li>
                                            <li><a href="">990v3</a></li>
                                            <li><a href="">990v4</a></li>
                                            <li><a href="">990v5</a></li>
                                            <li><a href="">991</a></li>
                                            <li><a href="">992</a></li>
                                            <li><a href="">997</a></li>
                                            <li><a href="">998</a></li>
                                            <li><a href="">1300</a></li>
                                            <li><a href="">2002R</a></li>
                                            <li><a href="">OMN1S</a></li>
                                            <li><a href="">Other</a></li>
                                            <li><a href="">Aime Leon Dore</a></li>
                                            <li><a href="">Bodega</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">Reebok</a>
                                        <ul>
                                            <li><a href="">Answer</a></li>
                                            <li><a href="">Beatnik</a></li>
                                            <li><a href="">Club C</a></li>
                                            <li><a href="">Classic Leather</a></li>
                                            <li><a href="">Instapump</a></li>
                                            <li><a href="">Kamikaze</a></li>
                                            <li><a href="">Pump</a></li>
                                            <li><a href="">Pyer Moss</a></li>
                                            <li><a href="">Question</a></li>
                                            <li><a href="">Workout</a></li>
                                            <li><a href="">Other</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">Other Brands</a>
                                        <ul>
                                            <li><a href="">Yeezy</a></li>
                                            <li><a href="">ASICS</a></li>
                                            <li><a href="">A Bathing Ape</a></li>
                                            <li><a href="">Diadora</a></li>
                                            <li><a href="">Converse</a></li>
                                            <li><a href="">Crocs</a></li>
                                            <li><a href="">Li-Ning</a></li>
                                            <li><a href="">New Balance</a></li>
                                            <li><a href="">Puma</a></li>
                                            <li><a href="">Saucony</a></li>
                                            <li><a href="">Under Armour</a></li>
                                            <li><a href="">Other</a></li>
                                            <li><a href="">Vans</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">Luxury Brands</a>
                                        <ul>
                                            <li><a href="">Alexander McQueen</a></li>
                                            <li><a href="">Balenciaga</a></li>
                                            <li><a href="">Burberry</a></li>
                                            <li><a href="">Chanel</a></li>
                                            <li><a href="">Common Projects</a></li>
                                            <li><a href="">Dior</a></li>
                                            <li><a href="">Gucci</a></li>
                                            <li><a href="">Louis Vuitton</a></li>
                                            <li><a href="">OFF-WHITE</a></li>
                                            <li><a href="">Prada</a></li>
                                            <li><a href="">Saint Laurent</a></li>
                                            <li><a href="">Versace</a></li>
                                            <li><a href="">Other</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li><a href="">Collections</a>
                                        <ul>
                                            <li><a href="">Nike Off-White</a></li>
                                            <li><a href="">Nike Travis Scott</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                            <li><a href=""><span>Streetwear<span class="tip tip-new">new</span></span></a>
                                <ul>
                                    <li><a href="">Artist Merch</a>
                                        <ul>
                                            <li><a href="">A$AP Mob</a></li>
                                            <li><a href="">Beyonce</a></li>
                                            <li><a href="">Billie Eilish</a></li>
                                            <li><a href="">Cardi B</a></li>
                                            <li><a href="">City Morgue</a></li>
                                            <li><a href="">Don Toliver</a></li>
                                            <li><a href="">Frank Ocean</a></li>
                                            <li><a href="">J Balvin</a></li>
                                            <li><a href="">Juice Wrld</a></li>
                                            <li><a href="">Justin Bieber</a></li>
                                            <li><a href="">Kanye West</a></li>
                                            <li><a href="">Kevin Abstract</a></li>
                                            <li><a href="">Kid Cudi</a></li>
                                            <li><a href="">Kids See Ghosts</a></li>
                                            <li><a href="">Kodak Black</a></li>
                                            <li><a href="">Lil Uzi Vert</a></li>
                                            <li><a href="">Lil Wayne</a></li>
                                            <li><a href="">Migos</a></li>
                                            <li><a href="">Nav</a></li>
                                            <li><a href="">Playboi Carti</a></li>
                                            <li><a href="">Pop Smoke</a></li>
                                            <li><a href="">Rolling Stones</a></li>
                                            <li><a href="">TDE</a></li>
                                            <li><a href="">Travis Scott</a></li>
                                            <li><a href="">The Weeknd</a></li>
                                            <li><a href="">Yeti Out</a></li>
                                            <li><a href="">YoungBoy NBA</a></li>
                                            <li><a href="">XXXTentacion</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">ASSC</a>
                                        <ul>
                                            <li><a href="">Accessories</a></li>
                                            <li><a href="">Bottoms</a></li>
                                            <li><a href="">Headwear</a></li>
                                            <li><a href="">Jackets</a></li>
                                            <li><a href="">Shirts</a></li>
                                            <li><a href="">T-Shirts</a></li>
                                            <li><a href="">Tops/Sweatshirts</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">BAPE</a>
                                        <ul>
                                            <li><a href="">Accessories</a></li>
                                            <li><a href="">Bags</a></li>
                                            <li><a href="">Bottoms</a></li>
                                            <li><a href="">Face Masks</a></li>
                                            <li><a href="">Headwear</a></li>
                                            <li><a href="">Jackets</a></li>
                                            <li><a href="">Shirts</a></li>
                                            <li><a href="">T-Shirts</a></li>
                                            <li><a href="">Tops/Sweatshirts</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">Fear of God</a>
                                        <ul>
                                            <li><a href="">Fear of God LA</a></li>
                                            <li><a href="">Essentials</a></li>
                                            <li><a href="">Essentials Kids</a></li>
                                            <li><a href="">Nike</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">KAWS</a>
                                        <ul>
                                            <li><a href="">Uniqlo</a></li>
                                            <li><a href="">Jordan Apparel</a></li>
                                            <li><a href="">Union</a></li>
                                            <li><a href="">Dior</a></li>
                                            <li><a href="">Sacai</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">Kith</a>
                                        <ul>
                                            <li><a href="">Accessories</a></li>
                                            <li><a href="">Bottoms</a></li>
                                            <li><a href="">Headwear</a></li>
                                            <li><a href="">Jackets</a></li>
                                            <li><a href="">Shirts</a></li>
                                            <li><a href="">T-Shirts</a></li>
                                            <li><a href="">Tops/Sweatshirts</a></li>
                                            <li><a href="">Looney Tunes</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">New Era</a>
                                        <ul>
                                            <li><a href="">Fitted</a></li>
                                            <li><a href="">Adjustable</a></li>
                                            <li><a href="">Beanie</a></li>
                                            <li><a href="">Other</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">Nike Apparel</a>
                                        <ul>
                                            <li><a href="">ACW</a></li>
                                            <li><a href="">Ambush</a></li>
                                            <li><a href="">Atmos</a></li>
                                            <li><a href="">Cactus Plant Flea Market</a></li>
                                            <li><a href="">Cav Empt</a></li>
                                            <li><a href="">Colin Kaepernick</a></li>
                                            <li><a href="">Dover Street Market</a></li>
                                            <li><a href="">Drake</a></li>
                                            <li><a href="">Heron Preston</a></li>
                                            <li><a href="">LBJ x John Elliott</a></li>
                                            <li><a href="">Marine Serre</a></li>
                                            <li><a href="">MMW</a></li>
                                            <li><a href="">Nike Sportswear</a></li>
                                            <li><a href="">Olivia Kim</a></li>
                                            <li><a href="">Parra</a></li>
                                            <li><a href="">Patta</a></li>
                                            <li><a href="">Pigalle</a></li>
                                            <li><a href="">Sacai</a></li>
                                            <li><a href="">Sean Wotherspoon</a></li>
                                            <li><a href="">Spongebob</a></li>
                                            <li><a href="">Staple</a></li>
                                            <li><a href="">Stone Island</a></li>
                                            <li><a href="">Stranger Things</a></li>
                                            <li><a href="">Stussy</a></li>
                                            <li><a href="">Tiger Woods</a></li>
                                            <li><a href="">Tom Sachs</a></li>
                                            <li><a href="">Undercover</a></li>
                                            <li><a href="">Undefeated</a></li>
                                            <li><a href="">ACG</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">Off-White</a>
                                        <ul>
                                            <li><a href="">Accessories</a></li>
                                            <li><a href="">Bottoms</a></li>
                                            <li><a href="">Face Masks</a></li>
                                            <li><a href="">Headwear</a></li>
                                            <li><a href="">Jackets</a></li>
                                            <li><a href="">Shirts</a></li>
                                            <li><a href="">T-Shirts</a></li>
                                            <li><a href="">Tops/Sweatshirts</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">Palace</a>
                                        <ul>
                                            <li><a href="">Accessories</a></li>
                                            <li><a href="">Bottoms</a></li>
                                            <li><a href="">Headwear</a></li>
                                            <li><a href="">Jackets</a></li>
                                            <li><a href="">Shirts</a></li>
                                            <li><a href="">T-Shirts</a></li>
                                            <li><a href="">Tops/Sweatshirts</a></li>
                                            <li><a href="">Bags</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">Sunglasses</a></li>
                                    <li><a href="">Supreme</a>
                                        <ul>
                                            <li><a href="">Accessories</a></li>
                                            <li><a href="">Bottoms</a></li>
                                            <li><a href="">Headwear</a></li>
                                            <li><a href="">Jackets</a></li>
                                            <li><a href="">Shirts</a></li>
                                            <li><a href="">T-Shirts</a></li>
                                            <li><a href="">Tops/Sweatshirts</a></li>
                                            <li><a href="">Bags</a></li>
                                            <li><a href="">Box Logos</a></li>
                                            <li><a href="">The North Face</a></li>
                                            <li><a href="">Fanny Packs</a></li>
                                            <li><a href="">Nike Collection</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">Other Brands</a>
                                        <ul>
                                            <li><a href="">100 Thieves</a></li>
                                            <li><a href="">adidas Apparel</a></li>
                                            <li><a href="">Aime Leon Dore</a></li>
                                            <li><a href="">AMIRI</a></li>
                                            <li><a href="">Awake</a></li>
                                            <li><a href="">Cactus Plant Flea Market</a></li>
                                            <li><a href="">Chrome Hearts</a></li>
                                            <li><a href="">Dior</a></li>
                                            <li><a href="">drew house</a></li>
                                            <li><a href="">Eric Emanuel</a></li>
                                            <li><a href="">FTP</a></li>
                                            <li><a href="">Full Send</a></li>
                                            <li><a href="">Girls Don't Cry</a></li>
                                            <li><a href="">Gallery Dept.</a></li>
                                            <li><a href="">Gucci</a></li>
                                            <li><a href="">Hidden NY</a></li>
                                            <li><a href="">Human Made</a></li>
                                            <li><a href="">Ivy Park</a></li>
                                            <li><a href="">Jordan Apparel</a></li>
                                            <li><a href="">Louis Vuitton</a></li>
                                            <li><a href="">Noah</a></li>
                                            <li><a href="">OVO</a></li>
                                            <li><a href="">Palm Angels</a></li>
                                            <li><a href="">Stussy</a></li>
                                            <li><a href="">Takashi Murakami</a></li>
                                            <li><a href="">The North Face</a></li>
                                            <li><a href="">Uniqlo</a></li>
                                            <li><a href="">Yeezy Apparel</a></li>
                                            <li><a href="">CDG</a></li>
                                            <li><a href="">Other</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                            <li><a href="">Collectibles</a>
                                <ul>
                                    <li><a href="">Electronics</a>
                                        <ul>
                                            <li><a href="">Apple</a></li>
                                            <li><a href="">AMD</a></li>
                                            <li><a href="">Beats</a></li>
                                            <li><a href="">Bose</a></li>
                                            <li><a href="">Intel</a></li>
                                            <li><a href="">Logitech</a></li>
                                            <li><a href="">Microsoft</a></li>
                                            <li><a href="">Nest</a></li>
                                            <li><a href="">Nintendo</a></li>
                                            <li><a href="">NVIDIA</a></li>
                                            <li><a href="">Oculus</a></li>
                                            <li><a href="">Playstation</a></li>
                                            <li><a href="">Razer</a></li>
                                            <li><a href="">Samsung</a></li>
                                            <li><a href="">Xbox</a></li>
                                            <li><a href="">Video Games</a></li>
                                            <li><a href="">Other Electronics</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">Trading Cards</a>
                                        <ul>
                                            <li><a href="">Baseball</a></li>
                                            <li><a href="">Basketball</a></li>
                                            <li><a href="">Football</a></li>
                                            <li><a href="">Hockey</a></li>
                                            <li><a href="">Soccer</a></li>
                                            <li><a href="">Other Sports</a></li>
                                            <li><a href="">Topps Project 2020</a></li>
                                            <li><a href="">Sealed Boxes</a></li>
                                            <li><a href="">Pokémon</a></li>
                                            <li><a href="">Yu-Gi-Oh!</a></li>
                                            <li><a href="">Magic: The Gathering</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">KAWS</a>
                                        <ul>
                                            <li><a href="">Vinyl Figures</a></li>
                                            <li><a href="">Plush Figures</a></li>
                                            <li><a href="">Bearbrick</a></li>
                                            <li><a href="">Keychains &amp;Pins</a></li>
                                            <li><a href="">Other</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">Bearbrick</a>
                                        <ul>
                                            <li><a href="">100%</a></li>
                                            <li><a href="">200%</a></li>
                                            <li><a href="">400%</a></li>
                                            <li><a href="">1000%</a></li>
                                            <li><a href="">Nyabrick</a></li>
                                            <li><a href="">Rabbrick</a></li>
                                            <li><a href="">Other</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">Art Prints</a>
                                        <ul>
                                            <li><a href="">Futura</a></li>
                                            <li><a href="">Hebru Brantley</a></li>
                                            <li><a href="">James Jean</a></li>
                                            <li><a href="">KAWS</a></li>
                                            <li><a href="">Shepard Fairey</a></li>
                                            <li><a href="">Takashi Murakami</a></li>
                                            <li><a href="">Yoshitomo Nara</a></li>
                                            <li><a href="">Other Artists</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">LEGO</a>
                                        <ul>
                                            <li><a href="">Architecture</a></li>
                                            <li><a href="">Botanical Collection</a></li>
                                            <li><a href="">Brick Headz</a></li>
                                            <li><a href="">City</a></li>
                                            <li><a href="">Creator</a></li>
                                            <li><a href="">Disney</a></li>
                                            <li><a href="">Friends</a></li>
                                            <li><a href="">Harry Potter</a></li>
                                            <li><a href="">Heroes</a></li>
                                            <li><a href="">Ideas</a></li>
                                            <li><a href="">Movies</a></li>
                                            <li><a href="">Ninjago</a></li>
                                            <li><a href="">Star Wars</a></li>
                                            <li><a href="">Super Mario</a></li>
                                            <li><a href="">Technic</a></li>
                                            <li><a href="">The Simpsons</a></li>
                                            <li><a href="">Other</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">Funko Pop!</a>
                                        <ul>
                                            <li><a href="">Ad Icons</a></li>
                                            <li><a href="">Anime</a></li>
                                            <li><a href="">Animation</a></li>
                                            <li><a href="">Asia</a></li>
                                            <li><a href="">Disney</a></li>
                                            <li><a href="">Freddy Funko</a></li>
                                            <li><a href="">Game of Thrones</a></li>
                                            <li><a href="">Games</a></li>
                                            <li><a href="">Heroes</a></li>
                                            <li><a href="">Icons</a></li>
                                            <li><a href="">Marvel</a></li>
                                            <li><a href="">Movies</a></li>
                                            <li><a href="">Music</a></li>
                                            <li><a href="">Pokémon</a></li>
                                            <li><a href="">Retro Toys</a></li>
                                            <li><a href="">Rides</a></li>
                                            <li><a href="">Town</a></li>
                                            <li><a href="">Soda</a></li>
                                            <li><a href="">Sports</a></li>
                                            <li><a href="">Stan Lee</a></li>
                                            <li><a href="">Star Wars</a></li>
                                            <li><a href="">Television</a></li>
                                            <li><a href="">Other</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">Action Figures</a>
                                        <ul>
                                            <li><a href="">Dolls</a></li>
                                            <li><a href="">Gundam</a></li>
                                            <li><a href="">Marvel</a></li>
                                            <li><a href="">Masters of the Universe</a></li>
                                            <li><a href="">Sports</a></li>
                                            <li><a href="">Star Wars</a></li>
                                            <li><a href="">Other</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">Daniel Arsham</a>
                                        <ul>
                                            <li><a href="">Future Relics</a></li>
                                            <li><a href="">Other</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">TakashiMurakami</a>
                                        <ul>
                                            <li><a href="">Vinyl Figures</a></li>
                                            <li><a href="">Plush Figures</a></li>
                                            <li><a href="">Skate Decks</a></li>
                                            <li><a href="">Keychains &amp; Pins</a></li>
                                            <li><a href="">Other</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">Virgil Abloh</a>
                                        <ul>
                                            <li><a href="">IKEA</a></li>
                                            <li><a href="">Other</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">Skate Decks</a>
                                        <ul>
                                            <li><a href="">Supreme</a></li>
                                            <li><a href="">Bape</a></li>
                                            <li><a href="">Palace</a></li>
                                            <li><a href="">Other</a></li>
                                            <li><a href="">Skate Accessories</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">Comic Books</a>
                                        <ul>
                                            <li><a href="">Avengers</a></li>
                                            <li><a href="">Batman</a></li>
                                            <li><a href="">Captain America</a></li>
                                            <li><a href="">DC Universe</a></li>
                                            <li><a href="">Fantastic Four</a></li>
                                            <li><a href="">GI Joe</a></li>
                                            <li><a href="">Hulk</a></li>
                                            <li><a href="">Invincible</a></li>
                                            <li><a href="">Iron Man</a></li>
                                            <li><a href="">Marvel Universe</a></li>
                                            <li><a href="">Saga</a></li>
                                            <li><a href="">Spawn</a></li>
                                            <li><a href="">Spider-Man</a></li>
                                            <li><a href="">Star Wars</a></li>
                                            <li><a href="">Sub-Mariner</a></li>
                                            <li><a href="">Superman</a></li>
                                            <li><a href="">Wolverine</a></li>
                                            <li><a href="">Wonder Woman</a></li>
                                            <li><a href="">X-Men</a></li>
                                            <li><a href="">Other</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">Other Artists</a>
                                        <ul>
                                            <li><a href="">Banksy</a></li>
                                            <li><a href="">Cote Escriva</a></li>
                                            <li><a href="">Danil Yad</a></li>
                                            <li><a href="">Futura</a></li>
                                            <li><a href="">Hajime Sorayama</a></li>
                                            <li><a href="">Hebru Brantley</a></li>
                                            <li><a href="">Jason Freeny</a></li>
                                            <li><a href="">Javier Calleja</a></li>
                                            <li><a href="">Joan Cornella</a></li>
                                            <li><a href="">Juce Gace</a></li>
                                            <li><a href="">Louis De Guzman</a></li>
                                            <li><a href="">Matt Gondek</a></li>
                                            <li><a href="">OG Slick</a></li>
                                            <li><a href="">Parra</a></li>
                                            <li><a href="">Quiccs</a></li>
                                            <li><a href=" ">Reina Koyano</a></li>
                                            <li><a href="">Ron English</a></li>
                                            <li><a href="">Steven Harrington</a></li>
                                            <li><a href="">Tom Sachs</a></li>
                                            <li><a href="">Whatshisname</a></li>
                                            <li><a href="">Yayoi Kusama</a></li>
                                            <li><a href="">Yoshitomo Nara</a></li>
                                            <li><a href="">Other</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">Other Collectibles</a>
                                        <ul>
                                            <li><a href="">Astroboy</a></li>
                                            <li><a href="">Ben Baller</a></li>
                                            <li><a href="">Books &amp; Magazines</a></li>
                                            <li><a href="">Chinatown Market</a></li>
                                            <li><a href="">Disney</a></li>
                                            <li><a href="">Hot Wheels</a></li>
                                            <li><a href="">Houseplant</a></li>
                                            <li><a href="">Kith</a></li>
                                            <li><a href="">Louis Vuitton</a></li>
                                            <li><a href="">MSCHF</a></li>
                                            <li><a href="">Neighborhood</a></li>
                                            <li><a href="">Pokemon</a></li>
                                            <li><a href="">RipNDip</a></li>
                                            <li><a href="">Shoeuzi</a></li>
                                            <li><a href="">Squishmallows</a></li>
                                            <li><a href="">Spalding</a></li>
                                            <li><a href="">Superplastic</a></li>
                                            <li><a href="">Supreme</a></li>
                                            <li><a href="">Travis Scott</a></li>
                                            <li><a href="">Undercover</a></li>
                                            <li><a href="">Vinyl Records &amp; Music</a></li>
                                            <li><a href="">Youtooz</a></li>
                                            <li><a href="">Other</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                            <li><a href="">Handbags</a>
                                <ul>
                                    <li><a href="">Louis Vuitton</a>
                                        <ul>
                                            <li><a href="">Supreme</a></li>
                                            <li><a href="">Keepall</a></li>
                                            <li><a href="">Speedy</a></li>
                                            <li><a href="">Alma</a></li>
                                            <li><a href="">Neverfull</a></li>
                                            <li><a href="">Pochette</a></li>
                                            <li><a href="">Collectors</a></li>
                                            <li><a href="">Other</a></li>
                                            <li><a href="">Game On</a></li>
                                            <li><a href="">NBA</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">Telfar</a></li>
                                    <li><a href="">Gucci</a>
                                        <ul>
                                            <li><a href="">Marmont</a></li>
                                            <li><a href="">Dionysus</a></li>
                                            <li><a href="">Boston</a></li>
                                            <li><a href="">Soho Disco</a></li>
                                            <li><a href="">Collectors</a></li>
                                            <li><a href="">Other</a></li>
                                            <li><a href="">TNF</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">MCM</a></li>
                                    <li><a href="">Chanel</a>
                                        <ul>
                                            <li><a href="">Flap</a></li>
                                            <li><a href="">Boy</a></li>
                                            <li><a href="">WOC</a></li>
                                            <li><a href="">Camera</a></li>
                                            <li><a href="">Filigree</a></li>
                                            <li><a href="">Collectors</a></li>
                                            <li><a href="">Other</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">Goyard</a>
                                        <ul>
                                            <li><a href="">Saint Louis</a></li>
                                            <li><a href="">Anjou</a></li>
                                            <li><a href="">Other</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">Dior</a>
                                        <ul>
                                            <li><a href="">Lady Dior</a></li>
                                            <li><a href="">Diorama</a></li>
                                            <li><a href="">Saddle</a></li>
                                            <li><a href="">Collectors</a></li>
                                            <li><a href="">Other</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">Balenciaga</a>
                                        <ul>
                                            <li><a href="">City</a></li>
                                            <li><a href="">Ville</a></li>
                                            <li><a href="">Camera</a></li>
                                            <li><a href="">Triangle</a></li>
                                            <li><a href="">Papier</a></li>
                                            <li><a href="">Other</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">Off-White</a></li>
                                    <li><a href="">Burberry</a></li>
                                    <li><a href="">Hermes</a>
                                        <ul>
                                            <li><a href="">Birkin</a></li>
                                            <li><a href="">Constance</a></li>
                                            <li><a href="">Evelyne</a></li>
                                            <li><a href="">Kelly</a></li>
                                            <li><a href="">Other</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="/">Prada</a>
                                        <ul>
                                            <li><a href="">Re-Edition</a></li>
                                            <li><a href="">Re-Edition 2000</a></li>
                                            <li><a href="">Re-Edition 2005</a></li>
                                            <li><a href="">Cahier</a></li>
                                            <li><a href="">Galleria</a></li>
                                            <li><a href="">Collectors</a></li>
                                            <li><a href="">Other</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">Brandon Blackwood</a></li>
                                    <li><a href="">Versace</a></li>
                                    <li><a href="">Tory Burch</a></li>
                                    <li><a href="">Other Brands</a>
                                        <ul>
                                            <li><a href="">Bottega Veneta</a></li>
                                            <li><a href="">Celine</a></li>
                                            <li><a href="">Chloe</a></li>
                                            <li><a href="">Coach</a></li>
                                            <li><a href="">Comme des Garcons</a></li>
                                            <li><a href="">Fendi</a></li>
                                            <li><a href="">Givenchy</a></li>
                                            <li><a href="">Longchamp</a></li>
                                            <li><a href="">Rimowa</a></li>
                                            <li><a href="">Saint Laurent</a></li>
                                            <li><a href="">The Marc Jacobs</a></li>
                                            <li><a href="">Yaito</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                            <li><a href=""><span>Watches<span class="tip tip-hot">Hot</span></span></a>
                                <ul>
                                    <li><a href="">Rolex</a>
                                        <ul>
                                            <li><a href="">Submariner</a></li>
                                            <li><a href="">Explorer</a></li>
                                            <li><a href="">Daytona</a></li>
                                            <li><a href="">GMT-Master II</a></li>
                                            <li><a href="">Sea-Dweller</a></li>
                                            <li><a href="">Datejust</a></li>
                                            <li><a href="">Day-Date</a></li>
                                            <li><a href="">Yacht-Master</a></li>
                                            <li><a href="">Oyster-Perpetual</a></li>
                                            <li><a href="">Cellini</a></li>
                                            <li><a href="">Sky-Dweller</a></li>
                                            <li><a href="">Air-King</a></li>
                                            <li><a href="">Other</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">Casio</a>
                                        <ul>
                                            <li><a href="">G-Shock</a></li>
                                            <li><a href="">Other</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">Apple</a>
                                        <ul>
                                            <li><a href="">Series 4</a></li>
                                            <li><a href="">Series 5</a></li>
                                            <li><a href="">Series 6</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">Seiko</a></li>
                                    <li><a href="">Timex</a></li>
                                    <li><a href="">Tudor</a></li>
                                    <li><a href="">Omega</a>
                                        <ul>
                                            <li><a href="">Speedmaster</a></li>
                                            <li><a href="">Seamaster</a></li>
                                            <li><a href="">Constellation</a></li>
                                            <li><a href="">Other</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">Audemars Piguet</a>
                                        <ul>
                                            <li><a href="">Royal Oak</a></li>
                                            <li><a href="">Royal Oak Offshore</a></li>
                                            <li><a href="">Other</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">Panerai</a>
                                        <ul>
                                            <li><a href="">Luminor</a></li>
                                            <li><a href="">Radiomir</a></li>
                                            <li><a href="">Other</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">Tag Heuer</a></li>
                                    <li><a href="">Breitling</a>
                                        <ul>
                                            <li><a href="">Navitimer</a></li>
                                            <li><a href="">Other</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">Cartier</a>
                                        <ul>
                                            <li><a href="">Tank</a></li>
                                            <li><a href="">Ballon Bleu</a></li>
                                            <li><a href="">Roadster</a></li>
                                            <li><a href="">Santos</a></li>
                                            <li><a href="">Pasha</a></li>
                                            <li><a href="">Other</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">IWC</a>
                                        <ul>
                                            <li><a href="">Big Pilot</a></li>
                                            <li><a href="">Pilot</a></li>
                                            <li><a href="">Portuguese</a></li>
                                            <li><a href="">Other</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">Shinola</a>
                                        <ul>
                                            <li><a href="">Bedrock</a></li>
                                            <li><a href="">Canfield</a></li>
                                            <li><a href="">Guardian</a></li>
                                            <li><a href="">Omaha</a></li>
                                            <li><a href="">Runwell</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">Jacob &amp; Co.</a></li>
                                    <li><a href="">Other Brands</a>
                                        <ul>
                                            <li><a href="">Swatch</a></li>
                                            <li><a href="">Ulysse Nardin</a></li>
                                            <li><a href="">Gucci</a></li>
                                            <li><a href="">Ernst Benz</a></li>
                                            <li><a href="">Oris</a></li>
                                            <li><a href="">Bell &amp; Ross</a></li>
                                            <li><a href="">Citizen</a></li>
                                            <li><a href="">Movado</a></li>
                                            <li><a href="">Chanel</a></li>
                                            <li><a href="">Tissot</a></li>
                                            <li><a href="">Bulova</a></li>
                                            <li><a href="">Nixon</a></li>
                                            <li><a href="">Hublot</a></li>
                                            <li><a href="">Other</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                        </ul>                        
                    </li>
                    <li><a href="{{ route('shop.news') }}">News</a></li>
                    <li><a href="{{ route('shop.app') }}">App</a></li>
                    <li><a href="{{ route('shop.about') }}">About</a></li>
                    <li><a href="">Help</a></li>
                    <li><a href="{{ route('customer.session.index')}}">Login</a></li>
                    <li><a href="{{ route('customer.register.index') }}">Signup</a></li>
                    <li><a href="">$0.0 Items</a></li>
                </ul>
                </nav><!-- End .mobile-nav -->                   
            </div>
        </div>    
        @include('shop::layouts.scripts')
        @stack('scripts')
    </body>
</html>
