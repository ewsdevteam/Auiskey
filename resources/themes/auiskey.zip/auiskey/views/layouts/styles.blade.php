{{-- preloaded fonts --}}
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
{{-- bootstrap --}}

    <link rel="stylesheet" href="{{ asset('themes/auiskey/assets/css/jquery-ui.css') }}">
    <link rel="stylesheet" href="{{ asset('themes/auiskey/assets/css/owl.carousel.min.css') }}">
    <link rel="stylesheet" href="{{ asset('themes/auiskey/assets/css/owl.theme.default.min.css') }}">
    <link rel="stylesheet" href="{{ asset('themes/auiskey/assets/css/slick.css') }}">
    <link rel="stylesheet" href="{{ asset('themes/auiskey/assets/css/slick-theme.css') }}">
    <link rel="stylesheet" href="{{ asset('themes/auiskey/assets/css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('themes/auiskey/assets/css/style.css') }}">
    <link rel="stylesheet" href="{{ asset('themes/auiskey/assets/css/responsive.css') }}">
    <link rel="stylesheet" href="{{ asset('themes/auiskey/assets/css/nice-select.css') }}">
    <link rel="stylesheet" href="{{ asset('themes/auiskey/assets/css/rotate.css') }}">
    <link rel="stylesheet" href="{{ asset('themes/auiskey/assets/css/sweetalert2.css') }}">

{{-- bootstrap flipped for rtl --}}
@if (core()->getCurrentLocale() && core()->getCurrentLocale()->direction == 'rtl')
   {{-- <link href="{{ asset('themes/velocity/assets/css/bootstrap-flipped.css') }}" rel="stylesheet"> --}}
@endif

{{-- mix versioned compiled file --}}
{{--<link rel="stylesheet" href="{{ asset(mix('/css/velocity.css', 'themes/velocity/assets')) }}" />--}}

{{-- extra css --}}
@stack('css')

{{-- custom css --}}
<style>
    {!! core()->getConfigData('general.content.custom_scripts.custom_css') !!}
    .slider{
            display:none;
    }
    .skeleton-loader{
        display:block;
    }
    .preloader{
        background-color: rgb(241, 241, 241);
        width: 100%;
        height: 100%;
        position: absolute;
        top: 0;
        left: 0;
        display:none;
    }

    .preloader img{
        text-align: center;
        display: block;
        margin: 20rem auto 0 auto;
        width: 85px;    
    }
    .size__bidAsk{position:relative;}
</style>
