
        <div class="ft-copyright">
        <p>
            @if (core()->getConfigData('general.content.footer.footer_content'))
                {!! core()->getConfigData('general.content.footer.footer_content') !!}
            @else
                {!! trans('admin::app.footer.copy-right') !!}
            @endif
        </p>
        </div>
        <div class="ft-socials">
            <ul>
                <li><a href=""  target="_blank" title="Facebook"><i class="fab fa-facebook-f"></i></a></li>
                <li><a href=""  target="_blank" title="Twitter"><i class="fab fa-twitter"></i></a></li>
                <li><a href=""  target="_blank" title="Google"><i class="fab fa-google"></i></a></li>
                <li><a href=""  target="_blank" title="Pinterest"><i class="fab fa-pinterest-p"></i></a></li>
                <li><a href=""  target="_blank" title="Linkedin"><i class="fab fa-linkedin-in"></i></a></li>
            </ul>
        </div>
