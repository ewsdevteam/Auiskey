
        {{-- @if ($categories)
            @include('shop::layouts.footer.top-brands')
        @endif --}}
    <footer>
        <div class="container">
            <div class="footer-parent">
                <div class="row">                    
                    @include('shop::layouts.footer.newsletter-subscription')
                    @include('shop::layouts.footer.footer-links')
                </div>
            </div>
            
            <div class="footer-copyright">
                @if (core()->getConfigData('general.content.footer.footer_toggle'))
                    @include('shop::layouts.footer.copy-right')
                @endif
            </div>
        </div>
    </footer><!-- End. footer -->


