{{--<div class="row footer-statics col-12 no-margin">
    @include('velocity::layouts.footer.footer-links.footer-left')
    @include('velocity::layouts.footer.footer-links.footer-middle')
    @include('velocity::layouts.footer.footer-links.footer-right')
</div> --}}
<div class="col-sm-3"></div>
<div class="col-sm-2">
        <div class="footer-navigation ft-common">
            <h3>about us</h3>
            <ul>
                <li><a href="{{ route('shop.about') }}">about</a></li>
                <li><a href="">support</a></li>
                <li><a href="{{ route('shop.authentication') }}">how we authenticate</a></li>
                <li><a href="{{ route('shop.terms') }}">terms of use</a></li>
                <li><a href="{{route('shop.privacy')}}">privacy</a></li>
                <li><a href="">careers</a></li>
                <li><a href="">contact us</a></li>
            </ul>
        </div>
</div>
<div class="col-sm-3">
        <div class="footer-customer-care ft-common">
            <h3>customer care</h3>
            <ul>
                <li><a href="">start selling</a></li>
                <li><a href="{{ URL::to('/jordan-1') }}">browse</a></li>
                <li><a href="">product request</a></li>
                <li><a href="{{ route('shop.authentication') }}">authentication service</a></li>
                <li><a href="">join power seller program</a></li>
            </ul>
        </div>
</div>
