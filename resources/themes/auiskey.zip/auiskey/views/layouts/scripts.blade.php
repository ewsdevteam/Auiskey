<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
        integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
        integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"
        integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6"
        crossorigin="anonymous"></script>

<script type="text/javascript" src="{{asset('themes/auiskey/assets/js/jquery.min.js')}}"></script>
<script type="text/javascript" src="{{asset('themes/auiskey/assets/js/jquery-ui.js')}}"></script>
<script type="text/javascript" src="{{asset('themes/auiskey/assets/js/rotate.js')}}"></script>
<script type="text/javascript" src="{{asset('themes/auiskey/assets/js/owl.carousel.min.js')}}"></script>
<script type="text/javascript" src="{{asset('themes/auiskey/assets/js/slick.js')}}"></script>
<script type="text/javascript" src="{{asset('themes/auiskey/assets/js/jquery.nice-select.js')}}"></script>
<script type="text/javascript" src="{{asset('themes/auiskey/assets/js/sweetalert2.all.min.js')}}"></script>
<script type="text/javascript" src="{{asset('themes/auiskey/assets/js/custom-code.js')}}"></script>
<script type="text/javascript" src="{{asset('themes/auiskey/assets/js/jquery.validate.js')}}"></script>

@stack('scripts')
<script type="text/javascript">
    //Code to display product slider
    
    $(document).ready(function(){
        $('.skeleton-loader').css('display','none');
        $('.slider').css('display','block');
    })
  //  window.Vue.config.devtools = true;
    // (() => {
     
    //     /* activate session messages */
    //     let message = @json($velocityHelper->getMessage());
    //     if (message.messageType && message.message !== '') {
    //         window.showAlert(message.messageType, message.messageLabel, message.message);
    //     }

    //     /* activate server error messages */
    //     window.serverErrors = [];
    //     @if (isset($errors))
    //         @if (count($errors))
    //             window.serverErrors = @json($errors->getMessages());
    //         @endif
    //     @endif

    //     /* add translations */
    //     window._translations = @json($velocityHelper->jsonTranslations());
    // })();
</script>


