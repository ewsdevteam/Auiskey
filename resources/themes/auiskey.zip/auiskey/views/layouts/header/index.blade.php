{{--<header class="sticky-header">
    <div class="row remove-padding-margin velocity-divide-page">
        <a class="left navbar-brand" href="{{ route('shop.home.index') }}" aria-label="Logo">
            <img class="logo" src="{{ core()->getCurrentChannel()->logo_url ?? asset('themes/velocity/assets/images/logo-text.png') }}" alt="" />
        </a>

        <div class="right searchbar">
            <div class="row">
                <div class="col-lg-5 col-md-12">
                    @include('velocity::shop.layouts.particals.search-bar')
                </div>

                <div class="col-lg-7 col-md-12 vc-full-screen">
                    <div class="left-wrapper">

                        {!! view_render_event('bagisto.shop.layout.header.wishlist.before') !!}

                            @include('velocity::shop.layouts.particals.wishlist', ['isText' => true])

                        {!! view_render_event('bagisto.shop.layout.header.wishlist.after') !!}

                        {!! view_render_event('bagisto.shop.layout.header.compare.before') !!}

                            @include('velocity::shop.layouts.particals.compare', ['isText' => true])

                        {!! view_render_event('bagisto.shop.layout.header.compare.after') !!}

                        {!! view_render_event('bagisto.shop.layout.header.cart-item.before') !!}

                            @include('shop::checkout.cart.mini-cart')

                        {!! view_render_event('bagisto.shop.layout.header.cart-item.after') !!}
                    </div>
                </div>
            </div>
        </div>
    </div>
</header> --}}
 
<div class="header-middle">
                <div class="container">
                    <div class="middle_part">
                        @if(Route::currentRouteName() == 'shop.news')
                        <div class="toggle-menu">
                        <div class="toggle_bars news-toggle news-toggle-btn">
                            <span class="icon_bars top_bar"></span>
                            <span class="icon_bars middle_bar"></span>
                            <span class="icon_bars bottom_bar"></span>
                        </div> <!-- End. toggle_bars -->

                        <div class="mega-menu">
                            <div class="mega-menu-list">
                                <div class="toggle_bars news-toggle">
                                    <span class="icon_bars top_bar"></span>
                                    <span class="icon_bars middle_bar"></span>
                                    <span class="icon_bars bottom_bar"></span>
                                </div> 
                                <nav id="news-nav">
                                    <h3>NEWS</h3>
                                    <ul>
                                        <li><a href="">Sneakers</a></li>
                                        <li><a href="">Streetwear</a></li>
                                        <li><a href="">Collectibles</a></li>
                                        <li><a href="">Handbags</a></li>
                                        <li><a href="">Watches</a></li>
                                        <li><a href="">Editorial</a></li>
                                        <li><a href="">Series</a></li>
                                        <li><a href="">Latest</a></li>
                                        <li><a href="">Selling</a></li>
                                        <li><a href="">Subscribe</a></li>
                                        <li><a href="">Shop StockX</a></li>
                                    </ul>
                                </nav>
                            </div>
                            <div class="mega-menu-slider">
                                <div class="news-mega-menu-slider owl-carousel owl-theme">
                                    <div class="mega-menu-slider-list">
                                        <a href="" title="latest news title"><img src="{{ asset('themes/auiskey/assets/img/brands/slider-1.png') }}" alt="slider-1"></a>
                                    </div>                                    
                                    <div class="mega-menu-slider-list">
                                        <a href="" title="latest news title"><img src="{{ asset('themes/auiskey/assets/img/brands/slider-1.png') }}" alt="slider-1"></a>
                                    </div>
                                    <div class="mega-menu-slider-list">
                                        <a href="" title="latest news title"><img src="{{ asset('themes/auiskey/assets/img/brands/slider-1.png') }}" alt="slider-1"></a>
                                    </div>
                                </div>
                            </div>
                        </div>   
                    </div> 
                        @else
                            <div class="toggle-menu">
                                <div class="toggle_bars mobile-menu-toggler">
                                    <span class="icon_bars top_bar"></span>
                                    <span class="icon_bars middle_bar"></span>
                                    <span class="icon_bars bottom_bar"></span>
                                </div>
                            </div>
                        @endif
                        
                        <div class="brand">
                            <div class="brand-view">
                                <a href="{{ route('shop.home.index') }}">
                                    @if ($logo = core()->getCurrentChannel()->logo_url)
                                        <img class="logo" src="{{ $logo }}" alt="" />
                                    @else
                                        <img src="{{asset('themes/auiskey/assets/img/brands/logo.png')}}" alt="stockX-logo">
                                    @endif    
                                </a>
                            </div>
                        </div>
                        <div class="search-engine">
                            <div class="header-search">
                                <form method="GET"
                                    role="search"
                                    id="search-form"
                                    action="{{ route('velocity.search.index') }}"
                                    >
                                    <div class="header-search-wrapper">
                                        <input type="search" class="form-control" name="q" id="q" placeholder="Search in..." required="">
                                        <a href="#" class="search-toggle" role="button"><i
                                                    class="far fa-search"></i></a>
                                    </div>
                                    <!-- End .header-search-wrapper -->
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    
        <!-- End of Header Section -->
