
@if(strpos(URL::previous(),'checkout/onepage'))
    @php
        session(['prev_url' => 'checkout/onepage']);
    @endphp
@else
    @php
        Session::forget('prev_url');
    @endphp
@endif


@extends('shop::layouts.master')

@section('page_title')
    {{ __('shop::app.customer.login-form.page-title') }}
@endsection
@push('css')
    <style>
        .error{
            color:#296242 !important; 
        }
    </style>
@endpush
@section('content-wrapper')
        <!-- Login Form Start -->
        <section class="login-form">
        <div class="container">
            <div class="login-sec">
                <div class="login-btns">
                    <div class="each-one">
                        <a href="{{ route('customer.session.index') }}" class="angle-btn btn-Primary active-angle-btn"><span>Login</span></a>
                        <a href="{{ route('customer.register.index') }}" class="angle-btn btn-Primary"><span>Signup</span></a>
                    </div>                                       
                </div>
                <div class="login-form-slider">
                    <!-- Slider -->
                    <div class="form-slider">
                        <div class="login-owl-carousel owl-carousel owl-theme">
                            <div class="item login-slider-item">
                                <img src="{{asset('themes/auiskey/assets/img/brands/login-slider-1.png')}}" alt="sneaker-1">
                            </div>
                            <div class="item login-slider-item">
                                <img src="{{asset('themes/auiskey/assets/img/brands/login-slider-1.png')}}" alt="sneaker-1">
                            </div>
                            <div class="item login-slider-item">
                                <img src="{{asset('themes/auiskey/assets/img/brands/login-slider-1.png')}}" alt="sneaker-1">
                            </div>
                        </div>
                    </div>
                    <!-- Form -->
                    <div class="login-form-sec">
                        <div class="stockX-logo">
                            <img src="{{asset('themes/auiskey/assets/img/brands/logo.png')}}" alt="stockX-logo">    
                        </div>
                        <form   method="POST"
                                action="{{ route('customer.session.create') }}"
                                id="login">

                            {{ csrf_field() }}

                            <div class="form-group">
                                <label for="Username">{{ __('shop::app.customer.login-form.email') }}</label>
                                <input type="text"
                                    class="form-control"
                                    name="email"
                                    value="{{ old('email') }}"
                                   >
                                @error('email')
                                    <span class = "error">{{ $message }}</span>
                                @endif
                            </div>
                            <div class="form-group">
                                <label for="Password">{{ __('shop::app.customer.login-form.password') }}
                                </label>

                                <input
                                    type="password"
                                    class="form-control"
                                    name="password"
                                    value="{{ old('password') }}"
                                   >
                                @error('password')
                                    <span class = "error">{{ $message }}</span>
                                @endif    
                                <span class="control-error" v-if="errors.has('password')" v-text="errors.first('password')"></span>
                            </div>
                            <div class="links-redirected">
                                <div class="remember-me">
                                    <input type="checkbox" name="" id="">
                                    <span>Remember me</span>
                                </div>
                                <a href="">Forget your password</a>
                            </div>
                            <input type="submit" value="Login" class="btn btn-Primary btn-submit">
                            <div class="continue-with">
                                <p>Continue with</p>
                                <ul>
                                    <li><a href=""><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href=""><i class="fab fa-twitter"></i></a></li>
                                    <li><a href=""><i class="fab fa-instagram"></i></a></li>
                                </ul>
                            </div>
                            <div class="account-ask">
                                <p>Don't have an account?</p>
                                <a href="{{ route('customer.register.index') }}">Sign up</a>
                            </div>
                        </form>
                    </div>
                </div> 
            </div>
        </div>
    </section>

@endsection
@push('scripts')
<script type = "text/javascript">
  $(document).ready(function(){
            $('#login').validate({
            rules:{
                email: {
                required: true,
                email: true
                },
                password: {
                required: true,
                },
            },
            messages:{
                email : {
                required: 'Enter your email',
                email: 'Email format in incorrect'
                },
                password : {
                required: 'Enter your password',
                },

            }
    })     
            
    })
</script>
@endpush

@push('scripts')

{!! Captcha::renderJS() !!}

@endpush