
@extends('shop::customers.account.index')

@section('page_title')
    {{ __('shop::app.customer.account.order.index.page-title') }}
@endsection

@section('page-detail-wrapper')
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper security-content">
<!-- Main content -->
    <section class="content element-setting ">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="security-container">
                        <h4 class="title-text">Buying</h4>
                    </div>
                </div>
        
                <div class="col-lg-12">
                            <div class="card card-primary card-outline card-tabs">
                                <div class="card-header p-0 pt-1 border-bottom-0">
                                    <ul class="nav nav-tabs" id="custom-tabs-three-tab" role="tablist">
                                        <li class="nav-item">
                                            <a class="nav-link active" id="custom-tabs-three-home-tab"
                                                data-toggle="pill" href="#custom-tabs-three-home" role="tab"
                                                aria-controls="custom-tabs-three-home" aria-selected="true">Current</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" id="custom-tabs-three-profile-tab" data-toggle="pill"
                                                href="#custom-tabs-three-profile" role="tab"
                                                aria-controls="custom-tabs-three-profile"
                                                aria-selected="false">Pending</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" id="custom-tabs-three-messages-tab" data-toggle="pill"
                                                href="#custom-tabs-three-messages" role="tab"
                                                aria-controls="custom-tabs-three-messages"
                                                aria-selected="false">History</a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="card-body">
                                    <div class="tab-content" id="custom-tabs-three-tabContent">
                                        <div class="tab-pane fade show active" id="custom-tabs-three-home"
                                            role="tabpanel" aria-labelledby="custom-tabs-three-home-tab">
                                            <!-- Product List -->
                                            <div class="product-listing-sec">
                                                @foreach($orders as $order)
                                                    @if(strtotime($order->created_at) > strtotime("-30 days"))
                                                    <div class="product-listing">
                                                        <div class="list-item product-img-title">
                                                            <div class="list-img">
                                                                @php
                                                                    $productBaseImage = $order->items[0]->product->getTypeInstance()->getBaseImage($order->items[0]);
                                                                @endphp
                                                                <img src="{{ $productBaseImage['original_image_url'] }}" alt="{{ $order->items[0]->name }}">
                                                            </div>
                                                            
                                                            <div class="list-title">
                                                                <p class="product-title">{{ $order->items[0]->name }}</p>
                                                                <p>           
                                                                    @if (isset($order->items[0]->additional['attributes']))
                                                        
                                                                            @foreach ($order->items[0]->additional['attributes'] as $attribute)
                                                                                <b>{{ $attribute['attribute_name'] }} : </b>{{ $attribute['option_label'] }}</br>
                                                                            @endforeach

                                                                    @endif 
                                                                </p>
                                                            </div>
                                                        </div>
                                                        <div class="list-item">
                                                            <p>Buying in {{ $order->created_at->format('F, d Y') }}</p>
                                                        </div>
                                                        @if($order->status == 'pending')
                                                            @php
                                                                $status = '25%';
                                                                $bar = 'info'            
                                                            @endphp
                                                        @elseif($order->status == 'processing')
                                                            @php
                                                                $status = '65%';
                                                                $bar = 'info'            
                                                            @endphp
                                                        @elseif($order->status == 'completed')
                                                            @php
                                                                $status = '100%';
                                                                $bar = 'info'            
                                                            @endphp
                                                        @elseif($order->status == 'canceled')
                                                            @php
                                                                $status = '100%';
                                                                $bar = 'danger'            
                                                            @endphp
                                                        @elseif($order->status == 'closed')
                                                            @php
                                                                $status = '100%';
                                                                $bar = 'success'            
                                                            @endphp                                        
                                                        @endif
                                                        <div class="list-item">
                                                            <div class="progress progress-xs">
                                                                <div class="progress-bar progress-bar-{{ $bar }}"
                                                                    style="width: {{ $status }}"></div>
                                                            </div>
                                                            <a class="badge badge-{{$bar}}">{{ $order->status }}</a>
                                                        </div>
                                                        <div class="list-item">
                                                            <a href="{{ route('customer.orders.view',['id' => $order->id]) }}" class="view_buying"><i class="far fa-eye"></i></a>
                                                        </div>
                                                    </div>
                                                    @endif
                                                @endforeach
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="custom-tabs-three-profile" role="tabpanel"
                                            aria-labelledby="custom-tabs-three-profile-tab">
                                            <!-- Product List -->
                                            <div class="product-listing-sec">

                                                @foreach($orders as $order)
                                                    @if($order->status == 'pending')
                                                    <div class="product-listing">
                                                        <div class="list-item product-img-title">
                                                            <div class="list-img">
                                                                @php
                                                                    $productBaseImage = $order->items[0]->product->getTypeInstance()->getBaseImage($order->items[0]);
                                                                @endphp
                                                                <img src="{{ $productBaseImage['original_image_url'] }}" alt="{{ $order->items[0]->name }}">
                                                            </div>
                                                            
                                                            <div class="list-title">
                                                                <p class="product-title">{{ $order->items[0]->name }}</p>
                                                                <p>           
                                                                    @if (isset($order->items[0]->additional['attributes']))
                                                        
                                                                            @foreach ($order->items[0]->additional['attributes'] as $attribute)
                                                                                <b>{{ $attribute['attribute_name'] }} : </b>{{ $attribute['option_label'] }}</br>
                                                                            @endforeach

                                                                    @endif 
                                                                </p>
                                                            </div>
                                                        </div>
                                                        <div class="list-item">
                                                            <p>Buying in {{ $order->created_at->format('F, d Y') }}</p>
                                                        </div>
                                                        @if($order->status == 'pending')
                                                            @php
                                                                $status = '25%';
                                                                $bar = 'info'            
                                                            @endphp
                                                        @elseif($order->status == 'processing')
                                                            @php
                                                                $status = '65%';
                                                                $bar = 'info'            
                                                            @endphp
                                                        @elseif($order->status == 'completed')
                                                            @php
                                                                $status = '100%';
                                                                $bar = 'info'            
                                                            @endphp
                                                        @elseif($order->status == 'canceled')
                                                            @php
                                                                $status = '100%';
                                                                $bar = 'danger'            
                                                            @endphp
                                                        @elseif($order->status == 'closed')
                                                            @php
                                                                $status = '100%';
                                                                $bar = 'success'            
                                                            @endphp                                        
                                                        @endif
                                                        <div class="list-item">
                                                            <div class="progress progress-xs">
                                                                <div class="progress-bar progress-bar-{{ $bar }}"
                                                                    style="width: {{ $status }}"></div>
                                                            </div>
                                                            <a class="badge badge-{{$bar}}">{{ $order->status }}</a>
                                                        </div>
                                                        <div class="list-item">
                                                            <a href="{{ route('customer.orders.view',['id' => $order->id]) }}" class="view_buying"><i class="far fa-eye"></i></a>
                                                        </div>
                                                    </div>
                                                    @endif
                                                @endforeach

                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="custom-tabs-three-messages" role="tabpanel"
                                            aria-labelledby="custom-tabs-three-messages-tab">
                                            <!-- Product List -->
                                            <div class="product-listing-sec">

                                                @foreach($orders as $order)
                                                    <div class="product-listing">
                                                        <div class="list-item product-img-title">
                                                            <div class="list-img">
                                                                @php
                                                                    $productBaseImage = $order->items[0]->product->getTypeInstance()->getBaseImage($order->items[0]);
                                                                @endphp
                                                                <img src="{{ $productBaseImage['original_image_url'] }}" alt="{{ $order->items[0]->name }}">
                                                            </div>
                                                            
                                                            <div class="list-title">
                                                                <p class="product-title">{{ $order->items[0]->name }}</p>
                                                                <p>           
                                                                    @if (isset($order->items[0]->additional['attributes']))
                                                        
                                                                            @foreach ($order->items[0]->additional['attributes'] as $attribute)
                                                                                <b>{{ $attribute['attribute_name'] }} : </b>{{ $attribute['option_label'] }}</br>
                                                                            @endforeach

                                                                    @endif 
                                                                </p>
                                                            </div>
                                                        </div>
                                                        <div class="list-item">
                                                            <p>Buying in {{ $order->created_at->format('F, d Y') }}</p>
                                                        </div>
                                                        @if($order->status == 'pending')
                                                            @php
                                                                $status = '25%';
                                                                $bar = 'info'            
                                                            @endphp
                                                        @elseif($order->status == 'processing')
                                                            @php
                                                                $status = '65%';
                                                                $bar = 'info'            
                                                            @endphp
                                                        @elseif($order->status == 'approved')
                                                            @php
                                                                $status = '100%';
                                                                $bar = 'info'            
                                                            @endphp
                                                        @elseif($order->status == 'canceled')
                                                            @php
                                                                $status = '100%';
                                                                $bar = 'danger'            
                                                            @endphp
                                                        @elseif($order->status == 'rejected')
                                                            @php
                                                                $status = '100%';
                                                                $bar = 'success'            
                                                            @endphp                                        
                                                        @endif
                                                        <div class="list-item">
                                                            <div class="progress progress-xs">
                                                                <div class="progress-bar progress-bar-{{ $bar }}"
                                                                    style="width: {{ $status }}"></div>
                                                            </div>
                                                            <a class="badge badge-{{$bar}}">{{ $order->status }}</a>
                                                        </div>
                                                        <div class="list-item">
                                                            <a href="{{ route('customer.orders.view',['id' => $order->id]) }}" class="view_buying"><i class="far fa-eye"></i></a>
                                                        </div>
                                                    </div>
                                                   
                                                @endforeach

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.card -->
                            </div>
                        </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
<!-- /.content -->
</div>
@endsection