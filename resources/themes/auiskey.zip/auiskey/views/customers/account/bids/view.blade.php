@extends('shop::customers.account.index')

@section('page_title')
    {{ __('shop::app.customer.account.order.view.page-tile', ['order_id' => $bid->increment_id]) }}
@endsection

@section('page-detail-wrapper')
<div class="content-wrapper security-content">
            <!-- Main content -->
            <section class="content element-setting ">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="security-container">
                                <h4 class="title-text"> {{ "Bid #:". $bid->bid_id }}</h4>
                                <p>This table will show you your current, information & invoices.</p>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="card card-primary card-outline card-tabs">
                                <div class="card-header p-0 pt-1 border-bottom-0">
                                    <ul class="nav nav-tabs" id="custom-tabs-three-tab" role="tablist">
                                        <li class="nav-item">
                                            <a class="nav-link active" id="custom-tabs-three-profile-tab"
                                                data-toggle="pill" href="#custom-tabs-info" role="tab"
                                                aria-controls="custom-tabs-three-home"
                                                aria-selected="true">Information</a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="card-body">
                                    <div class="tab-content" id="custom-tabs-three-tabContent">
                                        <div class="tab-pane fade show active" id="custom-tabs-info"
                                            role="tabpanel" aria-labelledby="custom-tabs-info">
                                            <div class="dates_cont">
                                                <h5>
                                                    <span><strong>{{ __('shop::app.customer.account.order.view.placed-on') }} </span> <span>  {{ core()->formatDate($bid->created_at, 'd M Y') }}</strong></span>
                                                </h5>
                                            </div>
                                            <!-- Order Review Table -->
                                            <div class="card-body table-responsive p-0">
                                                <table class="table table-hover text-nowrap">
                                                    <thead>
                                                        <tr>
                                                            <th>{{ __('shop::app.customer.account.order.view.SKU') }}</th>
                                                            <th>{{ __('shop::app.customer.account.order.view.product-name') }}</th>
                                                            <th>{{ __('shop::app.customer.account.order.view.price') }}</th>
                                                            <th>{{ __('shop::app.customer.account.order.view.item-status') }}</th>
                                                            <th>{{ __('shop::app.customer.account.order.view.subtotal') }}</th>
                                                            <th>{{ __('shop::app.customer.account.order.view.tax-percent') }}</th>
                                                            <th>{{ __('shop::app.customer.account.order.view.tax-amount') }}</th>
                                                            <th>{{ __('shop::app.customer.account.order.view.grand-total') }}</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                @foreach ($bid->items as $item)
                                                <tr>
                                                    <td data-value="{{ __('shop::app.customer.account.order.view.SKU') }}">
                                                        {{ $item->product->sku }}
                                                    </td>

                                                    <td data-value="{{ __('shop::app.customer.account.order.view.product-name') }}">
                                                        {{ $item->name }}

                                                        @if (isset($item->additional['attributes']))
                                                            <div class="item-options">

                                                                @foreach ($item->additional['attributes'] as $attribute)
                                                                    <b>{{ $attribute['attribute_name'] }} : </b>{{ $attribute['option_label'] }}</br>
                                                                @endforeach

                                                            </div>
                                                        @endif
                                                    </td>

                                                    <td data-value="{{ __('shop::app.customer.account.order.view.price') }}">
                                                        {{ core()->formatPrice($item->price, $bid->cart_currency_code) }}
                                                    </td>

                                                    <td data-value="{{ __('shop::app.customer.account.order.view.item-status') }}">
                                                        <span class="qty-row">
                                                            {{ $bid->status }}
                                                        </span>
                                                    </td>

                                                    <td data-value="{{ __('shop::app.customer.account.order.view.subtotal') }}">
                                                        {{ core()->formatPrice($item->total, $bid->cart_currency_code) }}
                                                    </td>

                                                    <td data-value="{{ __('shop::app.customer.account.order.view.tax-percent') }}">
                                                        {{ number_format($item->tax_percent, 2) }}%
                                                    </td>

                                                    <td data-value="{{ __('shop::app.customer.account.bid.view.tax-amount') }}">
                                                        {{ core()->formatPrice($item->tax_amount, $bid->cart_currency_code) }}
                                                    </td>

                                                    <td data-value="{{ __('shop::app.customer.account.order.view.grand-total') }}">
                                                        {{ core()->formatPrice($item->total + $item->tax_amount - $item->discount_amount, $bid->cart_currency_code) }}
                                                    </td>
                                                </tr>
                                            @endforeach
                                            </tbody>
                                                </table>
                                            </div>

                                            <div class="totals">
                                            <table class="sale-summary">
                                            <tbody>
                                                <tr>
                                                    <td>{{ __('shop::app.customer.account.order.view.subtotal') }}
                                                        <span class="dash-icon">-</span>
                                                    </td>
                                                    <td>{{ core()->formatPrice($bid->sub_total, $bid->cart_currency_code) }}</td>
                                                </tr>

                                                @if ($bid->haveStockableItems())
                                                    <tr>
                                                        <td>{{ __('shop::app.customer.account.order.view.shipping-handling') }}
                                                            <span class="dash-icon">-</span>
                                                        </td>
                                                        <td>{{ core()->formatPrice($bid->shipping_amount, $bid->cart_currency_code) }}</td>
                                                    </tr>
                                                @endif

                                                @if ($bid->base_discount_amount > 0)
                                                    <tr>
                                                        <td>{{ __('shop::app.customer.account.order.view.discount') }}
                                                            @if ($bid->coupon_code)
                                                                ({{ $bid->coupon_code }})
                                                            @endif
                                                            <span class="dash-icon">-</span>
                                                        </td>
                                                        <td>{{ core()->formatPrice($bid->discount_amount, $bid->cart_currency_code) }}</td>
                                                    </tr>
                                                @endif

                                                <tr class="border-bottom">
                                                    <td>{{ __('shop::app.customer.account.order.view.tax') }}
                                                        <span class="dash-icon">-</span>
                                                    </td>
                                                    <td>{{ core()->formatPrice($bid->tax_amount, $bid->cart_currency_code) }}</td>
                                                </tr>

                                                <tr class="fw6">
                                                    <td>{{ __('shop::app.customer.account.order.view.grand-total') }}
                                                        <span class="dash-icon">-</span>
                                                    </td>
                                                    <td>{{ core()->formatPrice($bid->grand_total, $bid->cart_currency_code) }}</td>
                                                </tr>

                                                <tr class="fw6">
                                                    <td>{{ __('shop::app.customer.account.order.view.total-paid') }}
                                                        <span class="dash-icon">-</span>
                                                    </td>
                                                    <td>{{ core()->formatPrice($bid->grand_total_invoiced, $bid->cart_currency_code) }}</td>
                                                </tr>

                                                <tr class="fw6">
                                                    <td>{{ __('shop::app.customer.account.order.view.total-refunded') }}
                                                        <span class="dash-icon">-</span>
                                                    </td>
                                                    <td>{{ core()->formatPrice($bid->grand_total_refunded, $bid->cart_currency_code) }}</td>
                                                </tr>

                                                <tr class="fw6">
                                                    <td>{{ __('shop::app.customer.account.order.view.total-due') }}
                                                        <span class="dash-icon">-</span>
                                                    </td>

                                                    @if($bid->status !== 'canceled')
                                                        <td>{{ core()->formatPrice($bid->total_due, $bid->cart_currency_code) }}</td>
                                                    @else
                                                        <td>{{ core()->formatPrice(0.00, $bid->cart_currency_code) }}</td>
                                                    @endif
                                                </tr>
                                            <tbody>
                                            </table>
                                            </div>



                                            <div class="buying_reviews_container">
                                                <div class="br_item">
                                                    <h4>Billing Address</h4>
                                                    @include ('admin::sales.address', ['address' => $bid->billing_address])
                                                    {!! view_render_event('bagisto.shop.customers.account.orders.view.billing-address.after', ['order' => $bid]) !!}  
                                                </div>
                                                @if ($bid->shipping_address)
                                                    <div class="br_item">
                                                        <h4>
                                                            {{ __('shop::app.customer.account.order.view.shipping-address') }}
                                                        </h4>

                                                            @include ('admin::sales.address', ['address' => $bid->shipping_address])

                                                            {!! view_render_event('bagisto.shop.customers.account.bids.view.shipping-address.after', ['order' => $bid]) !!}
                                                    </div>

                                                    <div class="br_item">
                                                        <h4>
                                                            {{ __('shop::app.customer.account.order.view.shipping-method') }}
                                                        </h4>

                                                        <p>
                                                            {{ $bid->shipping_title }}

                                                            {!! view_render_event('bagisto.shop.customers.account.orders.view.shipping-method.after', ['order' => $bid]) !!}
                                                        </p>
                                                    </div>
                                                @endif
                                                
                                                <div class="br_item">
                                                    <h4>
                                                        {{ __('shop::app.customer.account.order.view.payment-method') }}
                                                    </h4>

                                                    <p>
                                                        {{ core()->getConfigData('sales.paymentmethods.' . $bid->payment->method . '.title') }}

                                                        @php $additionalDetails = \Webkul\Payment\Payment::getAdditionalDetails($bid->payment->method); @endphp

                                                        @if (! empty($additionalDetails))
                                                            <div class="instructions">
                                                                <label>{{ $additionalDetails['title'] }}</label>
                                                                <p>{{ $additionalDetails['value'] }}</p>
                                                            </div>
                                                        @endif

                                                        {!! view_render_event('bagisto.shop.customers.account.orders.view.payment-method.after', ['order' => $bid]) !!}
                                                    </p>
                                                </div>
                                            </div>

                                        </div>

                                    </div>
                                </div>
                                <!-- /.card -->
                            </div>
                        </div>
                       
                    </div>
                </div><!-- /.container-fluid -->
            </section>
            <!-- /.content -->
        </div>

@endsection

@push('scripts')
    <script>
        function cancelOrder(message) {
            if (! confirm(message)) {
                return;
            }

            $('#cancelOrderForm').submit();
        }
    </script>
@endpush