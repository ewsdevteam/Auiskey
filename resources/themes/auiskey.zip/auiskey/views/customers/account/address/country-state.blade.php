        <div>
            <div class="control-group"><label for="country" class="mandatory">
                    Country
                </label> 
                <select type="text" v-validate="'required'" class="form-control" id="country" name="country" v-model="country" data-vv-as="&quot;{{ __('shop::app.customer.account.address.create.country') }}&quot;">
                    <option value=""></option>
                    @foreach (core()->countries() as $country)
                        <option {{ $country->code === $defaultCountry || (isset($address->country) && $country->code == $address->country) ? 'selected' : '' }}  value="{{ $country->code }}">{{ $country->name }}</option>
                    @endforeach
                </select>
                <div class="select-icon-container"><span
                        class="select-icon rango-arrow-down"></span></div>
                @error('country')
                    <span class = "error">{{$message}}</span>
                @enderror
            </div>
            <div class="control-group"><label for="state" class="mandatory">
                State
            </label>
                <input
                    id="state"
                    type="text"
                    name="state"
                    class="form-control"
                    v-if="!haveStates()"
                    v-validate="'required'"
                    data-vv-as="&quot;{{ __('shop::app.customer.account.address.create.state') }}&quot;" />
                    @error('state')
                        <span class = "error">{{$message}}</span>
                    @enderror   
            </div>
        </div>

