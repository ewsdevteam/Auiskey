@extends('shop::customers.account.index')

@section('page_title')
    {{ __('shop::app.customer.account.address.index.page-title') }}
@endsection

@section('page-detail-wrapper')
            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper security-content">
            <!-- Main content -->
            <section class="content element-setting ">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="profile-heading security-container">
                                <div class="active-ask">
                                    <div class="address_head">
                                        <h4 class="title-text">Addresses</h4>
                                        <a href = "{{ route('customer.address.create') }}" class="btn btn-Primary add-address">Add Address</a>
                                    </div>
                                </div>
                            </div>
                            {!! view_render_event('bagisto.shop.customers.account.address.list.before', ['addresses' => $addresses]) !!}    
                            <div class="col-md-12">
                                <div class="addresses-list">
                                 
                                @foreach ($addresses as $address)
                                    <div class="address-card">
                                        <h4>{{ $address->first_name }} {{ $address->last_name }}</h4>                                        
                                            <ul type="none">
                                                {{-- <li>{{ $address->company_name }}</li> --}}
                                                <li>{{ $address->address1 }},</li>
                                                <li>{{ $address->city }},</li>
                                                <li>{{ $address->state }},</li>
                                                <li>{{ core()->country_name($address->country) }} {{ $address->postcode }}</li>
                                                <li>
                                                    {{ __('shop::app.customer.account.address.index.contact') }} : {{$address->phone }}
                                                </li>
                                            </ul>
                                        <div class="btns-links">
                                            <a href = "{{ route('customer.address.edit', $address->id) }}" class="btn btn-link">Edit</a>
                                            <a href="javascript:void(0);" onclick="deleteAddress('{{ __('shop::app.customer.account.address.index.confirm-delete') }}')">Delete</a>
                                            <form id="deleteAddressForm" action="{{ route('address.delete', $address->id) }}" method="post">
                                                @method('delete')
                                                @csrf
                                            </form>
                                        </div>
                                    </div>
                                @endforeach    
                                </div>
                            </div>
                            {!! view_render_event('bagisto.shop.customers.account.address.list.after', ['addresses' => $addresses]) !!}

                            
                        </div>
                    </div>
                </div><!-- /.container-fluid -->
            </section>
            <!-- /.content -->
        </div>

@endsection

@push('scripts')
    <script>
        function deleteAddress(message) {
            if (! confirm(message)) {
                return;
            }

            $('#deleteAddressForm').submit();
        }
    </script>
@endpush

@if ($addresses->isEmpty())
    <style>
        a#add-address-button {
            position: absolute;
            margin-top: 92px;
        }

        .address-button {
            position: absolute;
            z-index: 1 !important;
            margin-top: 110px !important;
        }
    </style>
@endif
