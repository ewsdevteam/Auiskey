@extends('shop::customers.account.index')

@section('page_title')
    {{ __('shop::app.customer.account.address.edit.page-title') }}
@endsection

@section('page-detail-wrapper')
<div class="content-wrapper security-content">
            <!-- Main content -->
            <section class="content element-setting ">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="profile-heading security-container">
                                <div class="active-ask">
                                    <div class="active-ask-left active-ask-item">
                                        <h4 class="title-text">{{ __('shop::app.customer.account.address.edit.title') }}</h4>
                                    </div>
                                </div>
                            </div>



                            <div class="row">
                                <div class="col-12">
                                    <form method="post" action="{{ route('customer.address.update', $address->id) }}" class="edit__address">
                                    @method('PUT')
                                    @csrf
                                        
                                        <div class="account-table-content">
                                            <div class="control-group">
                                                <label for="company_name">Company name</label>
                                                <input type="text" name="company_name" value="{{ old('company_name') ?? $address->company_name }}"
                                                    data-vv-as="&quot;Company name&quot;" class="form-control">
                                                @error('company_name')
                                                    <span class = "error">{{$message}}</span>
                                                @enderror                                                                        
                                                <!---->
                                            </div>
                                            <div class="control-group"><label for="first_name">{{ __('shop::app.customer.account.address.create.first_name') }}</label>
                                                <input type="text" class="form-control" name="first_name" value="{{ old('first_name') ?? $address->first_name }}" data-vv-as="&quot;{{ __('shop::app.customer.account.address.create.company_name') }}&quot;">
                                                @error('first_name')
                                                    <span class = "error">{{$message}}</span>
                                                @enderror
                                            </div>
                                            <div class="control-group"><label for="last_name" class="mandatory">{{ __('shop::app.customer.account.address.create.last_name') }}</label>
                                                <input type="text" class="form-control" name="last_name" value="{{ old('last_name') ?? $address->last_name }}" v-validate="'required'" data-vv-as="&quot;{{ __('shop::app.customer.account.address.create.last_name') }}&quot;">    
                                                @error('last_name')
                                                    <span class = "error">{{$message}}</span>
                                                @enderror
                                            </div>
                                            <div class="control-group"><label for="vat_id">{{ __('shop::app.customer.account.address.create.vat_id') }}
                                                <span class="help-note">{{ __('shop::app.customer.account.address.create.vat_help_note') }}</span>
                                                </label>
                                                <input type="text" class="form-control" name="vat_id" value="{{ old('vat_id') ?? $address->vat_id }}" v-validate="" data-vv-as="&quot;{{ __('shop::app.customer.account.address.create.vat_id') }}&quot;">
                                                @error('vat_id')
                                                    <span class = "error">{{$message}}</span>
                                                @enderror
                                            </div>
                                            <?php $addresses = explode(PHP_EOL, (old('address1') ?? $address->address1)); ?>
                                            <div class="control-group"><label for="address_0" class="mandatory">{{ __('shop::app.customer.account.address.create.street-address') }}</label>
                                                <input type="text" class="form-control" name="address1[]" id="address_0" value="{{ isset($addresses[0]) ? $addresses[0] : '' }}" v-validate="'required'" data-vv-as="&quot;{{ __('shop::app.customer.account.address.create.street-address') }}&quot;">
                                                @error('address1')
                                                    <span class = "error">{{$message}}</span>
                                                @enderror
                                            </div>
                                            @if (core()->getConfigData('customer.settings.address.street_lines') && core()->getConfigData('customer.settings.address.street_lines') > 1)
                                                @for ($i = 1; $i < core()->getConfigData('customer.settings.address.street_lines'); $i++)
                                                    <div class="control-group" style="margin-top: -25px;">
                                                        <input type="text" class=form-control" name="address1[{{ $i }}]" id="address_{{ $i }}" value="{{ $addresses[$i] ?? '' }}">
                                                    </div>
                                                @endfor
                                            @endif
                                            @include ('shop::customers.account.address.country-state', ['countryCode' => old('country'), 'stateCode' => old('state')])
                                            
                                            <div class="control-group"><label for="city" class="mandatory">{{ __('shop::app.customer.account.address.create.city') }}</label>
                                            <input type="text" class="form-control" name="city" value="{{ old('city') ?? $address->city }}" v-validate="'required'" data-vv-as="&quot;{{ __('shop::app.customer.account.address.create.city') }}&quot;">
                                                @error('city')
                                                    <span class = "error">{{$message}}</span>
                                                @enderror
                                            </div>
                                            <div class="control-group">  <label for="postcode" class="mandatory">{{ __('shop::app.customer.account.address.create.postcode') }}</label>
                                            <input type="text" class="form-control" name="postcode" value="{{ old('postcode') ?? $address->postcode }}" v-validate="'required'" data-vv-as="&quot;{{ __('shop::app.customer.account.address.create.postcode') }}&quot;">
                                                @error('postcode')
                                                    <span class = "error">{{$message}}</span>
                                                @enderror
                                            </div>
                                            <div class="control-group"><label for="phone" class="mandatory">{{ __('shop::app.customer.account.address.create.phone') }}</label>
                                            <input type="text" class="form-control" name="phone" value="{{ old('phone') ?? $address->phone }}" v-validate="'required'" data-vv-as="&quot;{{ __('shop::app.customer.account.address.create.phone') }}&quot;">
                                                @error('phone')
                                                    <span class = "error">{{$message}}</span>
                                                @enderror
                                            </div>
                                            <div class="control-group d-flex">
                                                <input type="checkbox" id="default_address" class="w-auto" name="default_address" {{ $address->default_address ? 'checked' : '' }}>

                                                <label class="checkbox-view" for="default_address"></label>

                                                {{ __('shop::app.customer.account.address.default-address') }}
                                            </div>
                                            <div class="button-group">
                                                <button type="submit" class="btn btn-primary">
                                                    Save Address
                                                </button></div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!-- /.container-fluid -->
            </section>
            <!-- /.content -->
        </div>
   
    {!! view_render_event('bagisto.shop.customers.account.address.edit.after', ['address' => $address]) !!}
@endsection