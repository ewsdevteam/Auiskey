@extends('shop::customers.account.index')

@section('page-detail-wrapper')
<div class="content-wrapper security-content">
            <!-- Main content -->
            <section class="content element-setting ">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="security-container">
                                
                                <div class="profile-heading security-container following-sec">                                
                                    <div class="active-ask">
                                        <div class="active-ask-left active-ask-item">
                                            <h4 class="title-text">Following</h4>
                                            <p>This table will show you how your any product market value.</p>
                                        </div>
                                        <div class="active-ask-right active-ask-item">
                                          <select class="form-control">
                                            <option>Add Product</option>
                                            <option>Edit Product</option>
                                            <option>Delete</option>
                                          </select>
                                        </div>
                                      </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-12">
                            <!-- data table -->
                            <table id="currentTable" class="table table-bordered table-hover">
                                <thead>
                                <tr>
                                    <th>Item</th>
                                    <th>Market Value</th>
                                    <th>Lowest Ask</th>
                                    <th>Last Sale</th>                                    
                                  </tr>
                                  </thead>
                                  <tbody>
                                  <tr>
                                    <td>
                                        <div class="products-list">
                                          <img src="{{asset('themes/auiskey/assets/customer-dashboard/dist/img/jordan-6.png')}}" alt="sneaker6" width="40px" height="40px">
                                          <div class="product-title-texts">
                                              <p>Jordan 12 Retro Utility</p>
                                              <p>Lowest Ask</p>                                                        
                                        </div>
                                      </div>
                                    </td>
                                    <td>A$200</td>
                                    <td>A$40</td>
                                    <td>A$417</td>
                                  </tr> 

                                  <tr>
                                    <td>
                                        <div class="products-list">
                                          <img src="{{asset('themes/auiskey/assets/customer-dashboard/dist/img/jordan-6.png')}}" alt="sneaker6" width="40px" height="40px">
                                          <div class="product-title-texts">
                                              <p>Jordan 12 Retro Utility</p>
                                              <p>Lowest Ask</p>                                                        
                                        </div>
                                      </div>
                                    </td>
                                    <td>A$650</td>
                                    <td>A$23</td>
                                    <td>A$417</td>
                                  </tr> 


                                  <tr>
                                    <td>
                                        <div class="products-list">
                                          <img src="{{asset('themes/auiskey/assets/customer-dashboard/dist/img/jordan-6.png')}}" alt="sneaker6" width="40px" height="40px">
                                          <div class="product-title-texts">
                                              <p>Jordan 12 Retro Utility</p>
                                              <p>Lowest Ask</p>                                                        
                                        </div>
                                      </div>
                                    </td>
                                    <td>A$417</td>
                                    <td>A$23</td>
                                    <td>A$65</td>
                                  </tr> 
                                </tbody>                                                
                              </table>
                        </div>
                    </div>
                </div><!-- /.container-fluid -->
            </section>
            <!-- /.content -->
        </div>

@stop