@extends('shop::customers.account.index')

@section('page-detail-wrapper')
     <!-- Content Wrapper. Contains page content -->
     <div class="content-wrapper security-content">
            <!-- Main content -->
            <section class="content element-setting ">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="security-container">
                                <h4 class="title-text">Buying</h4>
                                <p>This table will show you how your current, pending & history are behaving.</p>
                            </div>
                        </div>

                        <div class="col-lg-12">
                            <div class="card card-primary card-outline card-tabs">
                                <div class="card-header p-0 pt-1 border-bottom-0">
                                    <ul class="nav nav-tabs" id="custom-tabs-three-tab" role="tablist">
                                        <li class="nav-item">
                                            <a class="nav-link active" id="custom-tabs-three-home-tab"
                                                data-toggle="pill" href="#custom-tabs-three-home" role="tab"
                                                aria-controls="custom-tabs-three-home" aria-selected="true">Current</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" id="custom-tabs-three-profile-tab" data-toggle="pill"
                                                href="#custom-tabs-three-profile" role="tab"
                                                aria-controls="custom-tabs-three-profile"
                                                aria-selected="false">Pending</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" id="custom-tabs-three-messages-tab" data-toggle="pill"
                                                href="#custom-tabs-three-messages" role="tab"
                                                aria-controls="custom-tabs-three-messages"
                                                aria-selected="false">History</a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="card-body">
                                    <div class="tab-content" id="custom-tabs-three-tabContent">
                                        <div class="tab-pane fade show active" id="custom-tabs-three-home"
                                            role="tabpanel" aria-labelledby="custom-tabs-three-home-tab">
                                            <!-- Product List -->
                                            <div class="product-listing-sec">

                                                <div class="product-listing">
                                                    <div class="list-item product-img-title">
                                                        <div class="list-img">
                                                            <img src="{{asset('themes/auiskey/assets/customer-dashboard/dist/img/jordan-6.png')}}" alt="sneaker">
                                                        </div>
                                                        <div class="list-title">
                                                            <p class="product-title">Jordan 12 Retro Utility</p>
                                                            <p>Lowest Ask</p>
                                                        </div>
                                                    </div>
                                                    <div class="list-item">
                                                        <p>Released in August of 2021</p>
                                                    </div>
                                                    <div class="list-item">
                                                        <div class="progress progress-xs">
                                                            <div class="progress-bar progress-bar-pink"
                                                                style="width: 55%"></div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="product-listing">
                                                    <div class="list-item product-img-title">
                                                        <div class="list-img">
                                                            <img src="{{asset('themes/auiskey/assets/customer-dashboard/dist/img/jordan-6.png')}}" alt="sneaker">
                                                        </div>
                                                        <div class="list-title">
                                                            <p class="product-title">Jordan 12 Retro Utility</p>
                                                            <p>Lowest Ask</p>
                                                        </div>
                                                    </div>
                                                    <div class="list-item">
                                                        <p>Released in August of 2021</p>
                                                    </div>
                                                    <div class="list-item">
                                                        <div class="progress progress-xs">
                                                            <div class="progress-bar progress-bar-pink"
                                                                style="width: 55%"></div>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="custom-tabs-three-profile" role="tabpanel"
                                            aria-labelledby="custom-tabs-three-profile-tab">
                                            <!-- Product List -->
                                            <div class="product-listing-sec">

                                                <div class="product-listing">
                                                    <div class="list-item product-img-title">
                                                        <div class="list-img">
                                                            <img src="{{asset('themes/auiskey/assets/customer-dashboard/dist/img/jordan-6.png')}}" alt="sneaker">
                                                        </div>
                                                        <div class="list-title">
                                                            <p class="product-title">Jordan 12 Retro Utility</p>
                                                            <p>Lowest Ask</p>
                                                        </div>
                                                    </div>
                                                    <div class="list-item">
                                                        <p>Released in August of 2021</p>
                                                    </div>
                                                    <div class="list-item">
                                                        <div class="progress progress-xs">
                                                            <div class="progress-bar progress-bar-pink"
                                                                style="width: 55%"></div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="product-listing">
                                                    <div class="list-item product-img-title">
                                                        <div class="list-img">
                                                            <img src="{{asset('themes/auiskey/assets/customer-dashboard/dist/img/jordan-6.png')}}" alt="sneaker">
                                                        </div>
                                                        <div class="list-title">
                                                            <p class="product-title">Jordan 12 Retro Utility</p>
                                                            <p>Lowest Ask</p>
                                                        </div>
                                                    </div>
                                                    <div class="list-item">
                                                        <p>Released in August of 2021</p>
                                                    </div>
                                                    <div class="list-item">
                                                        <div class="progress progress-xs">
                                                            <div class="progress-bar progress-bar-pink"
                                                                style="width: 55%"></div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="product-listing">
                                                    <div class="list-item product-img-title">
                                                        <div class="list-img">
                                                            <img src="{{asset('themes/auiskey/assets/customer-dashboard/dist/img/jordan-6.png')}}" alt="sneaker">
                                                        </div>
                                                        <div class="list-title">
                                                            <p class="product-title">Jordan 12 Retro Utility</p>
                                                            <p>Lowest Ask</p>
                                                        </div>
                                                    </div>
                                                    <div class="list-item">
                                                        <p>Released in August of 2021</p>
                                                    </div>
                                                    <div class="list-item">
                                                        <div class="progress progress-xs">
                                                            <div class="progress-bar progress-bar-pink"
                                                                style="width: 55%"></div>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="custom-tabs-three-messages" role="tabpanel"
                                            aria-labelledby="custom-tabs-three-messages-tab">
                                            <!-- Product List -->
                                            <div class="product-listing-sec">

                                                <div class="product-listing">
                                                    <div class="list-item product-img-title">
                                                        <div class="list-img">
                                                            <img src="{{asset('themes/auiskey/assets/customer-dashboard/dist/img/jordan-6.png')}}" alt="sneaker">
                                                        </div>
                                                        <div class="list-title">
                                                            <p class="product-title">Jordan 12 Retro Utility</p>
                                                            <p>Lowest Ask</p>
                                                        </div>
                                                    </div>
                                                    <div class="list-item">
                                                        <p>Released in August of 2021</p>
                                                    </div>
                                                    <div class="list-item">
                                                        <div class="progress progress-xs">
                                                            <div class="progress-bar progress-bar-pink"
                                                                style="width: 55%"></div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="product-listing">
                                                    <div class="list-item product-img-title">
                                                        <div class="list-img">
                                                            <img src="{{asset('themes/auiskey/assets/customer-dashboard/dist/img/jordan-6.png')}}" alt="sneaker">
                                                        </div>
                                                        <div class="list-title">
                                                            <p class="product-title">Jordan 12 Retro Utility</p>
                                                            <p>Lowest Ask</p>
                                                        </div>
                                                    </div>
                                                    <div class="list-item">
                                                        <p>Released in August of 2021</p>
                                                    </div>
                                                    <div class="list-item">
                                                        <div class="progress progress-xs">
                                                            <div class="progress-bar progress-bar-pink"
                                                                style="width: 55%"></div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="product-listing">
                                                    <div class="list-item product-img-title">
                                                        <div class="list-img">
                                                            <img src="{{asset('themes/auiskey/assets/customer-dashboard/dist/img/jordan-6.png')}}" alt="sneaker">
                                                        </div>
                                                        <div class="list-title">
                                                            <p class="product-title">Jordan 12 Retro Utility</p>
                                                            <p>Lowest Ask</p>
                                                        </div>
                                                    </div>
                                                    <div class="list-item">
                                                        <p>Released in August of 2021</p>
                                                    </div>
                                                    <div class="list-item">
                                                        <div class="progress progress-xs">
                                                            <div class="progress-bar progress-bar-pink"
                                                                style="width: 55%"></div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="product-listing">
                                                    <div class="list-item product-img-title">
                                                        <div class="list-img">
                                                            <img src="{{asset('themes/auiskey/assets/customer-dashboard/dist/img/jordan-6.png')}}" alt="sneaker">
                                                        </div>
                                                        <div class="list-title">
                                                            <p class="product-title">Jordan 12 Retro Utility</p>
                                                            <p>Lowest Ask</p>
                                                        </div>
                                                    </div>
                                                    <div class="list-item">
                                                        <p>Released in August of 2021</p>
                                                    </div>
                                                    <div class="list-item">
                                                        <div class="progress progress-xs">
                                                            <div class="progress-bar progress-bar-pink"
                                                                style="width: 55%"></div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="product-listing">
                                                    <div class="list-item product-img-title">
                                                        <div class="list-img">
                                                            <img src="{{asset('themes/auiskey/assets/customer-dashboard/dist/img/jordan-6.png')}}" alt="sneaker">
                                                        </div>
                                                        <div class="list-title">
                                                            <p class="product-title">Jordan 12 Retro Utility</p>
                                                            <p>Lowest Ask</p>
                                                        </div>
                                                    </div>
                                                    <div class="list-item">
                                                        <p>Released in August of 2021</p>
                                                    </div>
                                                    <div class="list-item">
                                                        <div class="progress progress-xs">
                                                            <div class="progress-bar progress-bar-pink"
                                                                style="width: 55%"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.card -->
                            </div>
                        </div>
                    </div>
                </div><!-- /.container-fluid -->
            </section>
            <!-- /.content -->
        </div>


@stop