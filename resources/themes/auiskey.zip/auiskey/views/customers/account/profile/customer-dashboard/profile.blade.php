
@extends('shop::customers.account.index')

@section('page-detail-wrapper')
<div class="content-wrapper security-content">
            <!-- Main content -->
            <section class="content element-setting ">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="profile-heading security-container">                                
                                <div class="active-ask">
                                    <div class="active-ask-left active-ask-item">
                                        <h4 class="title-text">Profile</h4>
                                    </div>
                                    <div class="active-ask-right active-ask-item">
                                      <select class="form-control">
                                        <option>Edit</option>
                                        <option>Edit</option>
                                        <option>Edit</option>
                                        <option>Edit</option>
                                      </select>
                                    </div>
                                  </div>
                            </div>
                            <div class="profile-wrapper">
                                <div class="profile-wrapper-item">
                                    <div class="pr-sub-item">
                                        <p class="text-title-heading">Name</p>
                                        <p>{{ auth('customer')->user()->first_name . ' ' . auth('customer')->user()->last_name}}</p>
                                    </div>
                                    <div class="pr-sub-item">
                                        <p class="text-title-heading">Contact</p>
                                        <p>+1 72635 2517</p>
                                    </div>
                                </div>
                                <div class="profile-wrapper-item">
                                    <div class="pr-sub-item">
                                        <p class="text-title-heading">Email</p>
                                        <p>{{ auth('customer')->user()->email}}</p>
                                    </div>
                                    <div class="pr-sub-item">
                                        <p class="text-title-heading">Reset</p>
                                        <a href="" class="btn btn-bg-primary btn-sm reset-btn">Reset Password</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </div>
                </div><!-- /.container-fluid -->
            </section>
            <!-- /.content -->
</div>

@stop