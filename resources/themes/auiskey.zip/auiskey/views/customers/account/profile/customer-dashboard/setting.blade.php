@extends('shop::customers.account.index')

@section('page-detail-wrapper')
<div class="content-wrapper security-content">
            <!-- Main content -->
            <section class="content element-setting ">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <h4 class="title-text">Account Settings</h4>

                            <div class="account-setting">
                                <div class="account-info">
                                    <div class="info-list">
                                        <div class="profile-heading security-container following-sec">
                                            <div class="active-ask account-info-bdr">
                                                <div class="active-ask-left active-ask-item">
                                                    <h5 class="info-text-title">Buying Info</h5>
                                                </div>
                                                <div class="active-ask-right active-ask-item mb-2">
                                                    <a href = "{{ route('customer.address.index') }}">View</a>
                                                </div>
                                            </div>
                                            <p>You do not have any payment information on file.</p>
                                        </div>
                                    </div>
                                </div>


                                <div class="account-info">
                                    <div class="info-list">
                                        <div class="profile-heading security-container following-sec">
                                            <div class="active-ask account-info-bdr">
                                                <div class="active-ask-left active-ask-item">
                                                    <h5 class="info-text-title">Shipping Info</h5>
                                                </div>
                                                <div class="active-ask-right active-ask-item mb-2">
                                                    <select class="form-control">
                                                        <option>Edit</option>
                                                        <option>Edit</option>
                                                        <option>Edit</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <p>You do not have any shipping information on file.</p>
                                        </div>
                                    </div>
                                </div>



                                <div class="account-info">
                                    <div class="info-list">
                                        <div class="profile-heading security-container following-sec">
                                            <div class="active-ask account-info-bdr">
                                                <div class="active-ask-left active-ask-item">
                                                    <h5 class="info-text-title">Seller Info</h5>
                                                </div>
                                                <div class="active-ask-right active-ask-item mb-2">
                                                    <select class="form-control">
                                                        <option>Edit</option>
                                                        <option>Edit</option>
                                                        <option>Edit</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <p>You do not have any account information on file.</p>
                                        </div>
                                    </div>
                                </div>


                                <div class="account-info">
                                    <div class="info-list">
                                        <div class="profile-heading security-container following-sec">
                                            <div class="active-ask account-info-bdr">
                                                <div class="active-ask-left active-ask-item">
                                                    <h5 class="info-text-title">Payout Info</h5>
                                                </div>
                                                <div class="active-ask-right active-ask-item mb-2">
                                                    <select class="form-control">
                                                        <option>Edit</option>
                                                        <option>Edit</option>
                                                        <option>Edit</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <p>You do not have any account information on file.</p>
                                        </div>
                                    </div>
                                </div>

                            </div>


                            <div class="notification-setting">
                                <h4 class="notification-text">Notifications</h4>
                                <div class="notification-listing">
                                    <div class="notification-items">
                                        <div class="notification-container">
                                            <div class="info-text-title">
                                                <h5>Bidding, New Lowest Ask</h5>
                                            </div>
                                            <div class="center-line"></div>
                                            <div class="form-group">
                                                <div class="custom-control custom-switch">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="customSwitch1">
                                                    <label class="custom-control-label" for="customSwitch1"></label>
                                                </div>
                                            </div>
                                        </div>
                                        <p>Sent when a new Lowest Ask is placed on an item you're biding on. </p>
                                    </div>

                                    <div class="notification-items">
                                        <div class="notification-container">
                                            <div class="info-text-title">
                                                <h5>Bidding, New Highest Bid</h5>
                                            </div>
                                            <div class="center-line"></div>
                                            <div class="form-group">
                                                <div class="custom-control custom-switch">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="customSwitch2">
                                                    <label class="custom-control-label" for="customSwitch2"></label>
                                                </div>
                                            </div>
                                        </div>
                                        <p>Sent when a new highest Bid is placed on an item you have an active Bid on.
                                        </p>
                                    </div>


                                    <div class="notification-items">
                                        <div class="notification-container">
                                            <div class="info-text-title">
                                                <h5>Bid Expiring</h5>
                                            </div>
                                            <div class="center-line"></div>
                                            <div class="form-group">
                                                <div class="custom-control custom-switch">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="customSwitch3">
                                                    <label class="custom-control-label" for="customSwitch3"></label>
                                                </div>
                                            </div>
                                        </div>
                                        <p>Sent 24 hours before your active Bid expires.</p>
                                    </div>




                                    <div class="notification-items">
                                        <div class="notification-container">
                                            <div class="info-text-title">
                                                <h5>Bid Expired</h5>
                                            </div>
                                            <div class="center-line"></div>
                                            <div class="form-group">
                                                <div class="custom-control custom-switch">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="customSwitch4">
                                                    <label class="custom-control-label" for="customSwitch4"></label>
                                                </div>
                                            </div>
                                        </div>
                                        <p>Sent when your Bid has expired.</p>
                                    </div>



                                    <div class="notification-items">
                                        <div class="notification-container">
                                            <div class="info-text-title">
                                                <h5>Ask Matches Expired Bid</h5>
                                            </div>
                                            <div class="center-line"></div>
                                            <div class="form-group">
                                                <div class="custom-control custom-switch">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="customSwitch5">
                                                    <label class="custom-control-label" for="customSwitch5"></label>
                                                </div>
                                            </div>
                                        </div>
                                        <p>Sent if a seller lists a new Ask that matches one of your expired bids.</p>
                                    </div>



                                    <div class="notification-items">
                                        <div class="notification-container">
                                            <div class="info-text-title">
                                                <h5>Buyer Nearby Match</h5>
                                            </div>
                                            <div class="center-line"></div>
                                            <div class="form-group">
                                                <div class="custom-control custom-switch">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="customSwitch6">
                                                    <label class="custom-control-label" for="customSwitch6"></label>
                                                </div>
                                            </div>
                                        </div>
                                        <p>Sent if a seller lists an Ask at the same price, or lower, within 1/2 size of
                                            your existing Bid.</p>
                                    </div>


                                    <div class="notification-items">
                                        <div class="notification-container">
                                            <div class="info-text-title">
                                                <h5>Bid Accepted</h5>
                                            </div>
                                            <div class="center-line"></div>
                                            <div class="form-group">
                                                <div class="custom-control custom-switch">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="customSwitch7">
                                                    <label class="custom-control-label" for="customSwitch7"></label>
                                                </div>
                                            </div>
                                        </div>
                                        <p>Your bid has been accepted</p>
                                    </div>



                                    <div class="notification-items">
                                        <div class="notification-container">
                                            <div class="info-text-title">
                                                <h5>IPO Bid Almost Out of the Money</h5>
                                            </div>
                                            <div class="center-line"></div>
                                            <div class="form-group">
                                                <div class="custom-control custom-switch">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="customSwitch8">
                                                    <label class="custom-control-label" for="customSwitch8"></label>
                                                </div>
                                            </div>
                                        </div>
                                        <p>Sent when you're almost outbid to win an IPO.</p>
                                    </div>



                                    <div class="notification-items">
                                        <div class="notification-container">
                                            <div class="info-text-title">
                                                <h5>IPO Bid Out of the Money</h5>
                                            </div>
                                            <div class="center-line"></div>
                                            <div class="form-group">
                                                <div class="custom-control custom-switch">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="customSwitch9">
                                                    <label class="custom-control-label" for="customSwitch9"></label>
                                                </div>
                                            </div>
                                        </div>
                                        <p>Sent if you've been outbid for an IPO and must increase your Bid to win.</p>
                                    </div>



                                    <div class="notification-items">
                                        <div class="notification-container">
                                            <div class="info-text-title">
                                                <h5>IPO Bid Accepted</h5>
                                            </div>
                                            <div class="center-line"></div>
                                            <div class="form-group">
                                                <div class="custom-control custom-switch">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="customSwitch10">
                                                    <label class="custom-control-label" for="customSwitch10"></label>
                                                </div>
                                            </div>
                                        </div>
                                        <p>Sent when your IPO Bid has been accepted.</p>
                                    </div>



                                    <div class="notification-items">
                                        <div class="account-info">
                                            <div class="info-list">
                                                <h4 class="notification-text">Selling</h4>
                                                <div class="profile-heading security-container following-sec">
                                                    <div class="active-ask account-info-bdr">
                                                        <div class="active-ask-left active-ask-item">
                                                            <h5 class="info-text-title">Asking, New Highest Bid</h5>
                                                        </div>
                                                        <div class="active-ask-right active-ask-item mb-2">
                                                            <select class="form-control">
                                                                <option>65%</option>
                                                                <option>34%</option>
                                                                <option>18%</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <p>Sent when a new Highest Bid is placed on an item that is at least
                                                        X percent of your Ask.</p>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="notification-container">
                                            <div class="info-text-title">
                                                <h5>Sent when a new Lowest Ask is placed for an item you have an active
                                                    Ask for.</h5>
                                            </div>
                                            <div class="center-line"></div>
                                            <div class="form-group">
                                                <div class="custom-control custom-switch">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="customSwitch11">
                                                    <label class="custom-control-label" for="customSwitch11"></label>
                                                </div>
                                            </div>
                                        </div>
                                        <p>Sent when a new Lowest Ask is placed for an item you have an active Ask for.
                                        </p>
                                    </div>


                                    <div class="notification-items">
                                        <div class="notification-container">
                                            <div class="info-text-title">
                                                <h5>Ask Expiring</h5>
                                            </div>
                                            <div class="center-line"></div>
                                            <div class="form-group">
                                                <div class="custom-control custom-switch">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="customSwitch12">
                                                    <label class="custom-control-label" for="customSwitch12"></label>
                                                </div>
                                            </div>
                                        </div>
                                        <p>Sent 24 hours before your active Ask expires.</p>
                                    </div>


                                    <div class="notification-items">
                                        <div class="notification-container">
                                            <div class="info-text-title">
                                                <h5>Ask Expired</h5>
                                            </div>
                                            <div class="center-line"></div>
                                            <div class="form-group">
                                                <div class="custom-control custom-switch">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="customSwitch13">
                                                    <label class="custom-control-label" for="customSwitch13"></label>
                                                </div>
                                            </div>
                                        </div>
                                        <p>Sent when your Ask has expired.</p>
                                    </div>


                                    <div class="notification-items">
                                        <div class="notification-container">
                                            <div class="info-text-title">
                                                <h5>Item Sold</h5>
                                            </div>
                                            <div class="center-line"></div>
                                            <div class="form-group">
                                                <div class="custom-control custom-switch">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="customSwitch14">
                                                    <label class="custom-control-label" for="customSwitch14"></label>
                                                </div>
                                            </div>
                                        </div>
                                        <p>Your item has sold.</p>
                                    </div>


                                    <div class="notification-items">
                                        <div class="notification-container">
                                            <div class="info-text-title">
                                                <h5>First Seller Has Not Shipped</h5>
                                            </div>
                                            <div class="center-line"></div>
                                            <div class="form-group">
                                                <div class="custom-control custom-switch">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="customSwitch15">
                                                    <label class="custom-control-label" for="customSwitch15"></label>
                                                </div>
                                            </div>
                                        </div>
                                        <p>Sent when a seller hasn't shipped by the deadline.</p>
                                    </div>


                                    <div class="notification-items">
                                        <div class="notification-container">
                                            <div class="info-text-title">
                                                <h5>Second Seller Has Not Shipped</h5>
                                            </div>
                                            <div class="center-line"></div>
                                            <div class="form-group">
                                                <div class="custom-control custom-switch">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="customSwitch16">
                                                    <label class="custom-control-label" for="customSwitch16"></label>
                                                </div>
                                            </div>
                                        </div>
                                        <p>Sent when a seller still hasn't shipped after first notification</p>
                                    </div>


                                    <div class="notification-items">
                                        <div class="notification-container">
                                            <div class="info-text-title">
                                                <h5>Third Seller Has Not Shipped</h5>
                                            </div>
                                            <div class="center-line"></div>
                                            <div class="form-group">
                                                <div class="custom-control custom-switch">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="customSwitch17">
                                                    <label class="custom-control-label" for="customSwitch17"></label>
                                                </div>
                                            </div>
                                        </div>
                                        <p>Sent as a final warning when a seller hasn't shipped</p>
                                    </div>



                                    <div class="notification-items">
                                        <div class="account-info">
                                            <div class="info-list">
                                                <h4 class="notification-text">Subscription</h4>
                                            </div>
                                        </div>

                                        <div class="notification-container">
                                            <div class="info-text-title">
                                                <h5>StockX Product Features & Major Announcements</h5>
                                            </div>
                                            <div class="center-line"></div>
                                            <div class="form-group">
                                                <div class="custom-control custom-switch">
                                                    <input type="checkbox" class="custom-control-input" id="customSwitch18">
                                                    <label class="custom-control-label" for="customSwitch18"></label>
                                                </div>
                                            </div>
                                        </div>
                                        <p>StockX Product Features & Major Announcements</p>
                                    </div>


                                    <div class="notification-items">
                                        <div class="notification-container">
                                            <div class="info-text-title">
                                                <h5>Sneaker News & Promotions</h5>
                                            </div>
                                            <div class="center-line"></div>
                                            <div class="form-group">
                                                <div class="custom-control custom-switch">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="customSwitch19">
                                                    <label class="custom-control-label" for="customSwitch19"></label>
                                                </div>
                                            </div>
                                        </div>
                                        <p>Sneaker News & Promotions</p>
                                    </div>


                                    <div class="notification-items">
                                        <div class="notification-container">
                                            <div class="info-text-title">
                                                <h5>Handbag News & Promotions</h5>
                                            </div>
                                            <div class="center-line"></div>
                                            <div class="form-group">
                                                <div class="custom-control custom-switch">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="customSwitch20">
                                                    <label class="custom-control-label" for="customSwitch20"></label>
                                                </div>
                                            </div>
                                        </div>
                                        <p>Handbag News & Promotions</p>
                                    </div>



                                    <div class="notification-items">
                                        <div class="notification-container">
                                            <div class="info-text-title">
                                                <h5>Watch News & Promotions</h5>
                                            </div>
                                            <div class="center-line"></div>
                                            <div class="form-group">
                                                <div class="custom-control custom-switch">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="customSwitch21">
                                                    <label class="custom-control-label" for="customSwitch21"></label>
                                                </div>
                                            </div>
                                        </div>
                                        <p>Watch News & Promotions</p>
                                    </div>


                                    <div class="notification-items">
                                        <div class="notification-container">
                                            <div class="info-text-title">
                                                <h5>Streetwear News & Promotions</h5>
                                            </div>
                                            <div class="center-line"></div>
                                            <div class="form-group">
                                                <div class="custom-control custom-switch">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="customSwitch22">
                                                    <label class="custom-control-label" for="customSwitch22"></label>
                                                </div>
                                            </div>
                                        </div>
                                        <p>Streetwear News & Promotions</p>
                                    </div>


                                    <div class="notification-items">
                                        <div class="notification-container">
                                            <div class="info-text-title">
                                                <h5>Price Drop Email</h5>
                                            </div>
                                            <div class="center-line"></div>
                                            <div class="form-group">
                                                <div class="custom-control custom-switch">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="customSwitch23">
                                                    <label class="custom-control-label" for="customSwitch23"></label>
                                                </div>
                                            </div>
                                        </div>
                                        <p>Price Drop Email</p>
                                    </div>


                                    <div class="notification-items">
                                        <div class="notification-container">
                                            <div class="info-text-title">
                                                <h5>Welcome Series</h5>
                                            </div>
                                            <div class="center-line"></div>
                                            <div class="form-group">
                                                <div class="custom-control custom-switch">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="customSwitch24">
                                                    <label class="custom-control-label" for="customSwitch24"></label>
                                                </div>
                                            </div>
                                        </div>
                                        <p>Welcome Series</p>
                                    </div>


                                    <div class="notification-items">
                                        <div class="notification-container">
                                            <div class="info-text-title">
                                                <h5>Collectibles News & Promotions</h5>
                                            </div>
                                            <div class="center-line"></div>
                                            <div class="form-group">
                                                <div class="custom-control custom-switch">
                                                    <input type="checkbox" class="custom-control-input"
                                                        id="customSwitch25">
                                                    <label class="custom-control-label" for="customSwitch25"></label>
                                                </div>
                                            </div>
                                        </div>
                                        <p>Collectibles News & Promotions</p>
                                    </div>


                                </div>
                            </div>

                        </div>
                    </div>
                </div><!-- /.container-fluid -->
            </section>
            <!-- /.content -->
        </div>

@stop