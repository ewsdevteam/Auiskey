@extends('shop::customers.account.index')

@section('page-detail-wrapper')
<div class="content-wrapper">   
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h4 class="m-0">Trending</h4>
            <p>This product will show you how trending products are behaving.</p>
          </div><!-- /.col -->          
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Main row -->
        <div class="row">
          <!-- Left col -->
          <div class="col-lg-12">
            <!-- Product List -->
            <div class="product-listing-sec">

              <div class="product-listing">
                <div class="list-item product-img-title">
                  <div class="list-img">
                    <img src="{{asset('themes/auiskey/assets/customer-dashboard/dist/img/jordan-6.png')}}" alt="sneaker">
                  </div>
                  <div class="list-title">
                    <p class="product-title">Jordan 12 Retro Utility</p>
                    <p>Lowest Ask</p>
                  </div>
                </div>
                <div class="list-item">
                  <p>Released in August of 2021</p>
                </div>
                <div class="list-item">
                  <div class="progress progress-xs">
                    <div class="progress-bar progress-bar-pink" style="width: 55%"></div>
                  </div>
                </div>
              </div>   

              <div class="product-listing">
                <div class="list-item product-img-title">
                  <div class="list-img">
                    <img src="{{asset('themes/auiskey/assets/customer-dashboard/dist/img/jordan-6.png')}}" alt="sneaker">
                  </div>
                  <div class="list-title">
                    <p class="product-title">Jordan 12 Retro Utility</p>
                    <p>Lowest Ask</p>
                  </div>
                </div>
                <div class="list-item">
                  <p>Released in August of 2021</p>
                </div>
                <div class="list-item">
                  <div class="progress progress-xs">
                    <div class="progress-bar progress-bar-pink" style="width: 55%"></div>
                  </div>
                </div>
              </div>   

            </div>
          </div>

          
          
          <!-- /.Left col -->
          <!-- right col (We are only adding the ID to make the widgets sortable)-->          
        </div>
        <div class="row">
          <!-- Active Ask -->
          <div class="active-ask">
            <div class="active-ask-left active-ask-item">
              <h4>Active Asks</h4>
              <p>See how your trade rages are progressing via the new statistics engine.</p>
            </div>
            <div class="active-ask-right active-ask-item">
              <label for="text">Timeline :</label>
              <select class="form-control">
                <option>1 days</option>
                <option>2 days</option>
                <option>3 days</option>
                <option>4 days</option>
                <option>5 days</option>
              </select>
            </div>
          </div>
          <div class="col-lg-6">          

            <div class="highlight-lineChart trade-range">
                <div class="highlight-lineChart-title">
                  <h5>Trade Range</h5>
                  <p>12 Month</p>
                </div>
                <canvas id="myChart"></canvas>
                <div class="trade">
                  <ul>
                    <li>
                      <span class="circle-item"></span>
                      <div class="trade-item">
                        <p>12-Month Trade Range</p>
                        <p>$200 - $416</p>
                      </div>
                    </li>
                    <li>
                      <span class="circle-item"></span>
                      <div class="trade-item">
                        <p>12-Month Trade Range</p>
                        <p>$200 - $416</p>
                      </div>
                    </li>
                    <li>
                      <span class="circle-item"></span>
                      <div class="trade-item">
                        <p>12-Month Trade Range</p>
                        <p>$200 - $416</p>
                      </div>
                    </li>
                  </ul>
                </div>
            </div>            
          </div>          
          <div class="col-lg-6">
              <div id="user-profile">
                <div class="profile-image">
                  <img src="{{asset('themes/auiskey/assets/customer-dashboard/dist/img/avatar5.png')}}" alt="avatar5">
                  <span class="online-identifier"></span>
                </div>
                <div class="user-title">
                  <h4>Girish .J</h4>
                  <p>VIC, Austrailia</p>
                </div>
                <div class="profile-specification">
                  <div class="pending-ask child-specification">
                    <p>Pending Ask</p>
                    <h2>14 Items</h2>
                  </div>
                  <div class="total-spent child-specification">
                    <p>Total Spent</p>
                    <h2>$6269</h2>
                  </div>
                  <div class="profit child-specification">
                    <p>Profit</p>
                    <h2>$829</h2>
                  </div>
                  <div class="overall child-specification">
                    <p>% overall</p>
                    <h2>48%</h2>
                  </div>  
                </div>
                <a href="">History</a>
              </div>
          </div>
          <div class="col-lg-6">
            <div class="highlight-lineChart">
              <div class="highlight-lineChart-title">
                <h5>Overdue</h5>
                <h1>$14220</h1>
              </div>
              <div id="container" style="height: 400px; width: 100%"></div>
            </div>
          </div>
        </div>
        <!-- /.row (main row) -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
@stop
