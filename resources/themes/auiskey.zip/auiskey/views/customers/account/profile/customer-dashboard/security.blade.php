@extends('shop::customers.account.index')

@section('page-detail-wrapper')
<div class="content-wrapper security-content">
    <section class="content element-setting ">
      <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="security-container">
                    <h4 class="title-text">Security</h4>
                    <h6>Two-Step Verification</h6>
                    <p>Adding two-step verification improves the overall security of your StockX account. Two-step verification
                        requires you to enter a code on a trusted mobile device in addition to your password at sign-in.</p>
                    <a href="" class="btn btn-default btn-bg-primary">Turn On</a>

                    <div class="faq-security">
                        <h2 class="faq-title-text">FAQ</h2>
                        
                        <h4>Why should I enable two-step verification?</h4>
                        <p>We're all human, and we all use passwords that can be a little baisc (shout out our pets). Two-Step
                            verification enhances the protection of your StockX account even if your password is compromised.
                        </p>
                        
                        <h4>What do I need to set up two-step verification?</h4>
                        <p>You'll need a phone that can receive SMS messages to enable two-step verification.</p>

                        <h4>How do I set up two-step verification?</h4>
                        <p>Click "Turn On" above to set up two-step verification.</p>

                        <ol>
                            <li>Input your cell phone number.</li>
                            <li>We'll send you a one-time code via SMS.</li>
                            <li>Enter the code on the login screen.</li>
                            <li>Remember to save the recovery code so you can still sign in if you don't have access to a trusted device.</li>
                        </ol>

                        <img src="{{asset('themes/auiskey/assets/customer-dashboard/dist/img/verification-code.jpg')}}" alt="verification-code-img" width="80%">
                        
                        <h4>For more information, see: two-step verification details.</h4>
                        <p>Please note: standard message and data rates may apply.</p>
                    </div>
                </div>
            </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    </div>
@stop