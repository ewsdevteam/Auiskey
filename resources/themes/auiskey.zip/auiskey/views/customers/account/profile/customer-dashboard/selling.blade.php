@extends('shop::customers.account.index')

@section('page-detail-wrapper')
<div class="content-wrapper security-content">
            <!-- Main content -->
            <section class="content element-setting ">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="security-container">
                                <h4 class="title-text">Selling</h4>
                                <p>This table will show you how your current, pending & history selling are behaving.</p>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="card card-primary card-outline card-tabs">
                                <div class="card-header p-0 pt-1 border-bottom-0">
                                    <ul class="nav nav-tabs" id="custom-tabs-three-tab" role="tablist">
                                        <li class="nav-item">
                                            <a class="nav-link active" id="custom-tabs-three-home-tab"
                                                data-toggle="pill" href="#custom-tabs-three-home" role="tab"
                                                aria-controls="custom-tabs-three-home" aria-selected="true">Current</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" id="custom-tabs-three-profile-tab" data-toggle="pill"
                                                href="#custom-tabs-three-profile" role="tab"
                                                aria-controls="custom-tabs-three-profile"
                                                aria-selected="false">Pending</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" id="custom-tabs-three-messages-tab" data-toggle="pill"
                                                href="#custom-tabs-three-messages" role="tab"
                                                aria-controls="custom-tabs-three-messages"
                                                aria-selected="false">History</a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="card-body">
                                    <div class="tab-content" id="custom-tabs-three-tabContent">
                                        <div class="tab-pane fade show active" id="custom-tabs-three-home"
                                            role="tabpanel" aria-labelledby="custom-tabs-three-home-tab">
                                            <!-- data table -->
                                            <table id="currentTable" class="table table-bordered table-hover">
                                                <thead>
                                                <tr>
                                                    <th>Item</th>
                                                    <th>Ask Price</th>
                                                    <th>Highest Bid</th>
                                                    <th>Lowest Ask</th>
                                                    <th>Spread</th>
                                                    <th>Expire</th>
                                                  </tr>
                                                  </thead>
                                                  <tbody>
                                                  <tr>
                                                    <td>
                                                        <div class="products-list">
                                                          <img src="{{asset('themes/auiskey/assets/customer-dashboard/dist/img/jordan-6.png')}}" alt="sneaker6" width="40px" height="40px">
                                                          <div class="product-title-texts">
                                                              <p>Jordan 12 Retro Utility</p>
                                                              <p>Lowest Ask</p>                                                        
                                                        </div>
                                                      </div>
                                                    </td>
                                                    <td>A$200</td>
                                                    <td>A$400</td>
                                                    <td>A$40</td>
                                                    <td>
                                                        <div class="progress progress-xs">
                                                            <div class="progress-bar progress-bar-pink" style="width: 55%"></div>
                                                          </div>
                                                    </td>
                                                    <td>15 Jun 2021</td>
                                                  </tr> 

                                                  <tr>
                                                    <td>
                                                        <div class="products-list">
                                                          <img src="{{asset('themes/auiskey/assets/customer-dashboard/dist/img/jordan-6.png')}}" alt="sneaker6" width="40px" height="40px">
                                                          <div class="product-title-texts">
                                                              <p>Jordan 12 Retro Utility</p>
                                                              <p>Lowest Ask</p>                                                        
                                                        </div>
                                                      </div>
                                                    </td>
                                                    <td>A$650</td>
                                                    <td>A$850</td>
                                                    <td>A$238</td>
                                                    <td>
                                                        <div class="progress progress-xs">
                                                            <div class="progress-bar progress-bar-pink" style="width: 55%"></div>
                                                          </div>
                                                    </td>
                                                    <td>15 Jun 2021</td>
                                                  </tr> 


                                                  <tr>
                                                    <td>
                                                        <div class="products-list">
                                                          <img src="{{asset('themes/auiskey/assets/customer-dashboard/dist/img/jordan-6.png')}}" alt="sneaker6" width="40px" height="40px">
                                                          <div class="product-title-texts">
                                                              <p>Jordan 12 Retro Utility</p>
                                                              <p>Lowest Ask</p>                                                        
                                                        </div>
                                                      </div>
                                                    </td>
                                                    <td>A$780</td>
                                                    <td>A$1,180</td>
                                                    <td>A$650</td>
                                                    <td>
                                                        <div class="progress progress-xs">
                                                            <div class="progress-bar progress-bar-pink" style="width: 55%"></div>
                                                          </div>
                                                    </td>
                                                    <td>15 Jun 2021</td>
                                                  </tr> 
                                                </tbody>                                                
                                              </table>
                                        </div>
                                        <div class="tab-pane fade" id="custom-tabs-three-profile" role="tabpanel"
                                            aria-labelledby="custom-tabs-three-profile-tab">
                                            <!-- data table -->
                                            <table id="pendingTable" class="table table-bordered table-hover">
                                                <thead>
                                                <tr>
                                                    <th>Item</th>
                                                    <th>Ask Price</th>
                                                    <th>Highest Bid</th>
                                                    <th>Lowest Ask</th>
                                                    <th>Spread</th>
                                                    <th>Expire</th>
                                                  </tr>
                                                  </thead>
                                                  <tbody>
                                                  <tr>
                                                    <td>
                                                        <div class="products-list">
                                                          <img src="{{asset('themes/auiskey/assets/customer-dashboard/dist/img/jordan-6.png')}}" alt="sneaker6" width="40px" height="40px">
                                                          <div class="product-title-texts">
                                                              <p>Jordan 12 Retro Utility</p>
                                                              <p>Lowest Ask</p>                                                        
                                                        </div>
                                                      </div>
                                                    </td>
                                                    <td>A$200</td>
                                                    <td>A$400</td>
                                                    <td>A$40</td>
                                                    <td>
                                                        <div class="progress progress-xs">
                                                            <div class="progress-bar progress-bar-pink" style="width: 55%"></div>
                                                          </div>
                                                    </td>
                                                    <td>15 Jun 2021</td>
                                                  </tr> 

                                                  <tr>
                                                    <td>
                                                        <div class="products-list">
                                                          <img src="{{asset('themes/auiskey/assets/customer-dashboard/dist/img/jordan-6.png')}}" alt="sneaker6" width="40px" height="40px">
                                                          <div class="product-title-texts">
                                                              <p>Jordan 12 Retro Utility</p>
                                                              <p>Lowest Ask</p>                                                        
                                                        </div>
                                                      </div>
                                                    </td>
                                                    <td>A$650</td>
                                                    <td>A$850</td>
                                                    <td>A$238</td>
                                                    <td>
                                                        <div class="progress progress-xs">
                                                            <div class="progress-bar progress-bar-pink" style="width: 55%"></div>
                                                          </div>
                                                    </td>
                                                    <td>15 Jun 2021</td>
                                                  </tr> 


                                                  <tr>
                                                    <td>
                                                        <div class="products-list">
                                                          <img src="{{asset('themes/auiskey/assets/customer-dashboard/dist/img/jordan-6.png')}}" alt="sneaker6" width="40px" height="40px">
                                                          <div class="product-title-texts">
                                                              <p>Jordan 12 Retro Utility</p>
                                                              <p>Lowest Ask</p>                                                        
                                                        </div>
                                                      </div>
                                                    </td>
                                                    <td>A$780</td>
                                                    <td>A$1,180</td>
                                                    <td>A$650</td>
                                                    <td>
                                                        <div class="progress progress-xs">
                                                            <div class="progress-bar progress-bar-pink" style="width: 55%"></div>
                                                          </div>
                                                    </td>
                                                    <td>15 Jun 2021</td>
                                                  </tr> 
                                                </tbody>                                                
                                              </table>
                                        </div>
                                        <div class="tab-pane fade" id="custom-tabs-three-messages" role="tabpanel"
                                            aria-labelledby="custom-tabs-three-messages-tab">
                                            <!-- data table -->
                                            <table id="historyTable" class="table table-bordered table-hover">
                                                <thead>
                                                <tr>
                                                    <th>Item</th>
                                                    <th>Ask Price</th>
                                                    <th>Highest Bid</th>
                                                    <th>Lowest Ask</th>
                                                    <th>Spread</th>
                                                    <th>Expire</th>
                                                  </tr>
                                                  </thead>
                                                  <tbody>
                                                  <tr>
                                                    <td>
                                                        <div class="products-list">
                                                          <img src="{{asset('themes/auiskey/assets/customer-dashboard/dist/img/jordan-6.png')}}" alt="sneaker6" width="40px" height="40px">
                                                          <div class="product-title-texts">
                                                              <p>Jordan 12 Retro Utility</p>
                                                              <p>Lowest Ask</p>                                                        
                                                        </div>
                                                      </div>
                                                    </td>
                                                    <td>A$200</td>
                                                    <td>A$400</td>
                                                    <td>A$40</td>
                                                    <td>
                                                        <div class="progress progress-xs">
                                                            <div class="progress-bar progress-bar-pink" style="width: 55%"></div>
                                                          </div>
                                                    </td>
                                                    <td>15 Jun 2021</td>
                                                  </tr> 

                                                  <tr>
                                                    <td>
                                                        <div class="products-list">
                                                          <img src="{{asset('themes/auiskey/assets/customer-dashboard/dist/img/jordan-6.png')}}" alt="sneaker6" width="40px" height="40px">
                                                          <div class="product-title-texts">
                                                              <p>Jordan 12 Retro Utility</p>
                                                              <p>Lowest Ask</p>                                                        
                                                        </div>
                                                      </div>
                                                    </td>
                                                    <td>A$650</td>
                                                    <td>A$850</td>
                                                    <td>A$238</td>
                                                    <td>
                                                        <div class="progress progress-xs">
                                                            <div class="progress-bar progress-bar-pink" style="width: 55%"></div>
                                                          </div>
                                                    </td>
                                                    <td>15 Jun 2021</td>
                                                  </tr> 


                                                  <tr>
                                                    <td>
                                                        <div class="products-list">
                                                          <img src="{{asset('themes/auiskey/assets/customer-dashboard/dist/img/jordan-6.png')}}" alt="sneaker6" width="40px" height="40px">
                                                          <div class="product-title-texts">
                                                              <p>Jordan 12 Retro Utility</p>
                                                              <p>Lowest Ask</p>                                                        
                                                        </div>
                                                      </div>
                                                    </td>
                                                    <td>A$780</td>
                                                    <td>A$1,180</td>
                                                    <td>A$650</td>
                                                    <td>
                                                        <div class="progress progress-xs">
                                                            <div class="progress-bar progress-bar-pink" style="width: 55%"></div>
                                                          </div>
                                                    </td>
                                                    <td>15 Jun 2021</td>
                                                  </tr> 
                                                </tbody>                                                
                                              </table>
                                              </div>
                                    </div>
                                </div>
                                <!-- /.card -->
                            </div>
                        </div>
                    </div>
                </div><!-- /.container-fluid -->
            </section>
            <!-- /.content -->
        </div>


@stop