@extends('shop::customers.account.index')

@section('page_title')
    {{ __('shop::app.customer.account.profile.index.title') }}
@endsection

@section('page-detail-wrapper')
<div class="content-wrapper security-content">
    <section class="content element-setting ">
        <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="profile-heading security-container">
                    <div class="active-ask">
                        <div class="active-ask-left active-ask-item">
                            <h4 class="title-text">Profile</h4>
                        </div>
                    </div>
                </div>
            <div class="row">
                <div class="col-12">
                    {!! view_render_event('bagisto.shop.customers.account.profile.edit.before', ['customer' => $customer]) !!}
                            <form
                                method="POST"
                                action="{{ route('customer.profile.store') }}"
                                class="edit__profile_form">
                                @csrf            
                                <div class="account-table-content">
                                    <div class="row">
                                        <label class="col-12">
                                        {{ __('shop::app.customer.account.profile.fname') }}
                                        </label>
                                        <div class="col-12">
                                            <input value="{{ $customer->first_name }}" name="first_name" class="form-control" type="text">
                                        </div>
                                    </div>
                                    <div class="row ">
                                        <label class="col-12 mandatory">
                                        {{ __('shop::app.customer.account.profile.lname') }}
                                        </label>
                                        <div class="col-12">
                                            <input value="{{ $customer->last_name }}" name="last_name" class="form-control" type="text">
                                        </div>
                                    </div>
                                    <div class="row ">
                                        <label class="col-12">
                                            Gender
                                        </label>
                                        <div class="col-12">
                                            <select
                                                name="gender"
                                                class="form-control"
                                                >

                                                <option value=""  @if ($customer->gender == "") selected @endif></option>
                                                <option
                                                    value="Other"
                                                    @if ($customer->gender == "Other")
                                                        selected="selected"
                                                    @endif>
                                                    {{ __('velocity::app.shop.gender.other') }}
                                                </option>

                                                <option
                                                    value="Male"
                                                    @if ($customer->gender == "Male")
                                                        selected="selected"
                                                    @endif>
                                                    {{ __('velocity::app.shop.gender.male') }}
                                                </option>

                                                <option
                                                    value="Female"
                                                    @if ($customer->gender == "Female")
                                                        selected="selected"
                                                    @endif>
                                                    {{ __('velocity::app.shop.gender.female') }}
                                                </option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="row ">
                                        <label class="col-12">
                                        {{ __('shop::app.customer.account.profile.dob') }}
                                        </label>
                                        <div class="col-12">
                                            <input
                                            type="date"
                                            name="date_of_birth"
                                            placeholder="dd/mm/yyyy"
                                            value="{{ old('date_of_birth') ?? $customer->date_of_birth }}"
                                            class="form-control">
                                            
                                        </div>
                                    </div>
                                    <div class="row"><label class="col-12 mandatory">
                                        {{ __('shop::app.customer.account.profile.email') }}
                                        </label>
                                        <div class="col-12"><input value="{{ $customer->email }}" name="email" type="text"
                                                aria-required="true" aria-invalid="false" class="form-control">
                                            <!---->
                                        </div>
                                    </div>
                                    <div class="row"><label class="col-12">
                                        {{ __('shop::app.customer.account.profile.phone') }}
                                        </label>
                                        <div class="col-12"><input value="{{ old('phone') ?? $customer->phone }}" name="phone" type="text" class="form-control">
                                            <!---->
                                        </div>
                                    </div>
                                    <div class="row"><label class="col-12">
                                    {{ __('velocity::app.shop.general.enter-current-password') }}
                                        </label>
                                        <div class="col-12 "><input value="" name="oldpassword" type="password" class="form-control"></div>
                                    </div>
                                    <div class="row"><label class="col-12">
                                            New password
                                        </label>
                                        <div class="col-12 "><input value="" name="password" type="password"
                                                aria-required="false" aria-invalid="false" class="form-control">
                                            <!---->
                                        </div>
                                    </div>
                                    <div class="row"><label class="col-12">
                                            Confirm new password
                                        </label>
                                        <div class="col-12 "><input value="" name="password_confirmation"
                                                type="password" data-vv-as="confirm password" aria-required="false"
                                                aria-invalid="false" class="form-control">
                                            <!---->
                                        </div>
                                    </div>
                                    @if (core()->getConfigData('customer.settings.newsletter.subscription'))
                                    <div class="control-group">
                                        <input type="checkbox" id="checkbox2" name="subscribed_to_news_letter" @if (isset($customer->subscription)) value="{{ $customer->subscription->is_subscribed }}" {{ $customer->subscription->is_subscribed ? 'checked' : ''}} @endif  style="width: auto;">
                                        <span>{{ __('shop::app.customer.signup-form.subscribe-to-newsletter') }}</span>
                                    </div>
                                    @endif
                                    <button
                                        type="submit" class="btn btn-primary btn__edit_profile">
                                        Update
                                    </button>
                                </div>
                            </form>
                    {!! view_render_event('bagisto.shop.customers.account.profile.edit.after', ['customer' => $customer]) !!}        
                </div>
            </div>
        </div>
    </div>
</div><!-- /.container-fluid -->
</section>
<!-- /.content -->
</div>
   
@endsection

