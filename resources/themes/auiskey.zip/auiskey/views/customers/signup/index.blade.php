@extends('shop::layouts.master')

@section('page_title')
    {{ __('shop::app.customer.signup-form.page-title') }}
@endsection

@section('content-wrapper')
@push('css')
    <style>
        .error{
            color:#296242 !important; 
        }
    </style>
@endpush
<section class="signup-form login-form">
        <div class="container">
            <div class="login-sec">
                <div class="login-btns">
                    <div class="each-one">
                    <a href="{{ route('customer.session.index') }}" class="angle-btn btn-Primary"><span>Login</span></a>
                        <a href="{{ route('customer.register.index') }}" class="angle-btn btn-Primary active-angle-btn"><span>Signup</span></a>
                    </div>                                       
                </div>
                <div class="login-form-slider">
                    <!-- Slider -->
                    <div class="form-slider signup-form-slider">
                        <div class="login-owl-carousel owl-carousel owl-theme">
                            <div class="item login-slider-item">
                                <img src="{{asset('themes/auiskey/assets/img/brands/login-slider-1.png')}}" alt="sneaker-1">
                            </div>
                            <div class="item login-slider-item">
                                <img src="{{asset('themes/auiskey/assets/img/brands/login-slider-1.png')}}" alt="sneaker-1">
                            </div>
                            <div class="item login-slider-item">
                                <img src="{{asset('themes/auiskey/assets/img/brands/login-slider-1.png')}}" alt="sneaker-1">
                            </div>
                        </div>
                    </div>
                    <!-- Form -->
                    <div class="login-form-sec">
                        <div class="stockX-logo">
                            <img src="{{asset('themes/auiskey/assets/img/brands/logo.png')}}" alt="stockX-logo">    
                        </div>
                        <form method="post"
                              action="{{ route('customer.register.create') }}"
                              id = "register">

                            {{ csrf_field() }}
                            <div class="form-group">
                                <label for="first-name">{{ __('shop::app.customer.signup-form.firstname') }}</label>
                                <input  type="text"
                                    class="form-control"
                                    name="first_name"
                                    value="{{ old('first_name') }}">
                                @error('first_name')
                                    <span class = "error">{{ $message }}</span>
                                @endif    
                            </div>
                            <div class="form-group">
                                <label for="last-name">{{ __('shop::app.customer.signup-form.lastname') }}</label>
                                <input type="text"
                                    class="form-control"
                                    name="last_name"
                                    value="{{ old('last_name') }}">
                                @error('last_name')
                                    <span class = "error">{{ $message }}</span>
                                @endif
                            </div>
                            <div class="form-group">
                                <label for="email">{{ __('shop::app.customer.signup-form.email') }}</label>
                                <input type="email"
                                    class="form-control"
                                    name="email"
                                    value="{{ old('email') }}">
                                @error('email')
                                    <span class = "error">{{ $message }}</span>
                                @endif
                            </div>
                            <div class="form-group">
                                <label for="Password">{{ __('shop::app.customer.signup-form.password') }}</label>
                                <input type="password"
                                    class="form-control"
                                    name="password"
                                    id="password"
                                    value="{{ old('password') }}">
                                @error('password')
                                    <span class = "error">{{ $message }}</span>
                                @endif   
                            </div>
                            <div class="form-group">
                                <label for="Password">{{ __('shop::app.customer.signup-form.confirm_pass') }}</label>
                                <input
                                    type="password"
                                    class="form-control"
                                    name="password_confirmation">
                                @error('password_confirmation')
                                    <span class = "error">{{ $message }}</span>
                                @endif
                            </div>
                            <div class="links-redirected">
                                <!-- <span>At least 8 characters, 1 uppercase letter, 1 number & 1 symbol</span>                                 -->
                            </div>
                            <input type="submit" value="Signup" class="btn btn-Primary btn-submit">
                            <div class="continue-with">
                                <p>Continue with</p>
                                <ul>
                                    <li><a href=""><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href=""><i class="fab fa-twitter"></i></a></li>
                                    <li><a href=""><i class="fab fa-instagram"></i></a></li>
                                </ul>
                            </div>
                            <div class="signing-up">
                                <input type="checkbox" id="checkbox2" name="is_subscribed">
                                <p>{{ __('shop::app.customer.signup-form.subscribe-to-newsletter') }}</p>
                            </div>
                        </form>
                    </div>
                </div> 
            </div>
        </div>
    </section>

@endsection

@push('scripts')
<script type = "text/javascript">
  $(document).ready(function(){
            $('#register').validate({
            rules:{
                first_name:{
                    required:true,
                },
                last_name:{
                    required:true,
                },
                email: {
                required: true,
                email: true
                },
                 password : {
                    required:true, 
                    minlength : 6
                },
                password_confirmation : {
                    minlength : 6,
                    equalTo : "#password"
                }
            },
            messages:{
                first_name:{
                    required:'Enter your First Name',
                },
                last_name:{
                    required:'Enter your Last Name',
                },
                email : {
                required: 'Enter your email',
                },
                password : {
                required: 'Enter your password',
                minlength: 'Minimum password should consist 6 character'
                },
                password_confirmation:{
                    minlength: 'Minimum password should consist 6 character',
                    equalTo: 'Password mismatch'
                }
            }
    })     
            
    })
</script>
@endpush

@push('scripts')

{!! Captcha::renderJS() !!}

@endpush