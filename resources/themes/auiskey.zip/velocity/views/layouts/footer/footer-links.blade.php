<div class="row footer-statics col-12 no-margin">
    @include('velocity::layouts.footer.footer-links.footer-left')
    @include('velocity::layouts.footer.footer-links.footer-middle')
    @include('velocity::layouts.footer.footer-links.footer-right')
</div>

